# coding: utf-8

"""
    IoT TS Aggregates API

     The aggregate service enables querying aggregated time series data including * aggregates generated on the fly * aggregates pre-calculated during ingest  Depending on, if entity is performance or simulation entity, different aggregation intervals are supported.  ### Performance Entity  Pre-calculated aggregates are available in the following intervals * 2 minute * 1 hour * 1 day  Intervals smaller than 2 minutes are also available and generated on the fly.   ### Simulation Entity  Pre-calculated aggregates are available in the following intervals * 1 millisecond * 10 millisecond * 1 second  On the fly aggregation is not supported for simulation entities.  Note: There might be time series data ingested in the past for which pre-calculated aggregates have not been computed. In that case for simulation entities, no aggregated data is returned.   # noqa: E501
"""


from __future__ import absolute_import

import unittest
from unittest.mock import MagicMock
from tsaggregates.clients import AggregatesClient
from tsaggregates.models import *
from tests.unit.test_util import TestUtil, MOCK_VALUE, MOCK_SUCCESS
from mindsphere_core.exceptions import MindsphereError
from mindsphere_core import TenantCredentials, mindsphere_core, token_service


class AggregatesClientUnitTest(unittest.TestCase):
    """AggregatesClient unit test stubs"""

    def setUp(self):
        credentials = TenantCredentials(client_id=MOCK_VALUE, client_secret=MOCK_VALUE, tenant=MOCK_VALUE)
        config = mindsphere_core.RestClientConfig(MOCK_VALUE, MOCK_VALUE)
        self.client = AggregatesClient(config, credentials)
        token_service._invoke_token_endpoint = MagicMock(return_value=MOCK_SUCCESS)

    def test_get_aggregate_timeseries(self):
        """Test case for get_aggregate_timeseries
        read aggregated time series
        """
        package_name = "tsaggregates.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = GetAggregateTimeseriesRequest()
        request_object.entity = TestUtil.get_mock_data(package_name, "str")
        request_object.propertyset = TestUtil.get_mock_data(package_name, "str")
        request_object._from = TestUtil.get_mock_data(package_name, "datetime")
        request_object.to = TestUtil.get_mock_data(package_name, "datetime")
        request_object.interval_value = TestUtil.get_mock_data(package_name, "float")
        request_object.interval_unit = TestUtil.get_mock_data(package_name, "str")
        response = self.client.get_aggregate_timeseries(request_object)
        self.assertEqual(200, response)

    def test_negative_get_aggregate_timeseries(self):
        """Negative test case for get_aggregate_timeseries
        read aggregated time series
        """
        request_object = GetAggregateTimeseriesRequest()
        with self.assertRaises(MindsphereError):
            self.client.get_aggregate_timeseries(request_object)

    def test_negative_request_get_aggregate_timeseries(self):
        """Negative test case for get_aggregate_timeseries
        read aggregated time series
        """
        with self.assertRaises(MindsphereError):
            self.client.get_aggregate_timeseries(None)


if __name__ == '__main__':
    unittest.main()
