# coding: utf-8

"""
    IoT Time Series API

    Store and query time series data with a precision of 1 millisecond.  # noqa: E501
"""


from __future__ import absolute_import

import unittest
from unittest.mock import MagicMock
from timeseries.clients import TimeSeriesClient
from timeseries.models import *
from tests.unit.test_util import TestUtil, MOCK_VALUE, MOCK_SUCCESS
from mindsphere_core.exceptions import MindsphereError
from mindsphere_core import TenantCredentials, mindsphere_core, token_service


class TimeSeriesClientUnitTest(unittest.TestCase):
    """TimeSeriesClient unit test stubs"""

    def setUp(self):
        credentials = TenantCredentials(client_id=MOCK_VALUE, client_secret=MOCK_VALUE, tenant=MOCK_VALUE)
        config = mindsphere_core.RestClientConfig(MOCK_VALUE, MOCK_VALUE)
        self.client = TimeSeriesClient(config, credentials)
        token_service._invoke_token_endpoint = MagicMock(return_value=MOCK_SUCCESS)

    def test_delete_timeseries(self):
        """Test case for delete_timeseries
        delete time series
        """
        package_name = "timeseries.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = DeleteTimeseriesRequest()
        request_object.entity = TestUtil.get_mock_data(package_name, "str")
        request_object.propertysetname = TestUtil.get_mock_data(package_name, "str")
        request_object._from = TestUtil.get_mock_data(package_name, "datetime")
        request_object.to = TestUtil.get_mock_data(package_name, "datetime")
        response = self.client.delete_timeseries(request_object)
        self.assertEqual(200, response)

    def test_negative_delete_timeseries(self):
        """Negative test case for delete_timeseries
        delete time series
        """
        request_object = DeleteTimeseriesRequest()
        with self.assertRaises(MindsphereError):
            self.client.delete_timeseries(request_object)

    def test_negative_request_delete_timeseries(self):
        """Negative test case for delete_timeseries
        delete time series
        """
        with self.assertRaises(MindsphereError):
            self.client.delete_timeseries(None)

    def test_get_timeseries(self):
        """Test case for get_timeseries
        read time series
        """
        package_name = "timeseries.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = GetTimeseriesRequest()
        request_object.entity = TestUtil.get_mock_data(package_name, "str")
        request_object.propertysetname = TestUtil.get_mock_data(package_name, "str")
        response = self.client.get_timeseries(request_object)
        self.assertEqual(200, response)

    def test_negative_get_timeseries(self):
        """Negative test case for get_timeseries
        read time series
        """
        request_object = GetTimeseriesRequest()
        with self.assertRaises(MindsphereError):
            self.client.get_timeseries(request_object)

    def test_negative_request_get_timeseries(self):
        """Negative test case for get_timeseries
        read time series
        """
        with self.assertRaises(MindsphereError):
            self.client.get_timeseries(None)

    def test_put_timeseries(self):
        """Test case for put_timeseries
        write or update time series
        """
        package_name = "timeseries.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = PutTimeseriesRequest()
        request_object.entity = TestUtil.get_mock_data(package_name, "str")
        request_object.propertysetname = TestUtil.get_mock_data(package_name, "str")
        request_object.timeseries = TestUtil.get_mock_data(package_name, "list[Timeseries]")
        response = self.client.put_timeseries(request_object)
        self.assertEqual(200, response)

    def test_negative_put_timeseries(self):
        """Negative test case for put_timeseries
        write or update time series
        """
        request_object = PutTimeseriesRequest()
        with self.assertRaises(MindsphereError):
            self.client.put_timeseries(request_object)

    def test_negative_request_put_timeseries(self):
        """Negative test case for put_timeseries
        write or update time series
        """
        with self.assertRaises(MindsphereError):
            self.client.put_timeseries(None)


if __name__ == '__main__':
    unittest.main()
