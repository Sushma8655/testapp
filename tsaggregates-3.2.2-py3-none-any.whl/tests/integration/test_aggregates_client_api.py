import unittest
from mindsphere_core import mindsphere_core, TenantCredentials, AppCredentials

from tsaggregates.clients.aggregates_client import AggregatesClient
from tsaggregates.models import *
from mindsphere_core.exceptions import MindsphereError, MindsphereClientError
from tests.data.test_data import *


class TestEventAnalytics(unittest.TestCase):
    def setUp(self):
        config = mindsphere_core.RestClientConfig("194.138.0.25", "9400")
        self.client = AggregatesClient(rest_client_config=config)

    def test_get_aggregate_timeseries_without_required_param(self):
        request_object = GetAggregateTimeseriesRequest(
            _from="2018-01-24T05:03:41Z",
            to="2018-01-24T05:10:41Z",
            interval_value="60",
            interval_unit="second",
            select="FRWheel",
            entity="078b1908bc9347678168760934465587",
            propertyset="TyreTemperature",
        )
        response = self.client.get_aggregate_timeseries(request_object)
        self.assertIsNotNone(response)

    def test_get_aggregate_timeseries_should_fail_without_entity(self):
        request_object = GetAggregateTimeseriesRequest(
            _from="2018-01-24T05:03:41Z",
            to="2018-01-24T05:10:41Z",
            interval_value="60",
            interval_unit="second",
            select="FRWheel",
            propertyset="TyreTemperature",
        )
        with self.assertRaises(MindsphereClientError):
            self.client.get_aggregate_timeseries(request_object)

    def test_get_aggregate_timeseries_should_fail_without_property(self):
        request_object = GetAggregateTimeseriesRequest(
            _from="2018-01-24T05:03:41Z",
            to="2018-01-24T05:10:41Z",
            interval_value="60",
            interval_unit="second",
            select="FRWheel",
            entity="078b1908bc9347678168760934465587",
        )
        with self.assertRaises(MindsphereClientError):
            self.client.get_aggregate_timeseries(request_object)

    def test_get_aggregate_timeseries_should_fail_invalid_entity(self):
        request_object = GetAggregateTimeseriesRequest(
            _from="2018-01-24T05:03:41Z",
            to="2018-01-24T05:10:41Z",
            interval_value="60",
            interval_unit="second",
            select="FRWheel",
            entity="invalid",
        )
        with self.assertRaises(MindsphereError):
            self.client.get_aggregate_timeseries(request_object)


if __name__ == "__main__":
    unittest.main()
