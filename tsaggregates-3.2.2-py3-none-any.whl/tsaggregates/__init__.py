# coding: utf-8

# flake8: noqa

"""
    IoT TS Aggregates API

     The aggregate service enables querying aggregated time series data including * aggregates generated on the fly * aggregates pre-calculated during ingest  Depending on, if entity is performance or simulation entity, different aggregation intervals are supported.  ### Performance Entity  Pre-calculated aggregates are available in the following intervals * 2 minute * 1 hour * 1 day  Intervals smaller than 2 minutes are also available and generated on the fly.   ### Simulation Entity  Pre-calculated aggregates are available in the following intervals * 1 millisecond * 10 millisecond * 1 second  On the fly aggregation is not supported for simulation entities.  Note: There might be time series data ingested in the past for which pre-calculated aggregates have not been computed. In that case for simulation entities, no aggregated data is returned.   # noqa: E501
"""


from __future__ import absolute_import

# import apis into sdk package
from tsaggregates.clients.aggregates_client import AggregatesClient


# import models into model package
from tsaggregates.models.aggregate import Aggregate
from tsaggregates.models.aggregates import Aggregates
from tsaggregates.models.badrequest import Badrequest
from tsaggregates.models.error import Error
from tsaggregates.models.get_aggregate_timeseries_request import GetAggregateTimeseriesRequest
from tsaggregates.models.notfound import Notfound
from tsaggregates.models.unauthorized import Unauthorized
