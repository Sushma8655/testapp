# coding: utf-8

"""
    IoT TS Aggregates API

     The aggregate service enables querying aggregated time series data including * aggregates generated on the fly * aggregates pre-calculated during ingest  Depending on, if entity is performance or simulation entity, different aggregation intervals are supported.  ### Performance Entity  Pre-calculated aggregates are available in the following intervals * 2 minute * 1 hour * 1 day  Intervals smaller than 2 minutes are also available and generated on the fly.   ### Simulation Entity  Pre-calculated aggregates are available in the following intervals * 1 millisecond * 10 millisecond * 1 second  On the fly aggregation is not supported for simulation entities.  Note: There might be time series data ingested in the past for which pre-calculated aggregates have not been computed. In that case for simulation entities, no aggregated data is returned.   # noqa: E501
"""


from __future__ import absolute_import

from mindsphere_core.mindsphere_core import logger
from mindsphere_core import mindsphere_core, exceptions, token_service
from mindsphere_core.token_service import init_credentials


class AggregatesClient:
    __base_path__ = '/api/iottsaggregates/v3'
    __model_package__ = __name__.split('.')[0]

    def __init__(self, rest_client_config=None, mindsphere_credentials=None):
        self.rest_client_config = rest_client_config
        self.mindsphere_credentials = init_credentials(mindsphere_credentials)

    def get_aggregate_timeseries(self, request_object):
        """read aggregated time series

        Read time series data aggregated over a certain interval for a single entity and propertyset within the provided time range. 

        :param GetAggregateTimeseriesRequest request_object: It contains the below parameters --> |br| ( entity* - Unique identifier of the entity. ), |br| ( propertyset* - Name of the propertyset. ), |br| ( from* - Beginning of the time range to read. ), |br| ( to* - End of the time range to read. ), |br| ( intervalValue* - Interval duration for the aggregates in intervalUnits. ), |br| ( intervalUnit* - Interval duration unit for the aggregates. ), |br| ( select - Properties and fields to select. By default all properties and the availale fields are returned. Providing a property name selects all fields of a property. A property name followed by a '.' and field name selects a specific field of a property. )

        :return: list[Aggregates]
        """
        logger.info('AggregatesClient.get_aggregate_timeseries() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `get_aggregate_timeseries`')

        if request_object.entity is None:
            raise exceptions.MindsphereClientError('The required parameter `entity` is missing from `request_object`, when calling `get_aggregate_timeseries`')

        if request_object.propertyset is None:
            raise exceptions.MindsphereClientError('The required parameter `propertyset` is missing from `request_object`, when calling `get_aggregate_timeseries`')

        if request_object._from is None:
            raise exceptions.MindsphereClientError('The required parameter `from` is missing from `request_object`, when calling `get_aggregate_timeseries`')

        if request_object.to is None:
            raise exceptions.MindsphereClientError('The required parameter `to` is missing from `request_object`, when calling `get_aggregate_timeseries`')

        if request_object.interval_value is None:
            raise exceptions.MindsphereClientError('The required parameter `intervalValue` is missing from `request_object`, when calling `get_aggregate_timeseries`')

        if request_object.interval_unit is None:
            raise exceptions.MindsphereClientError('The required parameter `intervalUnit` is missing from `request_object`, when calling `get_aggregate_timeseries`')

        end_point_url = '/aggregates/{entity}/{propertyset}'
        end_point_url = end_point_url.format(entity=request_object.entity, propertyset=request_object.propertyset)
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + str(token)}
        query_params = {'from': request_object._from, 'to': request_object.to, 'intervalValue': request_object.interval_value, 'intervalUnit': request_object.interval_unit, 'select': request_object.select}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info('AggregatesClient.get_aggregate_timeseries()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'GET', query_params, form_params, body_params, local_var_files, 'list[Aggregates]', self.__model_package__)

