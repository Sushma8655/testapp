# coding: utf-8

"""
    IoT TS Aggregates API

     The aggregate service enables querying aggregated time series data including * aggregates generated on the fly * aggregates pre-calculated during ingest  Depending on, if entity is performance or simulation entity, different aggregation intervals are supported.  ### Performance Entity  Pre-calculated aggregates are available in the following intervals * 2 minute * 1 hour * 1 day  Intervals smaller than 2 minutes are also available and generated on the fly.   ### Simulation Entity  Pre-calculated aggregates are available in the following intervals * 1 millisecond * 10 millisecond * 1 second  On the fly aggregation is not supported for simulation entities.  Note: There might be time series data ingested in the past for which pre-calculated aggregates have not been computed. In that case for simulation entities, no aggregated data is returned.   # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class GetAggregateTimeseriesRequest(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'select': 'str',
        'propertyset': 'str',
        'interval_unit': 'str',
        '_from': 'str',
        'to': 'str',
        'entity': 'str',
        'interval_value': 'float'
    }

    attribute_map = {
        'select': 'select',
        'propertyset': 'propertyset',
        'interval_unit': 'intervalUnit',
        '_from': 'from',
        'to': 'to',
        'entity': 'entity',
        'interval_value': 'intervalValue'
    }

    def __init__(self, select=None, propertyset=None, interval_unit=None, _from=None, to=None, entity=None, interval_value=None):
        self._select = select
        self._propertyset = propertyset
        self._interval_unit = interval_unit
        self.__from = _from
        self._to = to
        self._entity = entity
        self._interval_value = interval_value
        self.discriminator = None

    @property
    def select(self):
        """Gets the select of this GetAggregateTimeseriesRequest.

        :return: The select of this GetAggregateTimeseriesRequest.
        :rtype: str
        """
        return self._select

    @select.setter
    def select(self, select):
        """Sets the select of this GetAggregateTimeseriesRequest.

        :param select: The select of this GetAggregateTimeseriesRequest.
        :type: str
        """

        self._select = select

    @property
    def propertyset(self):
        """Gets the propertyset of this GetAggregateTimeseriesRequest.

        :return: The propertyset of this GetAggregateTimeseriesRequest.
        :rtype: str
        """
        return self._propertyset

    @propertyset.setter
    def propertyset(self, propertyset):
        """Sets the propertyset of this GetAggregateTimeseriesRequest.

        :param propertyset: The propertyset of this GetAggregateTimeseriesRequest.
        :type: str
        """

        self._propertyset = propertyset

    @property
    def interval_unit(self):
        """Gets the interval_unit of this GetAggregateTimeseriesRequest.

        :return: The interval_unit of this GetAggregateTimeseriesRequest.
        :rtype: str
        """
        return self._interval_unit

    @interval_unit.setter
    def interval_unit(self, interval_unit):
        """Sets the interval_unit of this GetAggregateTimeseriesRequest.

        :param interval_unit: The interval_unit of this GetAggregateTimeseriesRequest.
        :type: str
        """

        self._interval_unit = interval_unit

    @property
    def _from(self):
        """Gets the _from of this GetAggregateTimeseriesRequest.

        :return: The _from of this GetAggregateTimeseriesRequest.
        :rtype: str
        """
        return self.__from

    @_from.setter
    def _from(self, _from):
        """Sets the _from of this GetAggregateTimeseriesRequest.

        :param _from: The _from of this GetAggregateTimeseriesRequest.
        :type: str
        """

        self.__from = _from

    @property
    def to(self):
        """Gets the to of this GetAggregateTimeseriesRequest.

        :return: The to of this GetAggregateTimeseriesRequest.
        :rtype: str
        """
        return self._to

    @to.setter
    def to(self, to):
        """Sets the to of this GetAggregateTimeseriesRequest.

        :param to: The to of this GetAggregateTimeseriesRequest.
        :type: str
        """

        self._to = to

    @property
    def entity(self):
        """Gets the entity of this GetAggregateTimeseriesRequest.

        :return: The entity of this GetAggregateTimeseriesRequest.
        :rtype: str
        """
        return self._entity

    @entity.setter
    def entity(self, entity):
        """Sets the entity of this GetAggregateTimeseriesRequest.

        :param entity: The entity of this GetAggregateTimeseriesRequest.
        :type: str
        """

        self._entity = entity

    @property
    def interval_value(self):
        """Gets the interval_value of this GetAggregateTimeseriesRequest.

        :return: The interval_value of this GetAggregateTimeseriesRequest.
        :rtype: float
        """
        return self._interval_value

    @interval_value.setter
    def interval_value(self, interval_value):
        """Sets the interval_value of this GetAggregateTimeseriesRequest.

        :param interval_value: The interval_value of this GetAggregateTimeseriesRequest.
        :type: float
        """

        self._interval_value = interval_value

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(GetAggregateTimeseriesRequest, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, GetAggregateTimeseriesRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
