class MindsphereError(Exception):
    """Base class for mindspshere exceptions."""

    def __init__(self, message, error=None, http_status=None, log_ref=None):
        self.message = message
        self.error = error
        self.http_status = http_status
        self.log_ref = log_ref


class MindsphereClientError(MindsphereError):
    """Class for exceptions raised during
    any error caused by client input.
    """

    pass


class MindsphereServerError(MindsphereError):
    """Class for exceptions raised during
    any error received from api server.
    """

    pass


class MindsphereClientConfigurationError(MindsphereClientError):
    """Class for exceptions raised because
    of any incorrect/missing client configuration.
    """

    pass


class MindsphereForbiddenAccessError(MindsphereClientError):
    """Class for exceptions raised during
    any authorization error.
    """

    pass
