from .commonutil import append_bearer


class AppCredentials:
    """
    This class allows to configure app credentials.
    """

    def __init__(
        self,
        app_name=None,
        app_version=None,
        key_store_client_id=None,
        key_store_client_secret=None,
        host_tenant=None,
        user_tenant=None,
        authorization=None
    ):
        """
        app_name : str
            Application name
        app_version : str
            Application version
        key_store_client_id : str
            Key store client Id
        key_store_client_secret : str
            Key store client Secret
        host_tenant : str
            Host Tenant
        user_tenant : str
            User tenant name
        """
        self.app_name = app_name
        self.app_version = app_version
        self.key_store_client_id = key_store_client_id
        self.key_store_client_secret = key_store_client_secret
        self.host_tenant = host_tenant
        self.user_tenant = user_tenant
        self.authorization = authorization
        self._cached_token = None

    @property
    def cached_token(self):
        return self._cached_token

    @cached_token.setter
    def cached_token(self, cached_token):
        self._cached_token = cached_token


class TenantCredentials:
    """
    This class allows to configure tenant credentials.
    """

    def __init__(
        self,
        client_id=None,
        client_secret=None,
        tenant=None,
        sub_tenant=None,
        use_sub_tenant=None,
    ):
        """
        client_id : str
            Client Id
        client_secret : str
            Client secret
        tenant : str
            Tenant name
        sub_tenant : str
            Sub tenant name
        use_sub_tenant : bool
            Boolean to indicate if subtenant
            will be used to get token
        """
        self.client_id = client_id
        self.client_secret = client_secret
        self.tenant = tenant
        self.sub_tenant = sub_tenant
        self.use_sub_tenant = use_sub_tenant
        self._cached_token = None

    @property
    def cached_token(self):
        return self._cached_token

    @cached_token.setter
    def cached_token(self, cached_token):
        self._cached_token = cached_token


class UserToken:
    """
    This class allows to configure User token.
    """

    def __init__(
        self,
        authorization=None
    ):
        """
        authorization : str
            Authorization token
        """
        self.authorization = append_bearer(authorization)

