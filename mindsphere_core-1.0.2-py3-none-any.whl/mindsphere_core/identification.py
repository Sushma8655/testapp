# coding: utf-8

"""
    Technical Token Manager API

    This API provides operations to manage your access to customer IoT data. The operations return a Technical Token, which gives access to the tenant's IoT data.  # noqa: E501
"""


import pprint
import re  


import six
from mindsphere_core.exceptions import MindsphereClientError


class Identification(object):


    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'app_name': 'str',
        'app_version': 'str',
        'host_tenant': 'str',
        'user_tenant': 'str'
    }

    attribute_map = {
        'app_name': 'appName',
        'app_version': 'appVersion',
        'host_tenant': 'hostTenant',
        'user_tenant': 'userTenant'
    }

    def __init__(self, app_name=None, app_version=None, host_tenant=None, user_tenant=None):
        self._app_name = app_name
        self._app_version = app_version
        self._host_tenant = host_tenant
        self._user_tenant = user_tenant
        self.discriminator = None

    @property
    def app_name(self):
        """Gets the app_name of this Identification.
        Name of the application from Operator/Developer Cockpit

        :return: The app_name of this Identification.  
        :rtype: str
        """
        return self._app_name

    @app_name.setter
    def app_name(self, app_name):
        """Sets the app_name of this Identification.
        Name of the application from Operator/Developer Cockpit

        :param app_name: The app_name of this Identification.
        :type: str
        """

        self._app_name = app_name

    @property
    def app_version(self):
        """Gets the app_version of this Identification.
        Version of the application as given in Operation/Developer Cockpit.

        :return: The app_version of this Identification.  
        :rtype: str
        """
        return self._app_version

    @app_version.setter
    def app_version(self, app_version):
        """Sets the app_version of this Identification.
        Version of the application as given in Operation/Developer Cockpit.

        :param app_version: The app_version of this Identification.
        :type: str
        """

        self._app_version = app_version

    @property
    def host_tenant(self):
        """Gets the host_tenant of this Identification.
        Tenant ID of the developer/operator tenant hosting the application.

        :return: The host_tenant of this Identification.  
        :rtype: str
        """
        return self._host_tenant

    @host_tenant.setter
    def host_tenant(self, host_tenant):
        """Sets the host_tenant of this Identification.
        Tenant ID of the developer/operator tenant hosting the application.

        :param host_tenant: The host_tenant of this Identification.
        :type: str
        """

        self._host_tenant = host_tenant

    @property
    def user_tenant(self):
        """Gets the user_tenant of this Identification.
        Tenant ID of the tenant owning the data to be accessed with the Technical Token.

        :return: The user_tenant of this Identification.  
        :rtype: str
        """
        return self._user_tenant

    @user_tenant.setter
    def user_tenant(self, user_tenant):
        """Sets the user_tenant of this Identification.
        Tenant ID of the tenant owning the data to be accessed with the Technical Token.

        :param user_tenant: The user_tenant of this Identification.
        :type: str
        """

        self._user_tenant = user_tenant

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(Identification, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, Identification):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
