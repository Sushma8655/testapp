import logging
import logging.config

default_config = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "simple": {"format": "%(message)s"},
        "extended": {
            "format": "%(asctime)s - %(name)20s - %(levelname)6s - %(message)s"
        },
        "json": {
            "format": "name: %(name)s, level: %(levelname)s, time: %(asctime)s, message: %(message)s"
        },
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "level": "INFO",
            "formatter": "extended",
            "stream": "ext://sys.stdout",
        }
    },
    "loggers": {
        # Fine-grained logging configuration for individual modules or classes
        # Use this to set different log levels without changing 'real' code.
        "my_classes": {"level": "DEBUG", "propagate": True},
        "client_messages": {
            "level": "INFO",
            "propagate": True,
            "handlers": ["console"],
        },
    },
    "root": {
        # Set the level here to be the default
        #  minimum level of log record to be produced
        # If you set a handler to level DEBUG you will
        # need to set either this level, or
        # the level of one of the
        # loggers above to DEBUG
        # or you won't see any DEBUG messages
        "level": "INFO",
        "handlers": ["console"],
    },
}


def default_logging():
    """
    Default config : using  logging.StreamHandler
    class for handler and level : INFO and formatter : extended
    :return:
    """
    if default_config is not None:
        logging.config.dictConfig(default_config)
        logger = logging.getLogger()
        return logger


def setup_logging(level=logging.INFO, format="%(message)s"):
    """
        setup logging : using  logging.StreamHandler
        class as default for handler, level : custom and formatter : custom
    :return:
    """
    loggers = logging.getLogger()
    loggers.setLevel(level)
    handler = logging.StreamHandler()
    handler.setLevel(level)
    formatter = logging.Formatter(format)
    handler.setFormatter(formatter)
    loggers.addHandler(handler)
    return loggers
