# common Values
TENANT = "mdspsdk"
CLIENT_ID = "technical-user-mdspsdk"
CLIENT_ID_SUB_TENANT = "mdspsdk-tech-usr"
CLIENT_SECRET = ""
CLIENT_SECRET_SUB_TENANT = ""
SUB_TENANT = "sdktenant"
# SUB_TENANT = 'SDKSubTenant'

# Asset client
ASSET_CLIENT_OLD_PARENT_ID1 = "0ba09fbe8bad486893125b1156aa2eaa"
ASSET_CLIENT_OLD_PARENT_ID2 = "c867c8bc0c024c1080d42a6be7f49974"
ASSET_CLIENT_ASSET_TYPE = "mdspsdk.Tyre"
ASSET_CLIENT_FILE_ID = "876dcbc2381c49dd8026f23f9c608309"

# Aspect type client
ASPECT_CLIENT_ID = "mdspsdk.TemperatureAndPressure"
ASPECT_CLIENT_NAME = "TemperatureAndPressure"

# Asset type client
ASSET_TYPE_CLIENT_ID = "mdspsdk.Tyre"
ASSET_TYPE_CLIENT_PARENT_TYPE_ID = "core.basicasset"
ASSET_TYPE_CLIENT_ASPECT_NAME = "Temperature71015"
ASSET_TYPE_CLIENT_ASPECT_ID = "mdspsdk.Temperature71015"

# Asset Location client
ASSET_LOCATION_CLIENT_ID = "078b1908bc9347678168760934465587"

# Asset file client
ASSET_FILE_CLIENT_FILE_ID = "6e25330e9b634f6b9d4e8df5be62ed93"
