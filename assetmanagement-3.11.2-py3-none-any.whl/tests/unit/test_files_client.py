# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


from __future__ import absolute_import

import unittest
from unittest.mock import MagicMock
from assetmanagement.clients import FilesClient
from assetmanagement.models import *
from tests.unit.test_util import TestUtil, MOCK_VALUE, MOCK_SUCCESS
from mindsphere_core.exceptions import MindsphereError
from mindsphere_core import TenantCredentials, mindsphere_core, token_service


class FilesClientUnitTest(unittest.TestCase):
    """FilesClient unit test stubs"""

    def setUp(self):
        credentials = TenantCredentials(client_id=MOCK_VALUE, client_secret=MOCK_VALUE, tenant=MOCK_VALUE)
        config = mindsphere_core.RestClientConfig(MOCK_VALUE, MOCK_VALUE)
        self.client = FilesClient(config, credentials)
        token_service._invoke_token_endpoint = MagicMock(return_value=MOCK_SUCCESS)

    def test_delete_file(self):
        """Test case for delete_file
        Delete a file.
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = DeleteFileRequest()
        request_object.if_match = TestUtil.get_mock_data(package_name, "str")
        request_object.file_id = TestUtil.get_mock_data(package_name, "str")
        response = self.client.delete_file(request_object)
        self.assertEqual(200, response)

    def test_negative_delete_file(self):
        """Negative test case for delete_file
        Delete a file.
        """
        request_object = DeleteFileRequest()
        with self.assertRaises(MindsphereError):
            self.client.delete_file(request_object)

    def test_negative_request_delete_file(self):
        """Negative test case for delete_file
        Delete a file.
        """
        with self.assertRaises(MindsphereError):
            self.client.delete_file(None)

    def test_download_file(self):
        """Test case for download_file
        Returns a file by its id
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = DownloadFileRequest()
        request_object.file_id = TestUtil.get_mock_data(package_name, "str")
        response = self.client.download_file(request_object)
        self.assertEqual(200, response)

    def test_negative_download_file(self):
        """Negative test case for download_file
        Returns a file by its id
        """
        request_object = DownloadFileRequest()
        with self.assertRaises(MindsphereError):
            self.client.download_file(request_object)

    def test_negative_request_download_file(self):
        """Negative test case for download_file
        Returns a file by its id
        """
        with self.assertRaises(MindsphereError):
            self.client.download_file(None)

    def test_get_file(self):
        """Test case for get_file
        Returns a file's metadata by its id
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = GetFileRequest()
        request_object.file_id = TestUtil.get_mock_data(package_name, "str")
        response = self.client.get_file(request_object)
        self.assertEqual(200, response)

    def test_negative_get_file(self):
        """Negative test case for get_file
        Returns a file's metadata by its id
        """
        request_object = GetFileRequest()
        with self.assertRaises(MindsphereError):
            self.client.get_file(request_object)

    def test_negative_request_get_file(self):
        """Negative test case for get_file
        Returns a file's metadata by its id
        """
        with self.assertRaises(MindsphereError):
            self.client.get_file(None)

    def test_list_files(self):
        """Test case for list_files
        Get metadata of uploaded files.
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = ListFilesRequest()
        response = self.client.list_files(request_object)
        self.assertEqual(200, response)

    def test_replace_file(self):
        """Test case for replace_file
        Update a file
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = ReplaceFileRequest()
        request_object.if_match = TestUtil.get_mock_data(package_name, "str")
        request_object.file_id = TestUtil.get_mock_data(package_name, "str")
        request_object.file = TestUtil.get_mock_data(package_name, "file")
        request_object.name = TestUtil.get_mock_data(package_name, "str")
        request_object.scope = TestUtil.get_mock_data(package_name, "str")
        response = self.client.replace_file(request_object)
        self.assertEqual(200, response)

    def test_negative_replace_file(self):
        """Negative test case for replace_file
        Update a file
        """
        request_object = ReplaceFileRequest()
        with self.assertRaises(MindsphereError):
            self.client.replace_file(request_object)

    def test_negative_request_replace_file(self):
        """Negative test case for replace_file
        Update a file
        """
        with self.assertRaises(MindsphereError):
            self.client.replace_file(None)

    def test_upload_file(self):
        """Test case for upload_file
        Upload files to be used in Asset Management.
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = UploadFileRequest()
        request_object.file = TestUtil.get_mock_data(package_name, "file")
        request_object.name = TestUtil.get_mock_data(package_name, "str")
        response = self.client.upload_file(request_object)
        self.assertEqual(200, response)

    def test_negative_upload_file(self):
        """Negative test case for upload_file
        Upload files to be used in Asset Management.
        """
        request_object = UploadFileRequest()
        with self.assertRaises(MindsphereError):
            self.client.upload_file(request_object)

    def test_negative_request_upload_file(self):
        """Negative test case for upload_file
        Upload files to be used in Asset Management.
        """
        with self.assertRaises(MindsphereError):
            self.client.upload_file(None)


if __name__ == '__main__':
    unittest.main()
