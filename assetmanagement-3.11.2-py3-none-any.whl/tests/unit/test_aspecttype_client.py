# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


from __future__ import absolute_import

import unittest
from unittest.mock import MagicMock
from assetmanagement.clients import AspecttypeClient
from assetmanagement.models import *
from tests.unit.test_util import TestUtil, MOCK_VALUE, MOCK_SUCCESS
from mindsphere_core.exceptions import MindsphereError
from mindsphere_core import TenantCredentials, mindsphere_core, token_service
from assetmanagement.models.field_type_enum import FieldTypeEnum


class AspecttypeClientUnitTest(unittest.TestCase):
    """AspecttypeClient unit test stubs"""

    def setUp(self):
        credentials = TenantCredentials(client_id=MOCK_VALUE, client_secret=MOCK_VALUE, tenant=MOCK_VALUE)
        config = mindsphere_core.RestClientConfig(MOCK_VALUE, MOCK_VALUE)
        self.client = AspecttypeClient(config, credentials)
        token_service._invoke_token_endpoint = MagicMock(return_value=MOCK_SUCCESS)

    def test_delete_aspect_type(self):
        """Test case for delete_aspect_type
        Delete aspect type
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = DeleteAspectTypeRequest()
        request_object.if_match = TestUtil.get_mock_data(package_name, "str")
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        response = self.client.delete_aspect_type(request_object)
        self.assertEqual(200, response)

    def test_negative_delete_aspect_type(self):
        """Negative test case for delete_aspect_type
        Delete aspect type
        """
        request_object = DeleteAspectTypeRequest()
        with self.assertRaises(MindsphereError):
            self.client.delete_aspect_type(request_object)

    def test_negative_request_delete_aspect_type(self):
        """Negative test case for delete_aspect_type
        Delete aspect type
        """
        with self.assertRaises(MindsphereError):
            self.client.delete_aspect_type(None)

    def test_get_aspect_type(self):
        """Test case for get_aspect_type
        Read an aspect type
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = GetAspectTypeRequest()
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        response = self.client.get_aspect_type(request_object)
        self.assertEqual(200, response)

    def test_negative_get_aspect_type(self):
        """Negative test case for get_aspect_type
        Read an aspect type
        """
        request_object = GetAspectTypeRequest()
        with self.assertRaises(MindsphereError):
            self.client.get_aspect_type(request_object)

    def test_negative_request_get_aspect_type(self):
        """Negative test case for get_aspect_type
        Read an aspect type
        """
        with self.assertRaises(MindsphereError):
            self.client.get_aspect_type(None)

    def test_list_aspect_types(self):
        """Test case for list_aspect_types
        List all aspect types
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = ListAspectTypesRequest()
        response = self.client.list_aspect_types(request_object)
        self.assertEqual(200, response)

    def test_save_aspect_type(self):
        """Test case for save_aspect_type
        Create or Update an aspect type
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = SaveAspectTypeRequest()
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        request_object.aspecttype = TestUtil.get_mock_data(package_name, "AspectType")
        response = self.client.save_aspect_type(request_object)
        self.assertEqual(200, response)

    def test_negative_save_aspect_type(self):
        """Negative test case for save_aspect_type
        Create or Update an aspect type
        """
        request_object = SaveAspectTypeRequest()
        with self.assertRaises(MindsphereError):
            self.client.save_aspect_type(request_object)

    def test_negative_request_save_aspect_type(self):
        """Negative test case for save_aspect_type
        Create or Update an aspect type
        """
        with self.assertRaises(MindsphereError):
            self.client.save_aspect_type(None)

    def test_update_aspect_type(self):
        """Test case for update_aspect_type
        Patch an aspect type
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = UpdateAspectTypeRequest()
        request_object.if_match = TestUtil.get_mock_data(package_name, "str")
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        request_object.aspecttype = TestUtil.get_mock_data(package_name, "AspectType")
        response = self.client.update_aspect_type(request_object)
        self.assertEqual(200, response)

    def test_negative_update_aspect_type(self):
        """Negative test case for update_aspect_type
        Patch an aspect type
        """
        request_object = UpdateAspectTypeRequest()
        with self.assertRaises(MindsphereError):
            self.client.update_aspect_type(request_object)

    def test_negative_request_update_aspect_type(self):
        """Negative test case for update_aspect_type
        Patch an aspect type
        """
        with self.assertRaises(MindsphereError):
            self.client.update_aspect_type(None)

    def test_get_aspect_types_equals_to(self):
        """
        Test case for get_aspect_types_equals_to
        """
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        response = self.client.get_aspect_types_equals_to(FieldTypeEnum.NAME, "mock")
        self.assertEqual(200, response)

    def test_negative_get_aspect_types_equals_to(self):
        """
        Negative test case for get_aspect_types_equals_to
        """
        with self.assertRaises(MindsphereError):
            self.client.get_aspect_types_equals_to(FieldTypeEnum.ASSET_ID, "mock")

    def test_get_aspect_type_name_like(self):
        """
        Test case for get_aspect_types_like
        """
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        response = self.client.get_aspect_types_like(FieldTypeEnum.NAME, "mock")
        self.assertEqual(200, response)

    def test_aspect_types_starts_with(self):
        """
        Test case for aspect_types_starts_with
        """
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        response = self.client.get_aspect_types_starts_with(FieldTypeEnum.NAME, "mock")
        self.assertEqual(200, response)

    def test_get_aspect_types_ends_with(self):
        """
        Test case for get_aspect_types_ends_with
        """
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        response = self.client.get_aspect_types_ends_with(FieldTypeEnum.NAME, "mock")
        self.assertEqual(200, response)

    def test_get_aspect_types_contains(self):
        """
        Test case for get_aspect_types_ends_with
        """
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        response = self.client.get_aspect_types_contains(FieldTypeEnum.TENANT_ID, "mock")
        self.assertEqual(200, response)


if __name__ == '__main__':
    unittest.main()
