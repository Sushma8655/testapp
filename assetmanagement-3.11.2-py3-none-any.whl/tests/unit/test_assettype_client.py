# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


from __future__ import absolute_import

import unittest
from unittest.mock import MagicMock
from assetmanagement.clients import AssettypeClient
from assetmanagement.models import *
from tests.unit.test_util import TestUtil, MOCK_VALUE, MOCK_SUCCESS
from mindsphere_core.exceptions import MindsphereError
from mindsphere_core import TenantCredentials, mindsphere_core, token_service
from assetmanagement.models.field_type_enum import FieldTypeEnum


class AssettypeClientUnitTest(unittest.TestCase):
    """AssettypeClient unit test stubs"""

    def setUp(self):
        credentials = TenantCredentials(client_id=MOCK_VALUE, client_secret=MOCK_VALUE, tenant=MOCK_VALUE)
        config = mindsphere_core.RestClientConfig(MOCK_VALUE, MOCK_VALUE)
        self.client = AssettypeClient(config, credentials)
        token_service._invoke_token_endpoint = MagicMock(return_value=MOCK_SUCCESS)

    def test_delete_asset_type(self):
        """Test case for delete_asset_type
        Delete an asset type
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = DeleteAssetTypeRequest()
        request_object.if_match = TestUtil.get_mock_data(package_name, "str")
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        response = self.client.delete_asset_type(request_object)
        self.assertEqual(200, response)

    def test_negative_delete_asset_type(self):
        """Negative test case for delete_asset_type
        Delete an asset type
        """
        request_object = DeleteAssetTypeRequest()
        with self.assertRaises(MindsphereError):
            self.client.delete_asset_type(request_object)

    def test_negative_request_delete_asset_type(self):
        """Negative test case for delete_asset_type
        Delete an asset type
        """
        with self.assertRaises(MindsphereError):
            self.client.delete_asset_type(None)

    def test_delete_asset_type_file_assignment(self):
        """Test case for delete_asset_type_file_assignment
        Deletes a file assignment from an asset type
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = DeleteAssetTypeFileAssignmentRequest()
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        request_object.key = TestUtil.get_mock_data(package_name, "str")
        request_object.if_match = TestUtil.get_mock_data(package_name, "str")
        response = self.client.delete_asset_type_file_assignment(request_object)
        self.assertEqual(200, response)

    def test_negative_delete_asset_type_file_assignment(self):
        """Negative test case for delete_asset_type_file_assignment
        Deletes a file assignment from an asset type
        """
        request_object = DeleteAssetTypeFileAssignmentRequest()
        with self.assertRaises(MindsphereError):
            self.client.delete_asset_type_file_assignment(request_object)

    def test_negative_request_delete_asset_type_file_assignment(self):
        """Negative test case for delete_asset_type_file_assignment
        Deletes a file assignment from an asset type
        """
        with self.assertRaises(MindsphereError):
            self.client.delete_asset_type_file_assignment(None)

    def test_get_asset_type(self):
        """Test case for get_asset_type
        Read an asset type
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = GetAssetTypeRequest()
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        response = self.client.get_asset_type(request_object)
        self.assertEqual(200, response)

    def test_negative_get_asset_type(self):
        """Negative test case for get_asset_type
        Read an asset type
        """
        request_object = GetAssetTypeRequest()
        with self.assertRaises(MindsphereError):
            self.client.get_asset_type(request_object)

    def test_negative_request_get_asset_type(self):
        """Negative test case for get_asset_type
        Read an asset type
        """
        with self.assertRaises(MindsphereError):
            self.client.get_asset_type(None)

    def test_list_asset_types(self):
        """Test case for list_asset_types
        List all asset types
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = ListAssetTypesRequest()
        response = self.client.list_asset_types(request_object)
        self.assertEqual(200, response)

    def test_save_asset_type(self):
        """Test case for save_asset_type
        Create or Update an asset type
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = SaveAssetTypeRequest()
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        request_object.assettype = TestUtil.get_mock_data(package_name, "AssetType")
        response = self.client.save_asset_type(request_object)
        self.assertEqual(200, response)

    def test_negative_save_asset_type(self):
        """Negative test case for save_asset_type
        Create or Update an asset type
        """
        request_object = SaveAssetTypeRequest()
        with self.assertRaises(MindsphereError):
            self.client.save_asset_type(request_object)

    def test_negative_request_save_asset_type(self):
        """Negative test case for save_asset_type
        Create or Update an asset type
        """
        with self.assertRaises(MindsphereError):
            self.client.save_asset_type(None)

    def test_save_asset_type_file_assignment(self):
        """Test case for save_asset_type_file_assignment
        Add a new file assignment to an asset type
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = SaveAssetTypeFileAssignmentRequest()
        request_object.if_match = TestUtil.get_mock_data(package_name, "str")
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        request_object.key = TestUtil.get_mock_data(package_name, "str")
        request_object.assignment = TestUtil.get_mock_data(package_name, "KeyedFileAssignment")
        response = self.client.save_asset_type_file_assignment(request_object)
        self.assertEqual(200, response)

    def test_negative_save_asset_type_file_assignment(self):
        """Negative test case for save_asset_type_file_assignment
        Add a new file assignment to an asset type
        """
        request_object = SaveAssetTypeFileAssignmentRequest()
        with self.assertRaises(MindsphereError):
            self.client.save_asset_type_file_assignment(request_object)

    def test_negative_request_save_asset_type_file_assignment(self):
        """Negative test case for save_asset_type_file_assignment
        Add a new file assignment to an asset type
        """
        with self.assertRaises(MindsphereError):
            self.client.save_asset_type_file_assignment(None)

    def test_update_asset_type(self):
        """Test case for update_asset_type
        Patch an asset type
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = UpdateAssetTypeRequest()
        request_object.if_match = TestUtil.get_mock_data(package_name, "str")
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        request_object.assettype = TestUtil.get_mock_data(package_name, "AssetType")
        response = self.client.update_asset_type(request_object)
        self.assertEqual(200, response)

    def test_negative_update_asset_type(self):
        """Negative test case for update_asset_type
        Patch an asset type
        """
        request_object = UpdateAssetTypeRequest()
        with self.assertRaises(MindsphereError):
            self.client.update_asset_type(request_object)

    def test_negative_request_update_asset_type(self):
        """Negative test case for update_asset_type
        Patch an asset type
        """
        with self.assertRaises(MindsphereError):
            self.client.update_asset_type(None)

    def test_get_asset_types_equal_to(self):
        """Test case for get_asset_types_equal_to
        """
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        response = self.client.get_asset_types_equals_to(FieldTypeEnum.NAME, "mock")
        self.assertEqual(200, response)

    def test_negative_get_asset_types_equal_to(self):
        """Negative test case for get_asset_types_equal_to
        """
        with self.assertRaises(MindsphereError):
            self.client.get_asset_types_equals_to(FieldTypeEnum.ASSET_ID, "mock")

    def test_get_asset_types_like(self):
        """Test case for get_asset_types_like
        """
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        response = self.client.get_asset_types_like(FieldTypeEnum.TENANT_ID, "mock")
        self.assertEqual(200, response)

    def test_negative_get_asset_type_like(self):
        """Negative test case for get_asset_types_like
        """
        with self.assertRaises(MindsphereError):
            self.client.get_asset_types_like(FieldTypeEnum.ASSET_ID, "mock")

    def test_get_asset_types_starts_with(self):
        """Test case for get_asset_types_starts_with
        """
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        response = self.client.get_asset_types_starts_with(FieldTypeEnum.PARENT_TYPE_ID, "mock")
        self.assertEqual(200, response)

    def test_negative_get_asset_types_starts_with(self):
        """Negative test case for get_asset_types_starts_with
        """
        with self.assertRaises(MindsphereError):
            self.client.get_asset_types_starts_with(FieldTypeEnum.ASSET_ID, "mock")

    def test_get_asset_types_ends_with(self):
        """Test case for get_asset_types_ends_with
        """
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        response = self.client.get_asset_types_ends_with(FieldTypeEnum.PARENT_TYPE_ID, "mock")
        self.assertEqual(200, response)

    def test_negative_get_asset_types_ends_with(self):
        """Negative test case for get_asset_types_ends_with
        """
        with self.assertRaises(MindsphereError):
            self.client.get_asset_types_ends_with(FieldTypeEnum.ASSET_ID, "mock")

    def test_get_asset_types_contains_with(self):
        """Test case for get_asset_types_contains_with
        """
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        response = self.client.get_asset_types_contains(FieldTypeEnum.PARENT_TYPE_ID, "mock")
        self.assertEqual(200, response)

    def test_negative_asset_types_contains_with(self):
        """Negative test case for get_asset_types_contains_with
        """
        with self.assertRaises(MindsphereError):
            self.client.get_asset_types_contains(FieldTypeEnum.ASSET_ID, "mock")


if __name__ == '__main__':
    unittest.main()
