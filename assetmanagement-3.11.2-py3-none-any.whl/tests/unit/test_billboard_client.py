# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


from __future__ import absolute_import

import unittest
from unittest.mock import MagicMock
from assetmanagement.clients import BillboardClient
from assetmanagement.models import *
from tests.unit.test_util import TestUtil, MOCK_VALUE, MOCK_SUCCESS
from mindsphere_core.exceptions import MindsphereError
from mindsphere_core import TenantCredentials, mindsphere_core, token_service


class BillboardClientUnitTest(unittest.TestCase):
    """BillboardClient unit test stubs"""

    def setUp(self):
        credentials = TenantCredentials(client_id=MOCK_VALUE, client_secret=MOCK_VALUE, tenant=MOCK_VALUE)
        config = mindsphere_core.RestClientConfig(MOCK_VALUE, MOCK_VALUE)
        self.client = BillboardClient(config, credentials)
        token_service._invoke_token_endpoint = MagicMock(return_value=MOCK_SUCCESS)

    def test_get_billboard(self):
        """Test case for get_billboard
        List all links for available resources
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = GetBillboardRequest()
        response = self.client.get_billboard()
        self.assertEqual(200, response)


if __name__ == '__main__':
    unittest.main()
