# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


from __future__ import absolute_import

import unittest
from unittest.mock import MagicMock
from assetmanagement.clients import AssetsClient
from assetmanagement.models import *
from tests.unit.test_util import TestUtil, MOCK_VALUE, MOCK_SUCCESS
from mindsphere_core.exceptions import MindsphereError
from mindsphere_core import TenantCredentials, mindsphere_core, token_service
from assetmanagement.models.field_type_enum import FieldTypeEnum
from assetmanagement.models.delete_asset_confirmation_request import DeleteAssetConfirmationRequest


class AssetsClientUnitTest(unittest.TestCase):
    """AssetsClient unit test stubs"""

    def setUp(self):
        credentials = TenantCredentials(client_id=MOCK_VALUE, client_secret=MOCK_VALUE, tenant=MOCK_VALUE)
        config = mindsphere_core.RestClientConfig(MOCK_VALUE, MOCK_VALUE)
        self.client = AssetsClient(config, credentials)
        token_service._invoke_token_endpoint = MagicMock(return_value=MOCK_SUCCESS)

    def test_add_asset(self):
        """Test case for add_asset
        Create an asset
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = AddAssetRequest()
        request_object.asset = TestUtil.get_mock_data(package_name, "Asset")
        response = self.client.add_asset(request_object)
        self.assertEqual(200, response)

    def test_negative_add_asset(self):
        """Negative test case for add_asset
        Create an asset
        """
        request_object = AddAssetRequest()
        with self.assertRaises(MindsphereError):
            self.client.add_asset(request_object)

    def test_negative_request_add_asset(self):
        """Negative test case for add_asset
        Create an asset
        """
        with self.assertRaises(MindsphereError):
            self.client.add_asset(None)

    def test_delete_asset(self):
        """Test case for delete_asset
        Delete an asset
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = DeleteAssetRequest()
        request_object.if_match = TestUtil.get_mock_data(package_name, "str")
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        response = self.client.delete_asset(request_object)
        self.assertEqual(200, response)

    def test_negative_delete_asset(self):
        """Negative test case for delete_asset
        Delete an asset
        """
        request_object = DeleteAssetRequest()
        with self.assertRaises(MindsphereError):
            self.client.delete_asset(request_object)

    def test_negative_request_delete_asset(self):
        """Negative test case for delete_asset
        Delete an asset
        """
        with self.assertRaises(MindsphereError):
            self.client.delete_asset(None)

    def test_delete_asset_file_assigment(self):
        """Test case for delete_asset_file_assigment
        Deletes a file assignment from an asset
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = DeleteAssetFileAssigmentRequest()
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        request_object.key = TestUtil.get_mock_data(package_name, "str")
        request_object.if_match = TestUtil.get_mock_data(package_name, "str")
        response = self.client.delete_asset_file_assigment(request_object)
        self.assertEqual(200, response)

    def test_negative_delete_asset_file_assigment(self):
        """Negative test case for delete_asset_file_assigment
        Deletes a file assignment from an asset
        """
        request_object = DeleteAssetFileAssigmentRequest()
        with self.assertRaises(MindsphereError):
            self.client.delete_asset_file_assigment(request_object)

    def test_negative_request_delete_asset_file_assigment(self):
        """Negative test case for delete_asset_file_assigment
        Deletes a file assignment from an asset
        """
        with self.assertRaises(MindsphereError):
            self.client.delete_asset_file_assigment(None)

    def test_get_asset(self):
        """Test case for get_asset
        Returns an asset.
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = GetAssetRequest()
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        response = self.client.get_asset(request_object)
        self.assertEqual(200, response)

    def test_negative_get_asset(self):
        """Negative test case for get_asset
        Returns an asset.
        """
        request_object = GetAssetRequest()
        with self.assertRaises(MindsphereError):
            self.client.get_asset(request_object)

    def test_negative_request_get_asset(self):
        """Negative test case for get_asset
        Returns an asset.
        """
        with self.assertRaises(MindsphereError):
            self.client.get_asset(None)

    def test_get_root_asset(self):
        """Test case for get_root_asset
        Returns the root asset of the user.
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = GetRootAssetRequest()
        response = self.client.get_root_asset(request_object)
        self.assertEqual(200, response)

    def test_list_assets(self):
        """Test case for list_assets
        List all available assets
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = ListAssetsRequest()
        response = self.client.list_assets(request_object)
        self.assertEqual(200, response)

    def test_move_asset(self):
        """Test case for move_asset
        Move an asset
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = MoveAssetRequest()
        request_object.if_match = TestUtil.get_mock_data(package_name, "str")
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        request_object.move_parameters = TestUtil.get_mock_data(package_name, "AssetMove")
        response = self.client.move_asset(request_object)
        self.assertEqual(200, response)

    def test_negative_move_asset(self):
        """Negative test case for move_asset
        Move an asset
        """
        request_object = MoveAssetRequest()
        with self.assertRaises(MindsphereError):
            self.client.move_asset(request_object)

    def test_negative_request_move_asset(self):
        """Negative test case for move_asset
        Move an asset
        """
        with self.assertRaises(MindsphereError):
            self.client.move_asset(None)

    def test_replace_asset(self):
        """Test case for replace_asset
        Update an asset
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = ReplaceAssetRequest()
        request_object.if_match = TestUtil.get_mock_data(package_name, "str")
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        request_object.asset = TestUtil.get_mock_data(package_name, "AssetUpdate")
        response = self.client.replace_asset(request_object)
        self.assertEqual(200, response)

    def test_negative_replace_asset(self):
        """Negative test case for replace_asset
        Update an asset
        """
        request_object = ReplaceAssetRequest()
        with self.assertRaises(MindsphereError):
            self.client.replace_asset(request_object)

    def test_negative_request_replace_asset(self):
        """Negative test case for replace_asset
        Update an asset
        """
        with self.assertRaises(MindsphereError):
            self.client.replace_asset(None)

    def test_save_asset_file_assignment(self):
        """Test case for save_asset_file_assignment
        Save an file assignment to an asset
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = SaveAssetFileAssignmentRequest()
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        request_object.key = TestUtil.get_mock_data(package_name, "str")
        request_object.if_match = TestUtil.get_mock_data(package_name, "str")
        request_object.assignment = TestUtil.get_mock_data(package_name, "KeyedFileAssignment")
        response = self.client.save_asset_file_assignment(request_object)
        self.assertEqual(200, response)

    def test_negative_save_asset_file_assignment(self):
        """Negative test case for save_asset_file_assignment
        Save an file assignment to an asset
        """
        request_object = SaveAssetFileAssignmentRequest()
        with self.assertRaises(MindsphereError):
            self.client.save_asset_file_assignment(request_object)

    def test_negative_request_save_asset_file_assignment(self):
        """Negative test case for save_asset_file_assignment
        Save an file assignment to an asset
        """
        with self.assertRaises(MindsphereError):
            self.client.save_asset_file_assignment(None)

    def test_update_asset(self):
        """Test case for update_asset
        Patch an asset
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = UpdateAssetRequest()
        request_object.if_match = TestUtil.get_mock_data(package_name, "str")
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        request_object.asset = TestUtil.get_mock_data(package_name, "AssetUpdate")
        response = self.client.update_asset(request_object)
        self.assertEqual(200, response)

    def test_negative_update_asset(self):
        """Negative test case for update_asset
        Patch an asset
        """
        request_object = UpdateAssetRequest()
        with self.assertRaises(MindsphereError):
            self.client.update_asset(request_object)

    def test_negative_request_update_asset(self):
        """Negative test case for update_asset
        Patch an asset
        """
        with self.assertRaises(MindsphereError):
            self.client.update_asset(None)

    def test_asset_delete_confirmation(self):
        """
        delete asset confirmation
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=400)
        request_object = DeleteAssetConfirmationRequest()
        request_object.if_match = TestUtil.get_mock_data(package_name, "str")
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        response = self.client.delete_asset_with_confirmation(request_object)
        self.assertEqual(False, response)

    def test_get_assets_equals_to(self):
        """
        Test case for get_assets_equals_to
        """
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        response = self.client.get_assets_equals_to(FieldTypeEnum.NAME, "mock")
        self.assertEqual(200, response)

    def test_negative_get_assets_equals_to(self):
        """
        Negative test case for get_assets_equals_to
        """
        with self.assertRaises(MindsphereError):
            self.client.get_assets_equals_to(FieldTypeEnum.PARENT_TYPE_ID, "mock")

    def test_get_assets_name_like(self):
        """
        Test case for get_assets_like
        """
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        response = self.client.get_assets_like(FieldTypeEnum.PARENT_ID, "mock")
        self.assertEqual(200, response)

    def test_negative_get_assets_name_like(self):
        """
        Negative test case for get_assets_like
        """
        with self.assertRaises(MindsphereError):
            self.client.get_assets_like(FieldTypeEnum.PARENT_TYPE_ID, "mock")

    def test_assets_starts_with(self):
        """
        Test case for get_assets_starts_with
        """
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        response = self.client.get_assets_starts_with(FieldTypeEnum.EXTERNAL_ID, "mock")
        self.assertEqual(200, response)

    def test_negative_assets_starts_with(self):
        """
        Negative test case for get_assets_starts_with
        """
        with self.assertRaises(MindsphereError):
            self.client.get_assets_starts_with(FieldTypeEnum.PARENT_TYPE_ID, "mock")

    def test_get_assets_ends_with(self):
        """
        Test case for get_assets_ends_with
        """
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        response = self.client.get_assets_ends_with(FieldTypeEnum.DELETED, "mock")
        self.assertEqual(200, response)

    def test_negative_assets_ends_with(self):
        """
        Negative test case for get_assets_ends_with
        """
        with self.assertRaises(MindsphereError):
            self.client.get_assets_ends_with(FieldTypeEnum.PARENT_TYPE_ID, "mock")

    def test_get_assets_contains(self):
        """
        Test case for get_assets_contains
        """
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        response = self.client.get_assets_contains(FieldTypeEnum.SUBTENANT, "mock")
        self.assertEqual(200, response)

    def test_negative_assets_contains_with(self):
        """
        Negative test case for get_assets_ends_with
        """
        with self.assertRaises(MindsphereError):
            self.client.get_assets_contains(FieldTypeEnum.PARENT_TYPE_ID, "mock")

    def test_negative_assets_contains_with(self):
        """
        Negative test case for get_assets_contains
        """
        with self.assertRaises(MindsphereError):
            self.client.get_assets_contains(FieldTypeEnum.PARENT_TYPE_ID, "mock")

    def test_get_assets_contains_for_type_id(self):
        """
        Test case for get_assets_contains
        """
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        response = self.client.get_assets_contains(FieldTypeEnum.TYPE_ID, "mock")
        self.assertEqual(200, response)

    def test_get_assets_contains_for_tenant_id(self):
        """
        Test case for get_assets_contains
        """
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        response = self.client.get_assets_contains(FieldTypeEnum.TENANT_ID, "mock")
        self.assertEqual(200, response)

    def test_get_assets_contains_for_asset_id(self):
        """
        Test case for get_assets_contains
        """
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        response = self.client.get_assets_contains(FieldTypeEnum.ASSET_ID, "mock")
        self.assertEqual(200, response)

    def test_get_assets_type_id(self):
        """
        Test case for get_assets_type_id
        """
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        response = self.client.get_assets_of_type("mock")
        self.assertEqual(200, response)


if __name__ == '__main__':
    unittest.main()
