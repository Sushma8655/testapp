# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


from __future__ import absolute_import

import unittest
from unittest.mock import MagicMock
from assetmanagement.clients import LocationsClient
from assetmanagement.models import *
from tests.unit.test_util import TestUtil, MOCK_VALUE, MOCK_SUCCESS
from mindsphere_core.exceptions import MindsphereError
from mindsphere_core import TenantCredentials, mindsphere_core, token_service


class LocationsClientUnitTest(unittest.TestCase):
    """LocationsClient unit test stubs"""

    def setUp(self):
        credentials = TenantCredentials(client_id=MOCK_VALUE, client_secret=MOCK_VALUE, tenant=MOCK_VALUE)
        config = mindsphere_core.RestClientConfig(MOCK_VALUE, MOCK_VALUE)
        self.client = LocationsClient(config, credentials)
        token_service._invoke_token_endpoint = MagicMock(return_value=MOCK_SUCCESS)

    def test_delete_asset_location(self):
        """Test case for delete_asset_location
        Delete location assigned to given asset.
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = DeleteAssetLocationRequest()
        request_object.if_match = TestUtil.get_mock_data(package_name, "str")
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        response = self.client.delete_asset_location(request_object)
        self.assertEqual(200, response)

    def test_negative_delete_asset_location(self):
        """Negative test case for delete_asset_location
        Delete location assigned to given asset.
        """
        request_object = DeleteAssetLocationRequest()
        with self.assertRaises(MindsphereError):
            self.client.delete_asset_location(request_object)

    def test_negative_request_delete_asset_location(self):
        """Negative test case for delete_asset_location
        Delete location assigned to given asset.
        """
        with self.assertRaises(MindsphereError):
            self.client.delete_asset_location(None)

    def test_save_asset_location(self):
        """Test case for save_asset_location
        Create or Update location assigned to given asset
        """
        package_name = "assetmanagement.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = SaveAssetLocationRequest()
        request_object.if_match = TestUtil.get_mock_data(package_name, "str")
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        request_object.location = TestUtil.get_mock_data(package_name, "Location")
        response = self.client.save_asset_location(request_object)
        self.assertEqual(200, response)

    def test_negative_save_asset_location(self):
        """Negative test case for save_asset_location
        Create or Update location assigned to given asset
        """
        request_object = SaveAssetLocationRequest()
        with self.assertRaises(MindsphereError):
            self.client.save_asset_location(request_object)

    def test_negative_request_save_asset_location(self):
        """Negative test case for save_asset_location
        Create or Update location assigned to given asset
        """
        with self.assertRaises(MindsphereError):
            self.client.save_asset_location(None)


if __name__ == '__main__':
    unittest.main()
