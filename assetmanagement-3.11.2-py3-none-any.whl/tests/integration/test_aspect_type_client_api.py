import unittest
import random
from mindsphere_core import mindsphere_core
from assetmanagement.clients import AspecttypeClient
from assetmanagement.models import AspectType
from assetmanagement.models import SaveAspectTypeRequest
from assetmanagement.models import AspectVariable
from assetmanagement.models import GetAspectTypeRequest
from assetmanagement.models import UpdateAspectTypeRequest
from assetmanagement.models import ListAspectTypesRequest
from assetmanagement.models import DeleteAspectTypeRequest
from assetmanagement.models.field_type_enum import FieldTypeEnum
from mindsphere_core.exceptions import MindsphereError
from tests.data.test_data import *


class TestAspectTypeApi(unittest.TestCase):
    def setUp(self):
        config = mindsphere_core.RestClientConfig("194.138.0.25", "9400")
        self.client = AspecttypeClient(rest_client_config=config)

    def test_create_aspect_type(self):
        id1 = ASPECT_CLIENT_ID + str(self.get_random_number())
        name = ASPECT_CLIENT_NAME + str(self.get_random_number())
        aspect_variable_list = self.get_aspect_variable_list()
        aspect_type = AspectType(
            name=name,
            category="dynamic",
            scope="private",
            description="",
            variables=aspect_variable_list,
        )
        request_object = SaveAspectTypeRequest(
            id=id1, aspecttype=aspect_type, if_match="0"
        )
        aspect = self.client.save_aspect_type(request_object)
        self.assertEqual(aspect.id, id1)
        self.assertEqual(aspect.name, name)

    def test_create_aspect_with_id_as_null(self):
        name = ASPECT_CLIENT_NAME + str(self.get_random_number())
        aspect_variable_list = self.get_aspect_variable_list()
        aspect_type = AspectType(
            name=name,
            category="dynamic",
            scope="private",
            description="",
            variables=aspect_variable_list,
        )
        request_object = SaveAspectTypeRequest(
            id=None, aspecttype=aspect_type, if_match="0"
        )
        with self.assertRaises(MindsphereError):
            self.client.save_aspect_type(request_object)

    def test_create_aspect_with_invalid_id(self):
        name = ASPECT_CLIENT_NAME + str(self.get_random_number())
        aspect_variable_list = self.get_aspect_variable_list()
        aspect_type = AspectType(
            name=name,
            category="dynamic",
            scope="private",
            description="",
            variables=aspect_variable_list,
        )
        request_object = SaveAspectTypeRequest(
            id=TENANT, aspecttype=aspect_type, if_match="0"
        )
        with self.assertRaises(MindsphereError):
            self.client.save_aspect_type(request_object)

    def test_create_aspect_with_invalid_object(self):
        id1 = ASPECT_CLIENT_ID + str(self.get_random_number())
        name = ASPECT_CLIENT_NAME + str(self.get_random_number())
        aspect_variable_list = self.get_aspect_variable_list()
        aspect_type = AspectType(
            name=name,
            category="dynamic",
            scope="public",
            description="",
            variables=aspect_variable_list,
        )
        request_object = SaveAspectTypeRequest(
            id=id1, aspecttype=aspect_type, if_match=None
        )
        with self.assertRaises(MindsphereError):
            self.client.save_aspect_type(request_object)

    def test_put_aspect_types_by_id(self):
        aspect_variable_list = self.get_aspect_variable_list()
        aspect_type = AspectType(
            name="TemperatureAndPressure572",
            category="dynamic",
            scope="private",
            description="",
            variables=aspect_variable_list,
        )
        request_object = GetAspectTypeRequest(
            id="mdspsdk.TemperatureAndPressure572", if_none_match=None
        )

        response = self.client.get_aspect_type(request_object)
        request_object1 = UpdateAspectTypeRequest(
            if_match=str(response.etag), id=response.id, aspecttype=aspect_type
        )
        aspect = self.client.update_aspect_type(request_object1)
        self.assertEqual(aspect.id, "mdspsdk.TemperatureAndPressure572")

    def test_put_aspect_types_by_invalid_id(self):
        name = ASPECT_CLIENT_NAME + str(self.get_random_number())
        aspect_variable_list = self.get_aspect_variable_list()
        aspect_type = AspectType(
            name=name,
            category="dynamic",
            scope="private",
            description="",
            variables=aspect_variable_list,
        )
        request_object1 = UpdateAspectTypeRequest(
            if_match="0", id="core", aspecttype=aspect_type
        )
        with self.assertRaises(MindsphereError):
            aspect = self.client.update_aspect_type(request_object1)
            self.assertEqual(aspect.name, name)

    def test_put_aspect_types_by_invalid_object(self):
        name = ASPECT_CLIENT_NAME + str(self.get_random_number())
        id1 = TENANT + str(self.get_random_number())
        aspect_variable_list = self.get_aspect_variable_list()
        aspect_type = AspectType(
            name=name,
            category="dynamic",
            scope="public",
            description="",
            variables=aspect_variable_list,
        )
        request_object1 = UpdateAspectTypeRequest(
            if_match="0", id=id1, aspecttype=aspect_type
        )
        with self.assertRaises(MindsphereError):
            self.client.update_aspect_type(request_object1)

    def test_put_aspect_types_with_no_id(self):
        name = ASPECT_CLIENT_NAME + str(self.get_random_number())
        aspect_variable_list = self.get_aspect_variable_list()
        aspect_type = AspectType(
            name=name,
            category="dynamic",
            scope="public",
            description="",
            variables=aspect_variable_list,
        )
        request_object1 = UpdateAspectTypeRequest(
            if_match="0", id=None, aspecttype=aspect_type
        )
        with self.assertRaises(MindsphereError):
            aspect = self.client.update_aspect_type(request_object1)
            self.assertEqual(aspect.name, ASPECT_CLIENT_NAME)

    def test_put_aspect_types_with_no_aspect_object(self):
        id1 = ASPECT_CLIENT_ID + str(self.get_random_number())
        name = ASPECT_CLIENT_NAME + str(self.get_random_number())
        request_object1 = UpdateAspectTypeRequest(if_match="0", id=id1, aspecttype=None)
        with self.assertRaises(MindsphereError):
            aspect = self.client.update_aspect_type(request_object1)
            self.assertEqual(aspect.name, name)

    def test_overloaded_method_in_get_types(self):
        request_object1 = ListAspectTypesRequest(
            page=10, size=0, sort=None, filter=None, if_none_match=None
        )
        aspect = self.client.list_aspect_types(request_object1)
        self.assertTrue(aspect.page.size > 0)
        self.assertTrue(aspect.page.total_elements > 0)
        self.assertTrue(aspect.page.total_pages > 0)
        self.assertTrue(aspect.page.number > 0)
        self.assertIsNotNone(aspect.embedded.aspect_types[0].name)
        self.assertIsNotNone(aspect.embedded.aspect_types[0].category)
        self.assertIsNotNone(aspect.embedded.aspect_types[0].scope)
        self.assertIsNotNone(aspect.embedded.aspect_types[0].description)
        self.assertIsNotNone(aspect.embedded.aspect_types[0].variables)

    def test_get_aspect_type_by_id(self):
        request_object1 = GetAspectTypeRequest(id=ASPECT_CLIENT_ID, if_none_match=None)
        aspect = self.client.get_aspect_type(request_object1)
        self.assertEqual(aspect.category, "dynamic")
        self.assertEqual(aspect.description, "")
        self.assertEqual(aspect.name, ASPECT_CLIENT_NAME)
        self.assertEqual(aspect.scope, "private")

    def test_get_aspect_type_with_no_id(self):
        with self.assertRaises(MindsphereError):
            request_object1 = GetAspectTypeRequest(id=None, if_none_match="0")
            aspect = self.client.get_aspect_type(request_object1)
            self.assertEqual(aspect.category, "dynamic")
            self.assertEqual(aspect.description, "")
            self.assertEqual(aspect.name, "ACurrentVoltagePower")
            self.assertEqual(aspect.scope, "public")
            self.assertEqual(aspect.variables.data_type, "DOUBLE")
            self.assertEqual(aspect.variables.searchable, False)
            self.assertEqual(aspect.variables.name, "Current1")
            self.assertEqual(aspect.variables.unit, "A")
            self.assertEqual(aspect.variables.quality_code, False)

    def test_get_aspect_types(self):
        request_object1 = ListAspectTypesRequest(
            page=0, size=10, sort=None, filter=None, if_none_match=None
        )
        aspect = self.client.list_aspect_types(request_object1)
        self.assertTrue(aspect.page.size > 0)
        self.assertTrue(aspect.page.total_elements > 0)
        self.assertTrue(aspect.page.total_pages > 0)
        self.assertTrue(aspect.page.number >= 0)
        self.assertIsNotNone(aspect.embedded.aspect_types[0].name)
        self.assertIsNotNone(aspect.embedded.aspect_types[0].category)
        self.assertIsNotNone(aspect.embedded.aspect_types[0].scope)
        self.assertIsNotNone(aspect.embedded.aspect_types[0].description)
        self.assertIsNotNone(aspect.embedded.aspect_types[0].variables)

    def test_get_aspect_types_with_sort_and_filter(self):
        request_object1 = ListAspectTypesRequest(
            page=0, size=10, sort=None, filter=None, if_none_match=None
        )
        aspect = self.client.list_aspect_types(request_object1)
        self.assertTrue(aspect.page.size > 0)
        self.assertTrue(aspect.page.total_elements > 0)
        self.assertTrue(aspect.page.total_pages > 0)
        self.assertIsNotNone(aspect.embedded.aspect_types[0].name)
        self.assertIsNotNone(aspect.embedded.aspect_types[0].category)
        self.assertIsNotNone(aspect.embedded.aspect_types[0].scope)
        self.assertIsNotNone(aspect.embedded.aspect_types[0].description)
        self.assertIsNotNone(aspect.embedded.aspect_types[0].variables)

    def test_delete_aspect_types(self):
        id1 = ASPECT_CLIENT_ID + str(self.get_random_number())
        name = ASPECT_CLIENT_NAME + str(self.get_random_number())
        aspect_variable_list = self.get_aspect_variable_list()
        aspect_type = AspectType(
            name=name,
            category="dynamic",
            scope="private",
            description="",
            variables=aspect_variable_list,
        )
        request_object = SaveAspectTypeRequest(
            id=id1, aspecttype=aspect_type, if_match=None
        )
        aspect = self.client.save_aspect_type(request_object)
        self.assertEqual(aspect.id, id1)
        self.assertEqual(aspect.name, name)
        request_object1 = DeleteAspectTypeRequest(
            if_match=str(aspect.etag), id=aspect.id
        )
        self.client.delete_aspect_type(request_object1)

    def test_get_aspect_types_equals_to(self):
        response = self.client.get_aspect_types_equals_to(field_type=FieldTypeEnum.NAME, filter_value="engine")
        self.assertEqual('engine', response.embedded.aspect_types[0].name)

    def test_negative_get_aspect_types_equals_to(self):
        with self.assertRaises(MindsphereError):
            self.client.get_aspect_types_equals_to(field_type=FieldTypeEnum.ASSET_ID, filter_value="engine")

    def test_get_aspect_type_name_like(self):
        response = self.client.get_aspect_types_like(FieldTypeEnum.NAME, "engine", "engine1356")
        self.assertIsNotNone(response)

    def test_negative_get_aspect_type_name_like(self):
        with self.assertRaises(MindsphereError):
            self.client.get_aspect_types_like(FieldTypeEnum.ASSET_ID, "engine", "engine1356")

    def test_get_aspect_type_starts_with(self):
        response = self.client.get_aspect_types_starts_with(FieldTypeEnum.NAME, "engine262")
        self.assertEqual('engine262', response.embedded.aspect_types[0].name)

    def test_negative_get_aspect_type_starts_with(self):
        with self.assertRaises(MindsphereError):
            self.client.get_aspect_types_starts_with(FieldTypeEnum.ASSET_ID, "engine262")

    def test_get_aspect_type_ends_with(self):
        response = self.client.get_aspect_types_ends_with(FieldTypeEnum.NAME, "ine")
        self.assertIsNotNone(response)

    def test_negative_get_aspect_type_ends_with(self):
        with self.assertRaises(MindsphereError):
            self.client.get_aspect_types_ends_with(FieldTypeEnum.ASSET_ID, "engine262")

    def test_get_aspect_type_contains_with(self):
        response = self.client.get_aspect_types_contains(FieldTypeEnum.TENANT_ID, "sdk")
        self.assertIsNotNone(response)

    def test_negative_get_aspect_type_contains_with(self):
        with self.assertRaises(MindsphereError):
            self.client.get_aspect_types_contains(FieldTypeEnum.ASSET_ID, "engine262")

    def test_integration(self):
        id1 = "mdspsdk.Temperature" + str(self.get_random_number())
        name = "Temperature" + str(self.get_random_number())
        aspect_variable_list = self.get_aspect_variable_list()
        aspect_type = AspectType(
            name=name,
            category="dynamic",
            scope="private",
            description="temperature",
            variables=aspect_variable_list,
        )
        request_object = SaveAspectTypeRequest(
            id=id1, aspecttype=aspect_type, if_match=None
        )
        aspect = self.client.save_aspect_type(request_object)
        self.assertEqual(str(aspect.etag), "0")
        request_object2 = GetAspectTypeRequest(id=id1, if_none_match=str(aspect.etag))
        aspect_id = self.client.get_aspect_type(request_object2)
        self.assertEqual(aspect_id.category, "dynamic")

        aspect_variable_list1 = self.get_aspect_variable_list()
        aspect_type1 = AspectType(
            name=name,
            category="dynamic",
            scope="private",
            description="",
            variables=aspect_variable_list1,
        )
        request_object3 = UpdateAspectTypeRequest(
            if_match=str(aspect.etag), id=id1, aspecttype=aspect_type1
        )
        aspect2 = self.client.update_aspect_type(request_object3)
        self.assertEqual(aspect2.id, id1)
        request_object1 = DeleteAspectTypeRequest(if_match=str(aspect2.etag), id=id1)
        self.client.delete_aspect_type(request_object1)

    @staticmethod
    def get_aspect_variable_list():
        aspect_variable1 = AspectVariable(
            name="flwheel",
            data_type="DOUBLE",
            unit="C",
            searchable=False,
            length=None,
            default_value=None,
            quality_code=False,
        )
        aspect_variable2 = AspectVariable(
            name="frwheel",
            data_type="DOUBLE",
            unit="C",
            searchable=False,
            length=None,
            default_value=None,
            quality_code=False,
        )
        aspect_variable3 = AspectVariable(
            name="rlwheel",
            data_type="DOUBLE",
            unit="C",
            searchable=False,
            length=None,
            default_value=None,
            quality_code=False,
        )
        aspect_variable4 = AspectVariable(
            name="rrwheel",
            data_type="DOUBLE",
            unit="C",
            searchable=False,
            length=None,
            default_value=None,
            quality_code=False,
        )
        aspect_variable_list = [
            aspect_variable1,
            aspect_variable2,
            aspect_variable3,
            aspect_variable4,
        ]
        return aspect_variable_list

    @staticmethod
    def get_random_number():
        return random.randint(1000, 9000) + 1000


if __name__ == "__main__":
    unittest.main()
