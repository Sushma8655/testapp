import unittest
import random

from mindsphere_core import mindsphere_core
from mindsphere_core.exceptions import MindsphereError
from assetmanagement.models import AssetType
from assetmanagement.models import AspectType
from assetmanagement.models import AspectVariable
from assetmanagement.models import AssetTypeAspects
from assetmanagement.models import VariableDefinition
from assetmanagement.models import KeyedFileAssignment
from assetmanagement.clients import AssettypeClient
from assetmanagement.clients import AspecttypeClient
from assetmanagement.models import SaveAssetTypeRequest
from assetmanagement.models import DeleteAssetTypeRequest
from assetmanagement.models import DeleteAssetTypeFileAssignmentRequest
from assetmanagement.models import SaveAssetTypeFileAssignmentRequest
from assetmanagement.models import GetAssetTypeRequest
from assetmanagement.models import UpdateAssetTypeRequest
from assetmanagement.models import ListAssetTypesRequest
from assetmanagement.models import SaveAspectTypeRequest
from assetmanagement.models import DeleteAspectTypeRequest
from assetmanagement.models.field_type_enum import FieldTypeEnum
from tests.data.test_data import *


class TestAssetTypeApi(unittest.TestCase):
    def setUp(self):
        config = mindsphere_core.RestClientConfig("194.138.0.25", "9400")
        self.asset_type_client = AssettypeClient(rest_client_config=config)
        self.aspect_type_client = AspecttypeClient(rest_client_config=config)

    def test_put_asset_type_by_id(self):
        id1 = ASSET_TYPE_CLIENT_ID + str(self.get_random_number())
        name1 = "Wheel" + str(self.get_random_number())
        aspect = AssetTypeAspects(
            name=ASSET_TYPE_CLIENT_ASPECT_NAME,
            aspect_type_id=ASSET_TYPE_CLIENT_ASPECT_ID,
        )
        asset_type_aspects_list = [aspect]
        def_list = []
        file_assignments = []
        asset_type = AssetType(
            name=name1,
            description="Basic agent type for the Asset Management Service.",
            parent_type_id=ASSET_TYPE_CLIENT_PARENT_TYPE_ID,
            instantiable=None,
            scope="private",
            variables=def_list,
            file_assignments=file_assignments,
            aspects=asset_type_aspects_list,
        )
        request_object = SaveAssetTypeRequest(
            if_match=None, id=id1, assettype=asset_type
        )
        resource = self.asset_type_client.save_asset_type(request_object)
        self.assertIsNotNone(resource)
        self.assertEqual(resource.id, id1)

    def test_put_asset_type_by_id_using_list(self):
        id1 = ASSET_TYPE_CLIENT_ID + str(self.get_random_number())
        name1 = "Wheel" + str(self.get_random_number())
        aspect1 = AssetTypeAspects(
            name=ASSET_TYPE_CLIENT_ASPECT_NAME,
            aspect_type_id=ASSET_TYPE_CLIENT_ASPECT_ID,
        )
        asset_type_aspects_list = [aspect1]
        def_list = []
        file_assignments = []
        asset_type = AssetType(
            name=name1,
            description="Basic agent type for the Asset Management Service.",
            parent_type_id=ASSET_TYPE_CLIENT_PARENT_TYPE_ID,
            instantiable=None,
            scope="private",
            variables=def_list,
            file_assignments=file_assignments,
            aspects=asset_type_aspects_list,
        )
        request_object = SaveAssetTypeRequest(
            if_match=None, id=id1, assettype=asset_type
        )
        resource = self.asset_type_client.save_asset_type(request_object)
        self.assertIsNotNone(resource)
        self.assertEqual(resource.id, id1)

    def test_put_asset_type_with_no_id(self):
        name1 = "Wheel" + str(self.get_random_number())
        aspect = AssetTypeAspects(name=name1)
        def1 = VariableDefinition(
            name="externalId1",
            data_type="BOOLEAN",
            unit=None,
            searchable=False,
            length=255,
        )
        def_list = [def1]
        file_assignments = []
        asset_type = AssetType(
            name=name1,
            description="Basic agent type for the Asset Management Service.",
            parent_type_id=ASSET_TYPE_CLIENT_PARENT_TYPE_ID,
            instantiable=None,
            scope="public",
            variables=def_list,
            file_assignments=file_assignments,
            aspects=aspect,
        )
        with self.assertRaises(MindsphereError):
            request_object = SaveAssetTypeRequest(
                if_match=None, id=None, assettype=asset_type
            )
            self.asset_type_client.save_asset_type(request_object)

    def test_put_asset_type_with_no_asset_type(self):
        id1 = ASSET_TYPE_CLIENT_ID + str(self.get_random_number())
        with self.assertRaises(MindsphereError):
            request_object = SaveAssetTypeRequest(if_match=None, id=id1, assettype=None)
            self.asset_type_client.save_asset_type(request_object)

    def test_put_asset_type_with_invalid_id(self):
        id1 = TENANT + str(self.get_random_number())
        name1 = "FancyAsset" + str(self.get_random_number())
        aspect = AssetTypeAspects(
            name="AllDataTypes", aspect_type_id="khe1.aCurrentVoltagePower"
        )
        def_list = []
        file_assignments = []
        asset_type = AssetType(
            name=name1,
            description="Basic agent type for the Asset Management Service.",
            parent_type_id=ASSET_TYPE_CLIENT_PARENT_TYPE_ID,
            instantiable=None,
            scope="private",
            variables=def_list,
            file_assignments=file_assignments,
            aspects=aspect,
        )
        with self.assertRaises(MindsphereError):
            request_object = SaveAssetTypeRequest(
                if_match=None, id=id1, assettype=asset_type
            )
            self.asset_type_client.save_asset_type(request_object)

    def test_update_asset_type(self):
        id1 = ASSET_TYPE_CLIENT_ID + str(self.get_random_number())
        name1 = "Wheel" + str(self.get_random_number())
        aspect = AssetTypeAspects(
            name=ASSET_TYPE_CLIENT_ASPECT_NAME,
            aspect_type_id=ASSET_TYPE_CLIENT_ASPECT_ID,
        )
        asset_type_aspects_list = [aspect]
        def_list = []
        file_assignments = []
        asset_type = AssetType(
            name=name1,
            description="Basic agent type for the Asset Management Service.",
            parent_type_id=ASSET_TYPE_CLIENT_PARENT_TYPE_ID,
            instantiable=None,
            scope="private",
            variables=def_list,
            file_assignments=file_assignments,
            aspects=asset_type_aspects_list,
        )
        request_object1 = SaveAssetTypeRequest(
            if_match=None, id=id1, assettype=asset_type
        )
        resource = self.asset_type_client.save_asset_type(request_object1)
        request_object2 = UpdateAssetTypeRequest(
            if_match="0", id=resource.id, assettype=asset_type
        )
        update = self.asset_type_client.update_asset_type(request_object2)
        self.assertIsNotNone(update)
        self.assertEqual(update.id, id1)

    def test_update_asset_type_with_no_id(self):
        def_list = []
        file_assignments = []
        aspect = AssetTypeAspects(
            name="AllDataTypes", aspect_type_id="khe1.aCurrentVoltagePower"
        )
        asset_type = AssetType(
            name="FancyAsset",
            description="Basic agent type for the Asset Management Service.",
            parent_type_id=ASSET_TYPE_CLIENT_PARENT_TYPE_ID,
            instantiable=None,
            scope="private",
            variables=def_list,
            file_assignments=file_assignments,
            aspects=aspect,
        )
        with self.assertRaises(MindsphereError):
            request_object = UpdateAssetTypeRequest(
                if_match=None, id=None, assettype=asset_type
            )
            self.asset_type_client.update_asset_type(request_object)

    def test_update_asset_type_with_invalid_id(self):
        id1 = "core" + str(self.get_random_number())
        name1 = "Wheel" + str(self.get_random_number())
        def_list = []
        file_assignments = []
        aspect = AssetTypeAspects(
            name="AllDataTypes", aspect_type_id="khe1.aCurrentVoltagePower"
        )
        asset_type = AssetType(
            name=name1,
            description="Basic agent type for the Asset Management Service.",
            parent_type_id=ASSET_TYPE_CLIENT_PARENT_TYPE_ID,
            instantiable=None,
            scope="private",
            variables=def_list,
            file_assignments=file_assignments,
            aspects=aspect,
        )
        with self.assertRaises(MindsphereError):
            request_object = UpdateAssetTypeRequest(
                if_match="0", id=id1, assettype=asset_type
            )
            self.asset_type_client.update_asset_type(request_object)

    def test_get_asset_types_by_id(self):
        request_object = GetAssetTypeRequest(
            if_none_match=None, exploded=False, id=ASSET_TYPE_CLIENT_ID
        )
        asset_type = self.asset_type_client.get_asset_type(request_object)
        self.assertNotEqual(asset_type.etag, "0")

    def test_get_asset_types_by_invalid_id(self):
        with self.assertRaises(MindsphereError):
            request_object = GetAssetTypeRequest(
                if_none_match=None, exploded=False, id="core"
            )
            self.asset_type_client.get_asset_type(request_object)

    def test_get_asset_types_by_invalid_id_overloaded(self):
        with self.assertRaises(MindsphereError):
            request_object = GetAssetTypeRequest(
                if_none_match=None, exploded=False, id="core"
            )
            self.asset_type_client.get_asset_type(request_object)

    def test_get_asset_types_by_invalid_boolean(self):
        with self.assertRaises(MindsphereError):
            request_object = GetAssetTypeRequest(
                if_none_match=None, exploded=bool("asset"), id="core"
            )
            resource = self.asset_type_client.get_asset_type(request_object)
            self.assertNotEqual(resource.etag, 0)

    def test_get_asset_types(self):
        request_object = ListAssetTypesRequest(
            filter=None, if_none_match=None, size=10, exploded=False, page=0, sort=None
        )
        asset = self.asset_type_client.list_asset_types(request_object)
        self.assertTrue(asset.page.size > 0)
        self.assertTrue(asset.page.total_elements > 0)
        self.assertTrue(asset.page.total_pages > 0)
        self.assertIsNotNone(asset.embedded.asset_types[0].name)
        self.assertIsNotNone(asset.embedded.asset_types[0].description)
        self.assertIsNotNone(asset.embedded.asset_types[0].scope)
        self.assertIsNotNone(asset.embedded.asset_types[0].variables)

    def test_get_asset_types_checking_filter(self):
        request_object = ListAssetTypesRequest(
            filter='{"name":"aspecttypename"}',
            if_none_match=None,
            size=10,
            exploded=False,
            page=0,
            sort=None,
        )
        asset = self.asset_type_client.list_asset_types(request_object)
        self.assertIsNotNone(asset.embedded.asset_types)

    def test_get_asset_types_with_invalid_page_and_size(self):
        with self.assertRaises(MindsphereError):
            request_object = ListAssetTypesRequest(
                filter=None,
                if_none_match=None,
                size=10,
                exploded=False,
                page=2147483647,
                sort=None,
            )
            self.asset_type_client.list_asset_types(request_object)

    def test_get_asset_types_with_no_id(self):
        with self.assertRaises(MindsphereError):
            request_object = GetAssetTypeRequest(
                if_none_match=None, exploded=False, id=None
            )
            self.asset_type_client.get_asset_type(request_object)

    def test_get_asset_types_with_sort_and_filter(self):
        request_object1 = ListAssetTypesRequest(
            filter=None, if_none_match=None, size=10, exploded=False, page=0, sort=None
        )
        all_assets = self.asset_type_client.list_asset_types(request_object1)
        filter_name = all_assets.embedded.asset_types[0].name
        filter_input = '{"name":"' + filter_name + '"}'
        request_object2 = ListAssetTypesRequest(
            filter=filter_input,
            if_none_match=None,
            size=10,
            exploded=False,
            page=0,
            sort="name,desc",
        )
        asset = self.asset_type_client.list_asset_types(request_object2)
        self.assertTrue(asset.page.size > 0)
        self.assertTrue(asset.page.total_elements > 0)
        self.assertTrue(asset.page.total_pages > 0)
        self.assertIsNotNone(asset.embedded.asset_types[0].name)
        self.assertIsNotNone(asset.embedded.asset_types[0].description)
        self.assertIsNotNone(asset.embedded.asset_types[0].scope)
        self.assertIsNotNone(asset.embedded.asset_types[0].variables)

    def test_get_asset_types_with_negative_page(self):
        request_object = ListAssetTypesRequest(
            filter=None, if_none_match=None, size=10, exploded=False, page=-1, sort=None
        )
        asset = self.asset_type_client.list_asset_types(request_object)
        self.assertEqual(asset.page.number, 0)

    def test_get_asset_types_with_invalid_filter(self):
        with self.assertRaises(MindsphereError):
            request_object = ListAssetTypesRequest(
                filter="a",
                if_none_match=None,
                size=10,
                exploded=False,
                page=0,
                sort=None,
            )
            self.asset_type_client.list_asset_types(request_object)

    def test_get_asset_types_with_invalid_sort(self):
        with self.assertRaises(MindsphereError):
            request_object = ListAssetTypesRequest(
                filter=None,
                if_none_match=None,
                size=10,
                exploded=False,
                page=0,
                sort="sort",
            )
            self.asset_type_client.list_asset_types(request_object)

    def test_delete_asset_type(self):
        value = random.randint(1000, 9000) + 1000
        id1 = ASSET_TYPE_CLIENT_ID + str(value)
        name1 = "Wheel" + str(value)
        def_list = []
        file_assignments = []
        aspect = AssetTypeAspects(
            name=ASSET_TYPE_CLIENT_ASPECT_NAME,
            aspect_type_id=ASSET_TYPE_CLIENT_ASPECT_ID,
        )
        asset_type_aspects_list = [aspect]
        asset_type = AssetType(
            name=name1,
            description="Basic agent type for the Asset Management Service.",
            parent_type_id=ASSET_TYPE_CLIENT_PARENT_TYPE_ID,
            instantiable=None,
            scope="private",
            variables=def_list,
            file_assignments=file_assignments,
            aspects=asset_type_aspects_list,
        )
        request_object = SaveAssetTypeRequest(
            if_match=None, id=id1, assettype=asset_type, if_none_match=None
        )
        resource = self.asset_type_client.save_asset_type(request_object)
        self.assertIsNotNone(resource)
        self.assertEqual(resource.id, id1)

    def test_aspect_to_asset_type(self):
        aspect_id = "mdspsdk.Temperature" + str(self.get_random_number())
        aspect_name = "Temperature" + str(self.get_random_number())
        aspect_variable = AspectVariable()
        aspect_variable.data_type = "DOUBLE"
        aspect_variable.searchable = False
        aspect_variable.name = "FLWheel"
        aspect_variable.unit = "C"
        aspect_variable.length = None
        aspect_variable.quality_code = False
        aspect_variable_list = [aspect_variable]
        aspect_type = AspectType()
        aspect_type.name = aspect_name
        aspect_type.description = "temperature"
        aspect_type.category = "dynamic"
        aspect_type.scope = "private"
        aspect_type.variables = aspect_variable_list

        # save aspect type
        request_object1 = SaveAspectTypeRequest(
            if_none_match=None, aspecttype=aspect_type, if_match=None, id=aspect_id
        )
        aspect = self.aspect_type_client.save_aspect_type(request_object1)
        self.assertEqual(aspect.name, aspect_name)
        self.assertEqual(aspect.category, "dynamic")
        self.assertEqual(aspect.etag, 0)

        # create asset type
        asset_type_id = "mdspsdk.pressure" + str(self.get_random_number())
        asset_type_name = "Wheel" + str(self.get_random_number())
        asset_type = AssetType()
        asset_type.parent_type_id = ASSET_TYPE_CLIENT_PARENT_TYPE_ID
        asset_type.name = asset_type_name
        asset_type.description = "Basic agent type for the Asset Management Service."
        asset_type.scope = "private"
        aspect_object = AssetTypeAspects()
        aspect_object.name = aspect_name
        aspect_object.aspect_type_id = aspect_id
        asset_type_aspects_list = [aspect_object]
        asset_type.aspects = asset_type_aspects_list
        def_list = []
        file_assignments = []
        asset_type.variables = def_list
        asset_type.file_assignments = file_assignments

        # save asset type
        request_object2 = SaveAssetTypeRequest(
            if_match=None, id=asset_type_id, assettype=asset_type
        )
        resource = self.asset_type_client.save_asset_type(request_object2)
        self.assertIsNotNone(resource)
        self.assertEqual(resource.id, asset_type_id)
        self.assertEqual(resource.etag, 0)

        # delete asset type
        request_object3 = DeleteAssetTypeRequest(
            if_match=str(resource.etag), id=asset_type_id
        )
        self.asset_type_client.delete_asset_type(request_object3)

        # delete aspect type
        request_object4 = DeleteAspectTypeRequest(
            if_match=str(aspect.etag), id=aspect_id
        )
        self.aspect_type_client.delete_aspect_type(request_object4)

    def test_save_asset_type_file_assignment(self):
        request_object1 = GetAssetTypeRequest(
            if_none_match=None, exploded=False, id=ASSET_TYPE_CLIENT_ID
        )
        asset_type_data = self.asset_type_client.get_asset_type(request_object1)
        if_match = asset_type_data.etag
        id1 = asset_type_data.id
        key = "demotest"

        assignment = KeyedFileAssignment()
        assignment.file_id = ASSET_CLIENT_FILE_ID
        request_object2 = SaveAssetTypeFileAssignmentRequest(
            if_match=str(if_match), assignment=assignment, id=id1, key=key
        )
        asset_type_data = self.asset_type_client.save_asset_type_file_assignment(
            request_object2
        )
        for i in asset_type_data.file_assignments:
            if i.key == key:
                self.assertEqual(i.file_id, ASSET_CLIENT_FILE_ID)

    def test_delete_asset_type_file_assignment(self):
        id1 = ASSET_TYPE_CLIENT_ID
        key = "DemoTest1"
        assignment = KeyedFileAssignment(file_id=ASSET_CLIENT_FILE_ID)
        request_object1 = GetAssetTypeRequest(
            if_none_match=None, exploded=False, id=id1
        )
        asset_type_data = self.asset_type_client.get_asset_type(request_object1)
        if_match = asset_type_data.etag
        request_object2 = SaveAssetTypeFileAssignmentRequest(
            if_match=str(if_match), assignment=assignment, id=id1, key=key
        )
        asset_type_data = self.asset_type_client.save_asset_type_file_assignment(
            request_object2
        )
        for i in asset_type_data.file_assignments:
            if i.key == key:
                self.assertEqual(i.file_id, ASSET_CLIENT_FILE_ID)
                request_object3 = DeleteAssetTypeFileAssignmentRequest(
                    if_match=str(asset_type_data.etag),
                    id=asset_type_data.id,
                    key=asset_type_data.file_assignments[0].key,
                )
                asset_type_data = self.asset_type_client.delete_asset_type_file_assignment(
                    request_object3
                )
                self.assertEqual(asset_type_data.id, id1)

    def test_save_asset_type_file_assignment_invalid_id(self):
        id1 = ASSET_TYPE_CLIENT_ID
        key = "Demo"
        assignment = KeyedFileAssignment(file_id=ASSET_CLIENT_FILE_ID)
        request_object1 = GetAssetTypeRequest(
            if_none_match=None, exploded=False, id=id1
        )
        asset_type_data = self.asset_type_client.get_asset_type(request_object1)
        if_match = asset_type_data.etag
        with self.assertRaises(MindsphereError):
            request_object2 = SaveAssetTypeFileAssignmentRequest(
                if_match=str(if_match), assignment=assignment, id="INVALID", key=key
            )
            self.asset_type_client.save_asset_type_file_assignment(request_object2)

    def test_delete_asset_type_file_assignment_invalid_id(self):
        id1 = ASSET_TYPE_CLIENT_ID
        key = "Demo"
        request_object1 = GetAssetTypeRequest(
            if_none_match=None, exploded=False, id=id1
        )
        asset_type_data = self.asset_type_client.get_asset_type(request_object1)
        if_match = asset_type_data.etag
        with self.assertRaises(MindsphereError):
            request_object2 = DeleteAssetTypeFileAssignmentRequest(
                if_match=str(if_match), id="INVALID", key=key
            )
            self.asset_type_client.delete_asset_type_file_assignment(request_object2)

    def test_save_asset_type_file_assignment_no_id(self):
        id1 = ASSET_TYPE_CLIENT_ID
        key = "Demo"
        assignment = KeyedFileAssignment(file_id=ASSET_CLIENT_FILE_ID)
        request_object1 = GetAssetTypeRequest(
            if_none_match=None, exploded=False, id=id1
        )
        asset_type_data = self.asset_type_client.get_asset_type(request_object1)
        if_match = asset_type_data.etag
        with self.assertRaises(MindsphereError):
            request_object2 = SaveAssetTypeFileAssignmentRequest(
                if_match=str(if_match), assignment=assignment, id=None, key=key
            )
            self.asset_type_client.save_asset_type_file_assignment(request_object2)

    def test_delete_asset_type_file_assignment_no_id(self):
        id1 = ASSET_TYPE_CLIENT_ID
        key = "Demo"
        request_object1 = GetAssetTypeRequest(
            if_none_match=None, exploded=False, id=id1
        )
        asset_type_data = self.asset_type_client.get_asset_type(request_object1)
        if_match = asset_type_data.etag
        with self.assertRaises(MindsphereError):
            request_object2 = DeleteAssetTypeFileAssignmentRequest(
                if_match=str(if_match), id=None, key=key
            )
            self.asset_type_client.delete_asset_type_file_assignment(request_object2)

    def test_save_asset_type_file_assignment_no_key(self):
        id1 = ASSET_TYPE_CLIENT_ID
        key = None
        assignment = KeyedFileAssignment(file_id=ASSET_CLIENT_FILE_ID)
        request_object1 = GetAssetTypeRequest(
            if_none_match=None, exploded=False, id=id1
        )
        asset_type_data = self.asset_type_client.get_asset_type(request_object1)
        if_match = asset_type_data.etag
        with self.assertRaises(MindsphereError):
            request_object2 = SaveAssetTypeFileAssignmentRequest(
                if_match=str(if_match), assignment=assignment, id=id1, key=key
            )
            self.asset_type_client.save_asset_type_file_assignment(request_object2)

    def test_delete_asset_type_file_assignment_no_key(self):
        id1 = ASSET_TYPE_CLIENT_ID
        key = None
        request_object1 = GetAssetTypeRequest(
            if_none_match=None, exploded=False, id=id1
        )
        asset_type_data = self.asset_type_client.get_asset_type(request_object1)
        if_match = asset_type_data.etag
        with self.assertRaises(MindsphereError):
            request_object2 = DeleteAssetTypeFileAssignmentRequest(
                if_match=str(if_match), id=id1, key=key
            )
            self.asset_type_client.delete_asset_type_file_assignment(request_object2)

    def test_save_asset_type_file_assignment_no_assignment(self):
        id1 = ASSET_TYPE_CLIENT_ID
        key = "Demo1"
        assignment = KeyedFileAssignment()
        request_object1 = GetAssetTypeRequest(
            if_none_match=None, exploded=False, id=id1
        )
        asset_type_data = self.asset_type_client.get_asset_type(request_object1)
        if_match = asset_type_data.etag
        with self.assertRaises(MindsphereError):
            request_object2 = SaveAssetTypeFileAssignmentRequest(
                if_match=str(if_match), assignment=assignment, id=id1, key=key
            )
            self.asset_type_client.save_asset_type_file_assignment(request_object2)

    def test_save_asset_type_file_assignment_no_if_match(self):
        id1 = ASSET_TYPE_CLIENT_ID
        key = "Demo1"
        assignment = KeyedFileAssignment(file_id=ASSET_CLIENT_FILE_ID)
        with self.assertRaises(MindsphereError):
            request_object = SaveAssetTypeFileAssignmentRequest(
                if_match=None, assignment=assignment, id=id1, key=key
            )
            self.asset_type_client.save_asset_type_file_assignment(request_object)

    def test_delete_asset_type_file_assignment_no_if_match(self):
        id1 = ASSET_TYPE_CLIENT_ID
        key = "Demo1"
        with self.assertRaises(MindsphereError):
            request_object = DeleteAssetTypeFileAssignmentRequest(
                if_match=None, id=id1, key=key
            )
            self.asset_type_client.delete_asset_type_file_assignment(request_object)

    def test_save_asset_type_file_assignment_invalid_if_match(self):
        id1 = ASSET_TYPE_CLIENT_ID
        key = "Demo1"
        assignment = KeyedFileAssignment(file_id=ASSET_CLIENT_FILE_ID)
        with self.assertRaises(MindsphereError):
            request_object = SaveAssetTypeFileAssignmentRequest(
                if_match="0", assignment=assignment, id=id1, key=key
            )
            self.asset_type_client.save_asset_type_file_assignment(request_object)

    def test_delete_asset_type_file_assignment_invalid_if_match(self):
        id1 = ASSET_TYPE_CLIENT_ID
        key = "Demo1"
        with self.assertRaises(MindsphereError):
            request_object = DeleteAssetTypeFileAssignmentRequest(
                if_match="0", id=id1, key=key
            )
            self.asset_type_client.delete_asset_type_file_assignment(request_object)

    def test_save_asset_type_file_assignment_invalid_file_id(self):
        id1 = ASSET_TYPE_CLIENT_ID
        key = "Demo1"
        assignment = KeyedFileAssignment(file_id="INVALID")
        request_object1 = GetAssetTypeRequest(
            if_none_match=None, exploded=False, id=id1
        )
        asset_type_data = self.asset_type_client.get_asset_type(request_object1)
        if_match = asset_type_data.etag
        with self.assertRaises(MindsphereError):
            request_object2 = SaveAssetTypeFileAssignmentRequest(
                if_match=str(if_match), assignment=assignment, id=id1, key=key
            )
            self.asset_type_client.save_asset_type_file_assignment(request_object2)

    def test_get_asset_types_equals_to(self):
        response = self.asset_type_client.get_asset_types_equals_to(field_type=FieldTypeEnum.NAME, filter_value="asset")
        self.assertEqual('asset', response.embedded.asset_types[0].name)

    def test_negative_get_asset_types_equals_to(self):
        with self.assertRaises(MindsphereError):
            self.asset_type_client.get_asset_types_equals_to(field_type=FieldTypeEnum.PARENT_ID, filter_value="asset")

    def test_get_asset_types_like_name(self):
        response = self.asset_type_client.get_asset_types_like(FieldTypeEnum.PARENT_TYPE_ID, "core.basicasset")
        self.assertEqual('core.basicasset', response.embedded.asset_types[0].parent_type_id)

    def test_negative_get_asset_types_like_name(self):
        with self.assertRaises(MindsphereError):
            self.asset_type_client.get_asset_types_like(FieldTypeEnum.SUBTENANT, "asset")

    def test_get_asset_types_start_with(self):
        response = self.asset_type_client.get_asset_types_starts_with(field_type=FieldTypeEnum.TENANT_ID, filter_value="md")
        self.assertEqual('mdspsdk', response.embedded.asset_types[0].tenant_id)

    def test_negative_asset_types_start_with(self):
        with self.assertRaises(MindsphereError):
            self.asset_type_client.get_asset_types_starts_with(field_type=FieldTypeEnum.ASSET_ID, filter_value="engine262626")

    def test_get_asset_types_ends_with(self):
        response = self.asset_type_client.get_asset_types_ends_with(field_type=FieldTypeEnum.NAME, filter_value="l2055")
        self.assertEqual('Wheel2055', response.embedded.asset_types[0].name)

    def test_negative_asset_types_ends_with(self):
        with self.assertRaises(MindsphereError):
            self.asset_type_client.get_asset_types_ends_with(field_type=FieldTypeEnum.SUBTENANT,
                                                                        filter_value="262626")

    def test_get_asset_types_contains(self):
        response = self.asset_type_client.get_asset_types_contains(field_type=FieldTypeEnum.NAME, filter_value=
        "eel2055")
        self.assertEqual('Wheel2055', response.embedded.asset_types[0].name)

    def test_negative_get_asset_types_contains(self):
        with self.assertRaises(MindsphereError):
            self.asset_type_client.get_asset_types_ends_with(field_type=FieldTypeEnum.EXTERNAL_ID, filter_value=
            "262626")

    def test_integration(self):
        id1 = "mdspsdk.pressure" + str(self.get_random_number())
        name = "Wheel" + str(self.get_random_number())
        asset_type_dto = AssetType()
        asset_type_dto.parent_type_id = ASSET_TYPE_CLIENT_PARENT_TYPE_ID
        asset_type_dto.name = name
        asset_type_dto.description = (
            "Basic agent type for the Asset Management Service."
        )
        asset_type_dto.scope = "private"
        aspect = AssetTypeAspects(
            name="ContactPoint", aspect_type_id="core.contactpoint"
        )
        asset_type_aspects_list = [aspect]
        asset_type_dto.aspects = asset_type_aspects_list
        def_list = []
        file_assignments = []
        asset_type_dto.variables = def_list
        asset_type_dto.file_assignments = file_assignments

        request_object1 = SaveAssetTypeRequest(
            if_match=None, id=id1, assettype=asset_type_dto
        )
        resource = self.asset_type_client.save_asset_type(request_object1)
        self.assertIsNotNone(resource)
        request_object2 = GetAssetTypeRequest(
            if_none_match=str(resource.etag), exploded=False, id=id1
        )
        asset_type = self.asset_type_client.get_asset_type(request_object2)
        self.assertEqual(asset_type.name, name)

        asset_type_dto1 = AssetType()
        asset_type_dto1.parent_type_id = "core.basicasset"
        asset_type_dto1.name = name
        asset_type_dto1.description = (
            "Basic agent type for the Asset Management Service."
        )
        asset_type_dto1.scope = "private"
        aspect1 = AssetTypeAspects(
            name="ContactPoint", aspect_type_id="core.contactpoint"
        )
        aspect2 = AssetTypeAspects(
            name="Temperature71015", aspect_type_id="mdspsdk.Temperature71015"
        )
        asset_type_aspects_list = [aspect1, aspect2]
        asset_type_dto1.aspects = asset_type_aspects_list
        def_list = []
        file_assignments = []
        asset_type_dto1.variables = def_list
        asset_type_dto1.file_assignments = file_assignments

        request_object3 = UpdateAssetTypeRequest(
            if_match=str(resource.etag), id=id1, assettype=asset_type_dto1
        )
        update = self.asset_type_client.update_asset_type(request_object3)
        self.assertIsNotNone(update)

        request_object4 = GetAssetTypeRequest(
            if_none_match=None, exploded=False, id=id1
        )
        asset_type_data = self.asset_type_client.get_asset_type(request_object4)
        if_match = asset_type_data.etag
        key = "demoTest"

        assignment = KeyedFileAssignment
        assignment.file_id = ASSET_CLIENT_FILE_ID

        request_object5 = SaveAssetTypeFileAssignmentRequest(
            if_match=str(if_match), assignment=assignment, id=id1, key=key
        )
        asset_type_data = self.asset_type_client.save_asset_type_file_assignment(
            request_object5
        )
        for i in asset_type_data.file_assignments:
            if i.key == key:
                self.assertEqual(i.file_id, ASSET_CLIENT_FILE_ID)

        request_object6 = GetAssetTypeRequest(
            if_none_match=None, exploded=False, id=id1
        )
        asset_type_data = self.asset_type_client.get_asset_type(request_object6)
        if_match = asset_type_data.etag

        request_object7 = DeleteAssetTypeFileAssignmentRequest(
            if_match=str(if_match), id=id1, key=key
        )
        self.asset_type_client.delete_asset_type_file_assignment(request_object7)
        request_object8 = GetAssetTypeRequest(
            if_none_match=str(asset_type.etag), exploded=False, id=asset_type.id
        )
        self.asset_type_client.get_asset_type(request_object8)

        request_object9 = GetAssetTypeRequest(
            if_none_match=None, exploded=False, id=id1
        )
        asset_type_data = self.asset_type_client.get_asset_type(request_object9)
        if_match = asset_type_data.etag

        request_object10 = DeleteAssetTypeRequest(if_match=str(if_match), id=id1)
        self.asset_type_client.delete_asset_type(request_object10)

    @staticmethod
    def get_random_number():
        return random.randint(1000, 9000) + 1000


if __name__ == "__main__":
    unittest.main()
