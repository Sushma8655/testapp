import unittest
from mindsphere_core import mindsphere_core, TenantCredentials, AppCredentials
from mindsphere_core.exceptions import MindsphereError
from assetmanagement.clients import AssetsClient
from assetmanagement.models import Asset
from assetmanagement.models import AssetMove
from assetmanagement.models import AssetUpdate
from assetmanagement.models import Variable
from assetmanagement.models import KeyedFileAssignment
from assetmanagement.models import ListAssetsRequest
from assetmanagement.models import GetAssetRequest
from assetmanagement.models import SaveAssetFileAssignmentRequest
from assetmanagement.models import MoveAssetRequest
from assetmanagement.models import AddAssetRequest
from assetmanagement.models import UpdateAssetRequest
from assetmanagement.models import DeleteAssetRequest
from assetmanagement.models import DeleteAssetFileAssigmentRequest
from assetmanagement.models import GetRootAssetRequest
from assetmanagement.models.delete_asset_confirmation_request import DeleteAssetConfirmationRequest
from tests.data.test_data import *
from assetmanagement.models.field_type_enum import FieldTypeEnum


class TestAssetClientApi(unittest.TestCase):
    def setUp(self):
        config = mindsphere_core.RestClientConfig("194.138.0.25", "9400")
        self.client = AssetsClient(rest_client_config=config)

    def test_get_assets_with_sub_tenant(self):
        credentials = TenantCredentials(
            client_id=CLIENT_ID_SUB_TENANT,
            client_secret=CLIENT_SECRET_SUB_TENANT,
            tenant=TENANT,
            sub_tenant=SUB_TENANT,
            use_sub_tenant=True,
        )
        config = mindsphere_core.RestClientConfig(
            proxy_host="194.138.0.25", proxy_port="9400", host_environment="eu1"
        )
        client = AssetsClient(config, credentials)
        request_object = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        asset = client.list_assets(request_object)
        self.assertTrue(asset.page.size > 0)
        self.assertTrue(asset.page.total_pages > 0)
        self.assertTrue(asset.page.total_elements > 0)
        self.assertIsNotNone(asset.embedded.assets[0].name)
        self.assertIsNotNone(asset.embedded.assets[0].parent_id)
        self.assertIsNotNone(asset.embedded.assets[0].variables)
        self.assertIsNotNone(asset.embedded.assets[0].etag)
        self.assertIsNotNone(asset.embedded.assets[0].links)

    def test_get_assets(self):
        request_object = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        asset = self.client.list_assets(request_object)
        self.assertTrue(asset.page.size > 0)
        self.assertTrue(asset.page.total_pages > 0)
        self.assertTrue(asset.page.total_elements > 0)
        self.assertIsNotNone(asset.embedded.assets[0].name)
        self.assertIsNotNone(asset.embedded.assets[0].parent_id)
        self.assertIsNotNone(asset.embedded.assets[0].variables)
        self.assertIsNotNone(asset.embedded.assets[0].etag)
        self.assertIsNotNone(asset.embedded.assets[0].links)

    def test_get_assets_checking_filter(self):
        request_object = ListAssetsRequest(
            filter='{"name":"aspecttypename"}',
            if_none_match=None,
            size=10,
            page=0,
            sort=None,
        )
        asset = self.client.list_assets(request_object)
        self.assertIsNotNone(len(asset.embedded.assets))

    def test_get_assets_with_no_parameters(self):
        request_object = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        asset = self.client.list_assets(request_object)

        self.assertTrue(asset.page.size > 0)
        self.assertTrue(asset.page.total_pages > 0)
        self.assertTrue(asset.page.total_elements > 0)
        self.assertIsNotNone(asset.embedded.assets[0].name)
        self.assertIsNotNone(asset.embedded.assets[0].parent_id)
        self.assertIsNotNone(asset.embedded.assets[0].variables)
        self.assertIsNotNone(asset.embedded.assets[0].links)

    def test_get_assets_with_page_size(self):
        request_object = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        asset = self.client.list_assets(request_object)

        self.assertTrue(asset.page.size > 0)
        self.assertTrue(asset.page.total_pages > 0)
        self.assertTrue(asset.page.total_elements > 0)
        self.assertIsNotNone(asset.embedded.assets[0].name)
        self.assertIsNotNone(asset.embedded.assets[0].parent_id)
        self.assertIsNotNone(asset.embedded.assets[0].variables)
        self.assertIsNotNone(asset.embedded.assets[0].etag)
        self.assertIsNotNone(asset.embedded.assets[0].links)

    def test_get_assets_with_sort_filter(self):
        request_object1 = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        available_assets = self.client.list_assets(request_object1)
        selected_asset_name = available_assets.embedded.assets[0].name
        sort = "asc"
        filter = '{"name":"' + selected_asset_name + '"}'

        request_object2 = ListAssetsRequest(
            filter=filter, if_none_match=None, size=10, page=0, sort=sort
        )
        asset = self.client.list_assets(request_object2)
        self.assertTrue(asset.page.size > 0)
        self.assertTrue(asset.page.total_pages > 0)
        self.assertTrue(asset.page.total_elements > 0)
        self.assertIsNotNone(asset.embedded.assets[0].name)
        self.assertIsNotNone(asset.embedded.assets[0].parent_id)
        self.assertIsNotNone(asset.embedded.assets[0].variables)
        self.assertIsNotNone(asset.embedded.assets[0].etag)
        self.assertIsNotNone(asset.embedded.assets[0].links)

    def test_get_assets_with_id(self):
        request_object1 = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        asset_object = self.client.list_assets(request_object1)
        for asset_by_id in asset_object.embedded.assets:
            request_object2 = GetAssetRequest(
                if_none_match=str(asset_by_id.etag), id=asset_by_id.asset_id
            )
            asset = self.client.get_asset(request_object2)

            self.assertEqual(asset.asset_id, asset_by_id.asset_id)
            self.assertEqual(asset.tenant_id, asset_by_id.tenant_id)
            self.assertEqual(asset.name, asset_by_id.name)
            self.assertEqual(asset.etag, asset_by_id.etag)
            self.assertEqual(asset.external_id, asset_by_id.external_id)
            self.assertEqual(asset.description, asset_by_id.description)
            self.assertEqual(asset.parent_id, asset_by_id.parent_id)
            self.assertEqual(asset.type_id, asset_by_id.type_id)
            self.assertEqual(asset.deleted, asset_by_id.deleted)

    def test_get_assets_with_no_id(self):
        with self.assertRaises(MindsphereError):
            request_object = GetAssetRequest(if_none_match=None, id=None)
            self.client.get_asset(request_object)

    def test_get_assets_with_invalid_id(self):
        with self.assertRaises(MindsphereError):
            request_object = GetAssetRequest(if_none_match=None, id="Invalid Id")
            self.client.get_asset(request_object)

    def test_move_asset(self):
        asset_new = Asset()
        asset_new.name = "BMW"
        asset_new.parent_id = ASSET_CLIENT_OLD_PARENT_ID1
        asset_new.type_id = ASSET_CLIENT_ASSET_TYPE
        request_object1 = AddAssetRequest(asset=asset_new)
        asset_object = self.client.add_asset(request_object1)
        selected_asset_id = asset_object.asset_id
        move_parameters = AssetMove()
        move_parameters.new_parent_id = ASSET_CLIENT_OLD_PARENT_ID2
        request_object2 = MoveAssetRequest(
            if_match=str(asset_object.etag),
            id=selected_asset_id,
            move_parameters=move_parameters,
        )
        asset = self.client.move_asset(request_object2)
        self.assertEqual(move_parameters.new_parent_id, asset.parent_id)

        request_object3 = DeleteAssetRequest(
            if_match=str(asset.etag), id=selected_asset_id
        )
        self.client.delete_asset(request_object3)

    def test_move_asset_with_invalid_id(self):
        request_object1 = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        available_assets = self.client.list_assets(request_object1)
        old_parent_id = available_assets.embedded.assets[0].parent_id
        move_parameters = AssetMove()
        move_parameters.new_parent_id = old_parent_id

        with self.assertRaises(MindsphereError):
            request_object2 = MoveAssetRequest(
                if_match="7", id="InvaliId", move_parameters=move_parameters
            )
            self.client.move_asset(request_object2)

    def test_move_asset_with_invalid_move_parameter(self):
        request_object1 = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        available_assets = self.client.list_assets(request_object1)
        selected_asset_id = available_assets.embedded.assets[0].asset_id
        request_object2 = GetAssetRequest(if_none_match="0", id=selected_asset_id)
        asset_object = self.client.get_asset(request_object2)
        move_parameters = AssetMove()
        move_parameters.new_parent_id = "INVALIDID"
        with self.assertRaises(MindsphereError):
            request_object3 = MoveAssetRequest(
                if_match=str(asset_object.etag),
                id=selected_asset_id,
                move_parameters=move_parameters,
            )
            self.client.move_asset(request_object3)

    def test_update_asset_by_id(self):
        asset_new = Asset()
        asset_new.name = "BMW"
        asset_new.parent_id = ASSET_CLIENT_OLD_PARENT_ID1
        asset_new.type_id = ASSET_CLIENT_ASSET_TYPE
        request_object1 = AddAssetRequest(asset=asset_new)
        asset_object = self.client.add_asset(request_object1)
        selected_asset_id = asset_object.asset_id
        old_desc = asset_object.asset_id
        old_name = asset_object.name
        asset_dto = AssetUpdate()
        asset_dto.description = "bmw1"
        asset_dto.name = "mdspsdk10"
        request_object2 = UpdateAssetRequest(
            if_match=str(asset_object.etag), id=selected_asset_id, asset=asset_dto
        )
        asset = self.client.update_asset(request_object2)
        self.assertEqual(asset.description, asset_dto.description)

        # reverting back the updation
        request_object3 = GetAssetRequest(if_none_match=None, id=selected_asset_id)
        asset_object1 = self.client.get_asset(request_object3)
        asset_dto1 = AssetUpdate()
        asset_dto1.description = old_desc
        asset_dto1.name = old_name
        request_object4 = UpdateAssetRequest(
            if_match=str(asset_object1.etag), id=selected_asset_id, asset=asset_dto1
        )
        asset1 = self.client.update_asset(request_object4)
        self.assertEqual(asset1.description, asset_dto1.description)
        request_object5 = DeleteAssetRequest(
            if_match=str(asset1.etag), id=selected_asset_id
        )
        self.client.delete_asset(request_object5)

    def test_update_asset_by_id_with_invalid_id(self):
        id1 = "f64edc3540214384ae3b5478d0c7f3e3ssINVALID"
        asset = AssetUpdate()
        asset.description = "bmw1"
        asset.name = "mdspsdk10"
        with self.assertRaises(MindsphereError):
            request_object = UpdateAssetRequest(if_match="10", id=id1, asset=asset)
            self.client.update_asset(request_object)

    def test_update_asset_by_id_with_no_id(self):
        asset = AssetUpdate()
        asset.description = "bmw1"
        asset.name = "mdspsdk10"
        with self.assertRaises(MindsphereError):
            request_object = UpdateAssetRequest(if_match="10", id=None, asset=asset)
            self.client.update_asset(request_object)

    def test_update_asset_by_id_with_no_asset_update(self):
        request_object1 = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        available_assets = self.client.list_assets(request_object1)
        selected_asset_id = available_assets.embedded.assets[1].asset_id
        with self.assertRaises(MindsphereError):
            request_object2 = UpdateAssetRequest(
                if_match="10", id=selected_asset_id, asset=None
            )
            self.client.update_asset(request_object2)

    def test_add_asset(self):
        asset_dto = Asset()
        asset_dto.name = "BMW"
        asset_dto.parent_id = ASSET_CLIENT_OLD_PARENT_ID1
        asset_dto.type_id = ASSET_CLIENT_ASSET_TYPE
        request_object1 = AddAssetRequest(asset=asset_dto)
        asset = self.client.add_asset(request_object1)
        self.assertIsNotNone(asset.asset_id)
        request_object2 = DeleteAssetRequest(
            if_match=str(asset.etag), id=asset.asset_id
        )
        self.client.delete_asset(request_object2)

    def test_add_asset_invalid_params(self):
        asset_dto = Asset()
        asset_dto.name = "AssetTest1"
        asset_dto.parent_id = ASSET_CLIENT_OLD_PARENT_ID1 + "imn"
        asset_dto.type_id = ASSET_CLIENT_ASSET_TYPE
        with self.assertRaises(MindsphereError):
            request_object = AddAssetRequest(asset=asset_dto)
            self.client.add_asset(request_object)

    def test_add_asset_invalid_variables(self):
        asset_dto = Asset()
        asset_dto.name = "BMW"
        asset_dto.parent_id = ASSET_CLIENT_OLD_PARENT_ID1
        asset_dto.type_id = ASSET_TYPE_CLIENT_ID
        variable1 = Variable(name="123", value="1234")
        variable_list1 = [variable1]
        asset_dto.variables = variable_list1
        with self.assertRaises(MindsphereError):
            request_object = AddAssetRequest(asset=asset_dto)
            self.client.add_asset(request_object)

    def test_add_asset_invalid_parent_id(self):
        asset_dto = Asset()
        asset_dto.name = "AssetTest1"
        asset_dto.parent_id = "INVALID"
        asset_dto.type_id = ASSET_TYPE_CLIENT_ID
        with self.assertRaises(MindsphereError):
            request_object = AddAssetRequest(asset=asset_dto)
            self.client.add_asset(request_object)

    def test_get_root_asset(self):
        request_object = GetRootAssetRequest(if_none_match=None)
        asset = self.client.get_root_asset(request_object)
        self.assertEqual(asset.parent_id, "")

    def test_delete_asset(self):
        asset_dto = Asset()
        asset_dto.name = "BMW1"
        asset_dto.parent_id = ASSET_CLIENT_OLD_PARENT_ID1
        asset_dto.type_id = ASSET_TYPE_CLIENT_ID
        request_object1 = AddAssetRequest(asset=asset_dto)
        asset = self.client.add_asset(request_object1)
        self.assertIsNotNone(asset.asset_id)
        request_object2 = DeleteAssetRequest(
            if_match=str(asset.etag), id=asset.asset_id
        )
        self.client.delete_asset(request_object2)

    def test_delete_asset_with_no_id(self):
        with self.assertRaises(MindsphereError):
            request_object = DeleteAssetRequest(if_match=None, id="0")
            self.client.delete_asset(request_object)

    def test_delete_asset_with_invalid_id(self):
        with self.assertRaises(MindsphereError):
            request_object = DeleteAssetRequest(
                if_match=None, id="ae397427af154af5be6490fedf51e5dInvalid"
            )
            self.client.delete_asset(request_object)

    def test_save_asset_file_assignment(self):
        request_object1 = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        asset_object = self.client.list_assets(request_object1).embedded.assets[0]
        id1 = asset_object.asset_id
        key = "Demo1"
        assignment = KeyedFileAssignment(file_id=ASSET_CLIENT_FILE_ID)
        request_object2 = GetAssetRequest(if_none_match=None, id=id1)
        asset_data = self.client.get_asset(request_object2)
        if_match = asset_data.etag
        request_object3 = SaveAssetFileAssignmentRequest(
            if_match=str(if_match), assignment=assignment, id=id1, key=key
        )
        asset_data = self.client.save_asset_file_assignment(request_object3)
        for i in asset_data.file_assignments:
            if i.key == key:
                self.assertEqual(i.file_id, ASSET_CLIENT_FILE_ID)

    def test_save_asset_file_assignment_invalid_id(self):
        request_object1 = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        asset_object = self.client.list_assets(request_object1).embedded.assets[0]
        id1 = asset_object.asset_id
        key = "Demo1"
        assignment = KeyedFileAssignment(file_id=ASSET_CLIENT_FILE_ID)
        request_object2 = GetAssetRequest(if_none_match=None, id=id1)
        asset_data = self.client.get_asset(request_object2)
        if_match = asset_data.etag
        with self.assertRaises(MindsphereError):
            request_object3 = SaveAssetFileAssignmentRequest(
                if_match=str(if_match), assignment=assignment, id="INVALID", key=key
            )
            self.client.save_asset_file_assignment(request_object3)

    def test_delete_file_assignment(self):
        asset_dto = Asset()
        asset_dto.name = "BMW"
        asset_dto.parent_id = ASSET_CLIENT_OLD_PARENT_ID1
        asset_dto.type_id = ASSET_CLIENT_ASSET_TYPE
        request_object1 = AddAssetRequest(asset=asset_dto)
        asset_object = self.client.add_asset(request_object1)
        id1 = asset_object.asset_id
        key = "DemoTest"
        assignment = KeyedFileAssignment(file_id=ASSET_CLIENT_FILE_ID)
        request_object2 = GetAssetRequest(if_none_match=None, id=id1)
        asset_data = self.client.get_asset(request_object2)
        if_match = asset_data.etag
        request_object3 = SaveAssetFileAssignmentRequest(
            if_match=str(if_match), assignment=assignment, id=id1, key=key
        )
        asset_data = self.client.save_asset_file_assignment(request_object3)
        for i in asset_data.file_assignments:
            if i.key == key:
                self.assertEqual(i.file_id, ASSET_CLIENT_FILE_ID)
        if_match = asset_data.etag
        request_object4 = DeleteAssetFileAssigmentRequest(
            if_match=str(if_match), id=id1, key=key
        )
        self.client.delete_asset_file_assigment(request_object4)

    def test_delete_file_assignment_invalid_id(self):
        request_object1 = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        asset_object = self.client.list_assets(request_object1).embedded.assets[0]
        id1 = asset_object.asset_id
        key = "Demo1"
        request_object2 = GetAssetRequest(if_none_match=None, id=id1)
        asset_data = self.client.get_asset(request_object2)
        if_match = asset_data.etag
        with self.assertRaises(MindsphereError):
            request_object3 = DeleteAssetFileAssigmentRequest(
                if_match=str(if_match), id="INVALID", key=key
            )
            self.client.delete_asset_file_assigment(request_object3)

    def test_save_asset_file_assignment_with_no_id(self):
        request_object1 = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        asset_object = self.client.list_assets(request_object1).embedded.assets[0]
        id1 = asset_object.asset_id
        key = "Demo1"
        request_object2 = GetAssetRequest(if_none_match=None, id=id1)
        asset_data = self.client.get_asset(request_object2)
        if_match = asset_data.etag
        assignment = KeyedFileAssignment(file_id=ASSET_CLIENT_FILE_ID)
        with self.assertRaises(MindsphereError):
            request_object3 = SaveAssetFileAssignmentRequest(
                if_match=str(if_match), assignment=assignment, id="INVALID", key=key
            )
            self.client.save_asset_file_assignment(request_object3)

    def test_delete_file_assignment_with_no_id(self):
        request_object1 = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        asset_object = self.client.list_assets(request_object1).embedded.assets[0]
        id1 = asset_object.asset_id
        key = "Demo1"
        request_object2 = GetAssetRequest(if_none_match=None, id=id1)
        asset_data = self.client.get_asset(request_object2)
        if_match = asset_data.etag
        with self.assertRaises(MindsphereError):
            request_object3 = DeleteAssetFileAssigmentRequest(
                if_match=str(if_match), id=None, key=key
            )
            self.client.delete_asset_file_assigment(request_object3)

    def test_save_asset_file_assignment_with_no_key(self):
        request_object1 = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        asset_object = self.client.list_assets(request_object1).embedded.assets[0]
        id1 = asset_object.asset_id
        assignment = KeyedFileAssignment(file_id=ASSET_CLIENT_FILE_ID)
        request_object2 = GetAssetRequest(if_none_match=None, id=id1)
        asset_data = self.client.get_asset(request_object2)
        if_match = asset_data.etag
        with self.assertRaises(MindsphereError):
            request_object3 = SaveAssetFileAssignmentRequest(
                if_match=str(if_match), assignment=assignment, id=id1, key=None
            )
            self.client.save_asset_file_assignment(request_object3)

    def test_delete_file_assignment_with_no_key(self):
        request_object1 = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        asset_object = self.client.list_assets(request_object1).embedded.assets[0]
        id1 = asset_object.asset_id
        request_object2 = GetAssetRequest(if_none_match=None, id=id1)
        asset_data = self.client.get_asset(request_object2)
        if_match = asset_data.etag
        with self.assertRaises(MindsphereError):
            request_object3 = DeleteAssetFileAssigmentRequest(
                if_match=if_match, id=id1, key=None
            )
            self.client.delete_asset_file_assigment(request_object3)

    def test_save_asset_file_assignment_with_no_assignment(self):
        request_object1 = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        asset_object = self.client.list_assets(request_object1).embedded.assets[0]
        id1 = asset_object.asset_id
        key = "Demo1"
        assignment = KeyedFileAssignment()
        request_object2 = GetAssetRequest(if_none_match=None, id=id1)
        asset_data = self.client.get_asset(request_object2)
        if_match = asset_data.etag
        with self.assertRaises(MindsphereError):
            request_object3 = SaveAssetFileAssignmentRequest(
                if_match=str(if_match), assignment=assignment, id=id1, key=key
            )
            self.client.save_asset_file_assignment(request_object3)

    def test_save_asset_file_assignment_with_no_if_match(self):
        request_object1 = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        asset_object = self.client.list_assets(request_object1).embedded.assets[0]
        id1 = asset_object.asset_id
        key = "Demo1"
        assignment = KeyedFileAssignment()
        with self.assertRaises(MindsphereError):
            request_object2 = SaveAssetFileAssignmentRequest(
                if_match=None, assignment=assignment, id=id1, key=key
            )
            self.client.save_asset_file_assignment(request_object2)

    def test_delete_file_assignment_with_no_if_match(self):
        request_object1 = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        asset_object = self.client.list_assets(request_object1).embedded.assets[0]
        id1 = asset_object.asset_id
        key = "Demo1"
        with self.assertRaises(MindsphereError):
            request_object2 = DeleteAssetFileAssigmentRequest(
                if_match=None, id=id1, key=key
            )
            self.client.delete_asset_file_assigment(request_object2)

    def test_save_asset_file_assignment_with_invalid_if_match(self):
        request_object1 = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        asset_object = self.client.list_assets(request_object1).embedded.assets[0]
        id1 = asset_object.asset_id
        key = "Demo1"
        assignment = KeyedFileAssignment()
        with self.assertRaises(MindsphereError):
            request_object2 = SaveAssetFileAssignmentRequest(
                if_match="INVALID", assignment=assignment, id=id1, key=key
            )
            self.client.save_asset_file_assignment(request_object2)

    def test_delete_file_assignment_with_invalid_if_match(self):
        request_object1 = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        asset_object = self.client.list_assets(request_object1).embedded.assets[0]
        id1 = asset_object.asset_id
        key = "Demo1"
        with self.assertRaises(MindsphereError):
            request_object2 = DeleteAssetFileAssigmentRequest(
                if_match="INVALID", id=id1, key=key
            )
            self.client.delete_asset_file_assigment(request_object2)

    def test_save_asset_file_assignment_with_invalid_file_id(self):
        request_object1 = ListAssetsRequest(
            filter=None, if_none_match=None, size=10, page=0, sort=None
        )
        asset_object = self.client.list_assets(request_object1).embedded.assets[0]
        id1 = asset_object.asset_id
        key = "Demo1"
        assignment = KeyedFileAssignment(file_id="INVALID")
        request_object2 = GetAssetRequest(if_none_match=None, id=id1)
        asset_data = self.client.get_asset(request_object2)
        if_match = asset_data.etag
        with self.assertRaises(MindsphereError):
            request_object3 = SaveAssetFileAssignmentRequest(
                if_match=str(if_match), assignment=assignment, id=id1, key=key
            )
            self.client.save_asset_file_assignment(request_object3)

    def test_integration(self):
        asset_dto_new = Asset()
        asset_dto_new.name = "BMW"
        asset_dto_new.parent_id = ASSET_CLIENT_OLD_PARENT_ID1
        asset_dto_new.type_id = ASSET_CLIENT_ASSET_TYPE
        request_object1 = AddAssetRequest(asset=asset_dto_new)
        asset_object = self.client.add_asset(request_object1)
        selected_asset_id = asset_object.asset_id
        self.assertIsNotNone(selected_asset_id)

        request_object2 = GetAssetRequest(
            if_none_match=str(asset_object.etag), id=selected_asset_id
        )
        asset1 = self.client.get_asset(request_object2)
        self.assertEqual(asset1.asset_id, selected_asset_id)

        asset_dto = AssetUpdate()
        asset_dto.description = "bmw1"
        asset_dto.name = "mdspsdk10"

        request_object3 = UpdateAssetRequest(
            if_match=str(asset_object.etag), id=selected_asset_id, asset=asset_dto
        )
        self.client.update_asset(request_object3)

        key = "Demo1"
        assignment = KeyedFileAssignment()
        assignment.file_id = ASSET_CLIENT_FILE_ID
        request_object4 = GetAssetRequest(if_none_match=None, id=selected_asset_id)
        asset_data = self.client.get_asset(request_object4)

        request_object5 = SaveAssetFileAssignmentRequest(
            if_match=str(asset_data.etag),
            assignment=assignment,
            id=selected_asset_id,
            key=key,
        )
        asset_data = self.client.save_asset_file_assignment(request_object5)

        request_object6 = DeleteAssetRequest(
            if_match=str(asset_data.etag), id=selected_asset_id
        )
        self.client.delete_asset(request_object6)

    def test_asset_delete_confirmation(self):
        asset_dto_new = Asset()
        asset_dto_new.name = 'BMW'
        asset_dto_new.parent_id = ASSET_CLIENT_OLD_PARENT_ID1
        asset_dto_new.type_id = ASSET_CLIENT_ASSET_TYPE
        request_object1 = AddAssetRequest(asset=asset_dto_new)
        asset_object = self.client.add_asset(request_object1)
        selected_asset_id = asset_object.asset_id
        self.assertIsNotNone(selected_asset_id)
        request_object = DeleteAssetConfirmationRequest(id=asset_object.asset_id, if_match=0)
        response = self.client.delete_asset_with_confirmation(request_object)
        self.assertTrue(response)

    def test_get_asset_equal_to(self):
        response = self.client.get_assets_equals_to(field_type=FieldTypeEnum.NAME, filter_value="1233")
        self.assertEqual('1233', response.embedded.assets[0].name)

    def test_negative_asset_equal_to(self):
        with self.assertRaises(MindsphereError):
            self.client.get_assets_equals_to(field_type=FieldTypeEnum.PARENT_TYPE_ID, filter_value="1233")

    def test_get_assets_like(self):
        response = self.client.get_assets_like(FieldTypeEnum.NAME, "asset sdk 27_3", "asset sdk 28_1")
        self.assertIsNotNone(response)

    def test_negative_get_assets_like(self):
        with self.assertRaises(MindsphereError):
            self.client.get_assets_like(FieldTypeEnum.PARENT_TYPE_ID, "asset sdk 27_3", "asset sdk 28_1")

    def test_get_assets_starts_with(self):
        response = self.client.get_assets_starts_with(field_type=FieldTypeEnum.PARENT_ID, filter_value="0ba09fbe8bad4868")
        self.assertEqual('1233', response.embedded.assets[0].name)

    def test_negative_get_assets_starts_with(self):
        with self.assertRaises(MindsphereError):
            self.client.get_assets_starts_with(field_type=FieldTypeEnum.PARENT_TYPE_ID, filter_value="1233")

    def test_get_assets_ends_with(self):
        response = self.client.get_assets_ends_with(field_type=FieldTypeEnum.PARENT_ID, filter_value="93125b1156aa2eaa")
        self.assertEqual('1233', response.embedded.assets[0].name)

    def test_negative_get_assets_ends_with(self):
        with self.assertRaises(MindsphereError):
            self.client.get_assets_ends_with(field_type=FieldTypeEnum.PARENT_TYPE_ID, filter_value="93125b1156aa2eaa")

    def test_get_assets_ends_with_for_name(self):
        response = self.client.get_assets_contains(field_type=FieldTypeEnum.NAME, filter_value="23")
        self.assertEqual('1233', response.embedded.assets[0].name)

    def test_get_assets_of_type(self):
        response = self.client.get_assets_of_type("mdspsdk.Tyre")
        print(response)


if __name__ == "__main__":
    unittest.main()
