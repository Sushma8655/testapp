import unittest

from mindsphere_core import mindsphere_core
from assetmanagement.clients import LocationsClient
from mindsphere_core.exceptions import MindsphereError
from assetmanagement.clients import AssetsClient
from assetmanagement.models import Location
from assetmanagement.models import SaveAssetLocationRequest
from assetmanagement.models import GetAssetRequest
from assetmanagement.models import DeleteAssetLocationRequest
from tests.data.test_data import *

location = Location()
location.country = "Austria"
location.region = "dd 2"
location.longitude = 53.5125546
location.locality = "Innsbruck"
location.latitude = 9.9763411
location.postal_code = None
id1 = ASSET_LOCATION_CLIENT_ID


class TestAssetLocationClientApi(unittest.TestCase):
    def setUp(self):
        config = mindsphere_core.RestClientConfig("194.138.0.25", "9400")
        self.location_client = LocationsClient(rest_client_config=config)
        self.asset_client = AssetsClient(rest_client_config=config)

    def test_save_asset_location(self):
        request_object1 = GetAssetRequest(None, id1)
        asset = self.asset_client.get_asset(request_object1)
        request_object2 = SaveAssetLocationRequest(str(asset.etag), location, id1)
        self.location_client.save_asset_location(request_object2)

    def test_save_asset_location_with_no_id(self):
        with self.assertRaises(MindsphereError):
            request_object1 = GetAssetRequest(None, id1)
            asset = self.asset_client.get_asset(request_object1)
            request_object2 = SaveAssetLocationRequest(str(asset.etag), location, None)
            self.location_client.save_asset_location(request_object2)

    def test_save_asset_location_with_no_location(self):
        with self.assertRaises(MindsphereError):
            request_object1 = GetAssetRequest(None, id1)
            asset = self.asset_client.get_asset(request_object1)
            request_object2 = SaveAssetLocationRequest(str(asset.etag), None, id1)
            self.location_client.save_asset_location(request_object2)

    def test_save_asset_location_with_no_if_match(self):
        with self.assertRaises(MindsphereError):
            request_object = SaveAssetLocationRequest(None, location, id1)
            self.location_client.save_asset_location(request_object)

    def test_save_asset_location_with_invalid_id(self):
        with self.assertRaises(MindsphereError):
            request_object1 = GetAssetRequest(None, id1)
            asset = self.asset_client.get_asset(request_object1)
            request_object2 = SaveAssetLocationRequest(
                str(asset.etag), location, "Invalid"
            )
            self.location_client.save_asset_location(request_object2)

    def test_save_asset_location_with_invalid_if_match(self):
        with self.assertRaises(MindsphereError):
            request_object = SaveAssetLocationRequest("789", location, id1)
            self.location_client.save_asset_location(request_object)

    def test_save_asset_location_with_invalid_longitude(self):
        with self.assertRaises(MindsphereError):
            location.longitude = 190
            request_object1 = GetAssetRequest(None, id1)
            asset = self.asset_client.get_asset(request_object1)
            request_object2 = SaveAssetLocationRequest(str(asset.etag), location, id1)
            self.location_client.save_asset_location(request_object2)

    def test_delete_asset_location(self):
        request_object1 = GetAssetRequest(None, id1)
        asset = self.asset_client.get_asset(request_object1)
        # save asset location
        request_object2 = SaveAssetLocationRequest(str(asset.etag), location, id1)
        self.location_client.save_asset_location(request_object2)
        request_object3 = GetAssetRequest(None, id1)
        asset1 = self.asset_client.get_asset(request_object3)
        # delete asset location
        request_object4 = DeleteAssetLocationRequest(if_match=str(asset1.etag), id=id1)
        self.location_client.delete_asset_location(request_object4)

    def test_delete_asset_location_with_no_id(self):
        with self.assertRaises(MindsphereError):
            request_object1 = GetAssetRequest(None, id1)
            asset = self.asset_client.get_asset(request_object1)
            request_object2 = DeleteAssetLocationRequest(
                if_match=str(asset.etag), id=None
            )
            self.location_client.delete_asset_location(request_object2)

    def test_delete_asset_location_with_no_if_match(self):
        with self.assertRaises(MindsphereError):
            request_object = DeleteAssetLocationRequest(if_match=None, id=id1)
            self.location_client.delete_asset_location(request_object)

    def test_delete_asset_location_with_invalid_id(self):
        with self.assertRaises(MindsphereError):
            request_object1 = GetAssetRequest(None, id1)
            asset = self.asset_client.get_asset(request_object1)
            request_object2 = DeleteAssetLocationRequest(
                if_match=str(asset.etag), id="Invalid"
            )
            self.location_client.delete_asset_location(request_object2)

    def test_delete_asset_location_with_invalid_if_match(self):
        with self.assertRaises(MindsphereError):
            request_object2 = DeleteAssetLocationRequest(if_match="8688", id=id1)
            self.location_client.delete_asset_location(request_object2)

    def test_integration(self):
        request_object1 = GetAssetRequest(None, id1)
        asset = self.asset_client.get_asset(request_object1)
        request_object2 = SaveAssetLocationRequest(str(asset.etag), location, id1)
        self.location_client.save_asset_location(request_object2)
        request_object3 = GetAssetRequest(None, id1)
        asset1 = self.asset_client.get_asset(request_object3)
        request_object4 = DeleteAssetLocationRequest(if_match=str(asset1.etag), id=id1)
        self.location_client.delete_asset_location(request_object4)


if __name__ == "__main__":
    unittest.main()
