import unittest

from mindsphere_core import mindsphere_core
from assetmanagement.clients import StructureClient
from mindsphere_core.exceptions import MindsphereError
from assetmanagement.models import ListAssetAspectsRequest
from assetmanagement.models import ListAssetVariablesRequest
from tests.data.test_data import *


id1 = ASSET_LOCATION_CLIENT_ID


class TestAspectTypeApi(unittest.TestCase):
    def setUp(self):

        config = mindsphere_core.RestClientConfig("194.138.0.25", "9400")
        self.client = StructureClient(rest_client_config=config)

    def test_list_asset_aspects_by_asset_id(self):
        request_object = ListAssetAspectsRequest(
            filter=None, if_none_match=None, size=10, id=id1, page=0, sort=None
        )
        aspects = self.client.list_asset_aspects(request_object)
        self.assertIsNotNone(len(aspects.embedded.aspects))

    def test_list_asset_aspects_by_asset_id_checking_filter(self):
        request_object = ListAssetAspectsRequest(
            filter='{"name":"aspecttypename"}',
            if_none_match=None,
            size=10,
            id=id1,
            page=0,
            sort=None,
        )
        aspects = self.client.list_asset_aspects(request_object)
        self.assertIsNotNone(len(aspects.embedded.aspects))

    def test_list_asset_aspects_by_asset_id_with_all_params(self):
        request_object = ListAssetAspectsRequest(
            filter=None, if_none_match="0", size=10, id=id1, page=0, sort="name"
        )
        aspects = self.client.list_asset_aspects(request_object)
        self.assertIsNotNone(len(aspects.embedded.aspects))
        self.assertTrue(len(aspects.embedded.aspects) > 0)

    def test_list_asset_aspects_by_asset_id_page_size(self):
        request_object = ListAssetAspectsRequest(
            filter=None, if_none_match=None, size=10, id=id1, page=0, sort=None
        )
        aspects = self.client.list_asset_aspects(request_object)
        self.assertIsNotNone(len(aspects.embedded.aspects))
        self.assertTrue(len(aspects.embedded.aspects) > 0)

    def test_list_asset_aspects_by_asset_id_sort_filter(self):
        request_object = ListAssetAspectsRequest(
            filter=None, if_none_match=None, size=10, id=id1, page=0, sort="name"
        )
        aspects = self.client.list_asset_aspects(request_object)
        self.assertIsNotNone(len(aspects.embedded.aspects))

    def test_list_asset_aspects_by_id_sort_filter(self):
        request_object1 = ListAssetAspectsRequest(
            filter=None, if_none_match=None, size=10, id=id1, page=0, sort=None
        )
        all_aspects = self.client.list_asset_aspects(request_object1)
        filter_name = all_aspects.embedded.aspects[0].name
        filter_input = '{"name":"' + filter_name + '"}'

        request_object2 = ListAssetAspectsRequest(
            filter=filter_input,
            if_none_match=None,
            size=10,
            id=id1,
            page=0,
            sort="length,asc",
        )
        aspects = self.client.list_asset_aspects(request_object2)
        self.assertIsNotNone(len(aspects.embedded.aspects))
        self.assertTrue(len(aspects.embedded.aspects) > 0)

    def test_list_asset_aspects_with_invalid_id(self):
        id2 = "InvalidId"
        with self.assertRaises(MindsphereError):
            request_object = ListAssetAspectsRequest(
                filter=None,
                if_none_match=None,
                size=10,
                id=id2,
                page=0,
                sort="name,desc",
            )
            self.client.list_asset_aspects(request_object)

    def test_list_asset_aspects_with_no_id(self):
        id2 = None
        with self.assertRaises(MindsphereError):
            request_object = ListAssetAspectsRequest(
                filter=None,
                if_none_match=None,
                size=10,
                id=id2,
                page=0,
                sort="name,desc",
            )
            self.client.list_asset_aspects(request_object)

    def test_list_asset_aspects_with_invalid_filter(self):
        with self.assertRaises(MindsphereError):
            request_object = ListAssetAspectsRequest(
                filter="invalid eq 'x'",
                if_none_match=None,
                size=10,
                id=id1,
                page=0,
                sort="name",
            )
            self.client.list_asset_aspects(request_object)

    def test_list_asset_aspects_with_invalid_sort(self):
        request_object = ListAssetAspectsRequest(
            filter=None, if_none_match=None, size=10, id=id1, page=0, sort="InvalidSort"
        )
        aspects = self.client.list_asset_aspects(request_object)
        self.assertIsNotNone(len(aspects.embedded.aspects))
        self.assertTrue(len(aspects.embedded.aspects) > 0)

    def test_list_asset_variables_by_asset_id(self):
        request_object = ListAssetVariablesRequest(
            filter=None, if_none_match=None, size=10, id=id1, page=0, sort="name,desc"
        )
        variables = self.client.list_asset_variables(request_object)
        self.assertIsNotNone(variables)
        self.assertIsNotNone(len(variables.embedded.variables))
        self.assertTrue(len(variables.embedded.variables) > 0)

    def test_list_asset_variables_by_all_params(self):
        request_object = ListAssetVariablesRequest(
            filter=None, if_none_match="0", size=10, id=id1, page=0, sort="length,asc"
        )
        variables = self.client.list_asset_variables(request_object)
        self.assertIsNotNone(variables)
        self.assertIsNotNone(len(variables.embedded.variables))
        self.assertTrue(len(variables.embedded.variables) > 0)

    def test_list_asset_variables_by_page_size(self):
        request_object = ListAssetVariablesRequest(
            filter=None, if_none_match="0", size=10, id=id1, page=0, sort="length,asc"
        )
        variables = self.client.list_asset_variables(request_object)
        self.assertIsNotNone(variables)
        self.assertIsNotNone(len(variables.embedded.variables))
        self.assertTrue(len(variables.embedded.variables) > 0)

    def test_list_asset_variables_by_sort_filter(self):
        request_object = ListAssetVariablesRequest(
            filter=None, if_none_match="0", size=10, id=id1, page=0, sort="length,asc"
        )
        variables = self.client.list_asset_variables(request_object)
        self.assertIsNotNone(variables)

    def test_list_asset_variables_with_invalid_id(self):
        id2 = "InvalidId"
        with self.assertRaises(MindsphereError):
            request_object = ListAssetVariablesRequest(
                filter=None,
                if_none_match="0",
                size=10,
                id=id2,
                page=0,
                sort="length,asc",
            )
            self.client.list_asset_variables(request_object)

    def test_list_asset_variables_with_no_id(self):
        id2 = None
        with self.assertRaises(MindsphereError):
            request_object = ListAssetVariablesRequest(
                filter=None,
                if_none_match="0",
                size=10,
                id=id2,
                page=0,
                sort="length,asc",
            )
            self.client.list_asset_variables(request_object)

    def test_list_asset_variables_with_invalid_filter(self):
        with self.assertRaises(MindsphereError):
            request_object = ListAssetVariablesRequest(
                filter="invalid eq x",
                if_none_match=None,
                size=10,
                id=id1,
                page=0,
                sort="name",
            )
            self.client.list_asset_variables(request_object)

    def test_list_asset_variables_with_invalid_sort(self):
        request_object = ListAssetVariablesRequest(
            filter=None, if_none_match=None, size=10, id=id1, page=0, sort="invalidSort"
        )
        variables = self.client.list_asset_variables(request_object)
        self.assertIsNotNone(len(variables.embedded.variables))
        self.assertTrue(len(variables.embedded.variables) > 0)

    def test_integration(self):
        request_object1 = ListAssetAspectsRequest(
            filter=None, if_none_match=None, size=10, id=id1, page=0, sort="invalidSort"
        )
        aspects = self.client.list_asset_aspects(request_object1)
        self.assertIsNotNone(len(aspects.embedded.aspects))

        request_object2 = ListAssetVariablesRequest(
            filter=None, if_none_match=None, size=10, id=id1, page=0, sort="invalidSort"
        )
        variables = self.client.list_asset_variables(request_object2)
        self.assertIsNotNone(variables)

        request_object3 = ListAssetVariablesRequest(
            filter=None, if_none_match="0", size=10, id=id1, page=0, sort="length,asc"
        )
        variables1 = self.client.list_asset_variables(request_object3)
        self.assertIsNotNone(variables1)


if __name__ == "__main__":
    unittest.main()
