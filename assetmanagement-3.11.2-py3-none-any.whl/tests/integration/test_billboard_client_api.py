import unittest

from mindsphere_core import mindsphere_core, TenantCredentials
from assetmanagement.clients import BillboardClient
from tests.data.test_data import *


class TestBillboardClientApi(unittest.TestCase):
    def setUp(self):
        config = mindsphere_core.RestClientConfig("194.138.0.25", "9400")
        self.client = BillboardClient(rest_client_config=config)

    def test_get_billboard_with_sub_tenant(self):
        credentials = TenantCredentials(
            client_id=CLIENT_ID_SUB_TENANT,
            client_secret=CLIENT_SECRET_SUB_TENANT,
            tenant=TENANT,
            sub_tenant=SUB_TENANT,
            use_sub_tenant=True,
        )
        config = mindsphere_core.RestClientConfig(
            proxy_host="194.138.0.25", proxy_port="9400", host_environment="eu1"
        )
        client = BillboardClient(config, credentials)
        billboard_resource = client.get_billboard()
        self.assertIsNotNone(billboard_resource)

    def test_get_billboard(self):
        billboard_resource = self.client.get_billboard()
        self.assertIsNotNone(billboard_resource)


if __name__ == "__main__":
    unittest.main()
