import unittest
import random
import os
from tests.data.test_data import *

from mindsphere_core import mindsphere_core
from mindsphere_core.exceptions import MindsphereError
from assetmanagement.clients import FilesClient
from assetmanagement.models import DeleteFileRequest
from assetmanagement.models import DownloadFileRequest
from assetmanagement.models import GetFileRequest
from assetmanagement.models import ListFilesRequest
from assetmanagement.models import ReplaceFileRequest
from assetmanagement.models import UploadFileRequest


file_id = ASSET_FILE_CLIENT_FILE_ID
file_name = "test"


class TestAssetFileClientApi(unittest.TestCase):
    def setUp(self):
        config = mindsphere_core.RestClientConfig("194.138.0.25", "9400")
        self.client = FilesClient(rest_client_config=config)

    def test_create_asset_files(self):
        file_name1 = "integ_" + str(self.get_random_number())
        path = os.path.abspath(__file__)
        # Make the file point to data folder
        config_file = os.path.dirname(path) + r"/sample_file.txt"
        request = UploadFileRequest(config_file, "private", file_name1, file_name1)
        resource = self.client.upload_file(request)
        self.assertIsNotNone(resource)

    def test_create_asset_files_invalid_file(self):
        file_name1 = "integ_" + str(self.get_random_number())
        with self.assertRaises(FileNotFoundError):
            current_file = open("test1.txt")
            request = UploadFileRequest(current_file, "private", file_name, file_name1)
            self.client.upload_file(request)

    def test_create_asset_files_existing_id(self):
        file_name1 = None
        request = ListFilesRequest(
            page=0, size=10, sort=None, filter=None, if_none_match=None
        )
        asset_files = self.client.list_files(request)
        if (
            (asset_files is not None)
            and (len(asset_files.embedded.files) is not None)
            and (asset_files.embedded.files is not None)
        ):
            file_name1 = asset_files.embedded.files[0].name

        path = os.path.abspath(__file__)
        config_file = os.path.dirname(path) + r"/sample_file.txt"
        with self.assertRaises(MindsphereError):
            request = UploadFileRequest(config_file, "private", file_name1, file_name1)
            self.client.upload_file(request)

    def test_get_files(self):
        request = ListFilesRequest(
            page=0, size=10, sort=None, filter=None, if_none_match=None
        )
        asset_files = self.client.list_files(request)
        self.assertIsNotNone(asset_files)

    def test_get_asset_files_with_page_size(self):
        request = ListFilesRequest(
            page=0, size=3, sort=None, filter=None, if_none_match=None
        )
        asset_files = self.client.list_files(request)
        self.assertIsNotNone(asset_files)
        self.assertTrue(0 < len(asset_files.embedded.files) <= 3)

    def test_get_asset_files_with_invalid_page(self):
        request = ListFilesRequest(
            page=99999, size=3, sort=None, filter=None, if_none_match=None
        )
        asset_files = self.client.list_files(request)
        self.assertIsNotNone(asset_files)
        self.assertEqual(len(asset_files.embedded.files), 0)

    def test_download_file(self):
        request = DownloadFileRequest(file_id)
        file_contents = self.client.download_file(request)
        print(file_contents)
        self.assertIsNotNone(file_contents)

    def test_get_asset_files_with_sort_filter(self):
        filter_input = '{"name":"' + file_name + '"}'
        request = ListFilesRequest(
            page=0, size=10, sort="asc", filter=filter_input, if_none_match=None
        )
        asset_files = self.client.list_files(request)
        self.assertIsNotNone(asset_files)
        self.assertEqual(asset_files.embedded.files[0].name, file_name)

    def test_get_asset_files_with_invalid_sort_filter(self):
        request = ListFilesRequest(0, 10, "InvalidSort", None, None)
        with self.assertRaises(MindsphereError):
            self.client.list_files(request)

    def test_download_file_invalid_id(self):
        request = DownloadFileRequest("InvalidId")
        with self.assertRaises(MindsphereError):
            self.client.download_file(request)

    def test_get_file_by_id(self):
        request = GetFileRequest(file_id=file_id, if_none_match=None)
        file_metadata_resource = self.client.get_file(request)
        self.assertIsNotNone(file_metadata_resource)
        self.assertEqual(file_metadata_resource.name, file_name)

    def test_get_file_by_invalid_id(self):
        request = GetFileRequest("invalidId", "0")
        with self.assertRaises(MindsphereError):
            self.client.get_file(request)

    def test_get_file_by_id_with_if_none_match(self):
        request = GetFileRequest(file_id=file_id, if_none_match="0")
        file_metadata_resource = self.client.get_file(request)
        self.assertIsNotNone(file_metadata_resource)
        self.assertEqual(file_metadata_resource.name, file_name)

    def test_get_file_by_id_with_if_none_match_invalid_id(self):
        request = GetFileRequest("InvalidId", "0")
        with self.assertRaises(MindsphereError):
            self.client.get_file(request)

    def test_get_file_by_id_with_if_none_match_invalid_etag(self):
        request = GetFileRequest("InvalidId", "x")
        with self.assertRaises(MindsphereError):
            self.client.get_file(request)

    @staticmethod
    def get_random_number():
        return random.randint(1000, 9000) + 1000


if __name__ == "__main__":
    unittest.main()
