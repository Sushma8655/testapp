# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


from __future__ import absolute_import

from mindsphere_core.mindsphere_core import logger
from mindsphere_core import mindsphere_core, exceptions, token_service
from mindsphere_core.token_service import init_credentials


class BillboardClient:
    __base_path__ = '/api/assetmanagement/v3'
    __model_package__ = __name__.split('.')[0]

    def __init__(self, rest_client_config=None, mindsphere_credentials=None):
        self.rest_client_config = rest_client_config
        self.mindsphere_credentials = init_credentials(mindsphere_credentials)

    def get_billboard(self):
        """List all links for available resources

        List all links for available resources


        :return: BillboardResource
        """
        logger.info('BillboardClient.get_billboard() invoked.')

        end_point_url = '/'
        end_point_url = end_point_url.format()
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/hal+json, application/vnd.error+json', 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + str(token)}
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info('BillboardClient.get_billboard()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'GET', query_params, form_params, body_params, local_var_files, 'BillboardResource', self.__model_package__)

