# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


from __future__ import absolute_import

from mindsphere_core.mindsphere_core import logger
from mindsphere_core import mindsphere_core, exceptions, token_service
from mindsphere_core.token_service import init_credentials


class StructureClient:
    __base_path__ = '/api/assetmanagement/v3'
    __model_package__ = __name__.split('.')[0]

    def __init__(self, rest_client_config=None, mindsphere_credentials=None):
        self.rest_client_config = rest_client_config
        self.mindsphere_credentials = init_credentials(mindsphere_credentials)

    def list_asset_aspects(self, request_object):
        """Get all aspects of an asset

        Get all static and dynamic aspects of a given asset 

        :param ListAssetAspectsRequest request_object: It contains the below parameters --> |br| ( id* - Unique identifier ), |br| ( page - Specifies the requested page index ), |br| ( size - Specifies the number of elements in a page ), |br| ( sort - Specifies the ordering of returned elements ), |br| ( filter - Specifies the additional filtering criteria ), |br| ( If-None-Match - ETag hash of previous request to allow caching )

        :return: AspectListResource
        """
        logger.info('StructureClient.list_asset_aspects() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `list_asset_aspects`')

        if request_object.id is None:
            raise exceptions.MindsphereClientError('The required parameter `id` is missing from `request_object`, when calling `list_asset_aspects`')

        end_point_url = '/assets/{id}/aspects'
        end_point_url = end_point_url.format(id=request_object.id)
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/hal+json, application/vnd.error+json', 'Content-Type': 'application/json', 'If-None-Match': request_object.if_none_match, 'Authorization': 'Bearer ' + str(token)}
        query_params = {'page': request_object.page, 'size': request_object.size, 'sort': request_object.sort, 'filter': request_object.filter}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info('StructureClient.list_asset_aspects()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'GET', query_params, form_params, body_params, local_var_files, 'AspectListResource', self.__model_package__)

    def list_asset_variables(self, request_object):
        """Get all variables of an asset

        Get all variables of a given asset including inherited ones 

        :param ListAssetVariablesRequest request_object: It contains the below parameters --> |br| ( id* - Unique identifier ), |br| ( page - Specifies the requested page index ), |br| ( size - Specifies the number of elements in a page ), |br| ( sort - Specifies the ordering of returned elements ), |br| ( filter - Specifies the additional filtering criteria ), |br| ( If-None-Match - ETag hash of previous request to allow caching )

        :return: VariableListResource
        """
        logger.info('StructureClient.list_asset_variables() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `list_asset_variables`')

        if request_object.id is None:
            raise exceptions.MindsphereClientError('The required parameter `id` is missing from `request_object`, when calling `list_asset_variables`')

        end_point_url = '/assets/{id}/variables'
        end_point_url = end_point_url.format(id=request_object.id)
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/hal+json, application/vnd.error+json', 'Content-Type': 'application/json', 'If-None-Match': request_object.if_none_match, 'Authorization': 'Bearer ' + str(token)}
        query_params = {'page': request_object.page, 'size': request_object.size, 'sort': request_object.sort, 'filter': request_object.filter}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info('StructureClient.list_asset_variables()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'GET', query_params, form_params, body_params, local_var_files, 'VariableListResource', self.__model_package__)

