from __future__ import absolute_import

# flake8: noqa

# import apis into api package
from assetmanagement.clients.aspecttype_client import AspecttypeClient
from assetmanagement.clients.assets_client import AssetsClient
from assetmanagement.clients.assettype_client import AssettypeClient
from assetmanagement.clients.billboard_client import BillboardClient
from assetmanagement.clients.files_client import FilesClient
from assetmanagement.clients.locations_client import LocationsClient
from assetmanagement.clients.structure_client import StructureClient
