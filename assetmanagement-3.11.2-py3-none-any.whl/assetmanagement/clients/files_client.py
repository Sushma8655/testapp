# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


from __future__ import absolute_import

from mindsphere_core.mindsphere_core import logger
from mindsphere_core import mindsphere_core, exceptions, token_service
from mindsphere_core.token_service import init_credentials


class FilesClient:
    __base_path__ = '/api/assetmanagement/v3'
    __model_package__ = __name__.split('.')[0]

    def __init__(self, rest_client_config=None, mindsphere_credentials=None):
        self.rest_client_config = rest_client_config
        self.mindsphere_credentials = init_credentials(mindsphere_credentials)

    def delete_file(self, request_object):
        """Delete a file.

        * Deletion is blocked if there are any file assignment with the given fileId. 

        :param DeleteFileRequest request_object: It contains the below parameters --> |br| ( If-Match* - Last known version to facilitate optimistic locking ), |br| ( fileId* - Unique identifier of the file. )

        :return: None
        """
        logger.info('FilesClient.delete_file() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `delete_file`')

        if request_object.if_match is None:
            raise exceptions.MindsphereClientError('The required parameter `If-Match` is missing from `request_object`, when calling `delete_file`')

        if request_object.file_id is None:
            raise exceptions.MindsphereClientError('The required parameter `fileId` is missing from `request_object`, when calling `delete_file`')

        end_point_url = '/files/{fileId}'
        end_point_url = end_point_url.format(fileId=request_object.file_id)
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/hal+json, application/vnd.error+json', 'Content-Type': 'application/json', 'If-Match': request_object.if_match, 'Authorization': 'Bearer ' + str(token)}
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info('FilesClient.delete_file()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'DELETE', query_params, form_params, body_params, local_var_files, None, self.__model_package__)

    def download_file(self, request_object):
        """Returns a file by its id

        Returns a file by its id 

        :param DownloadFileRequest request_object: It contains the below parameters --> |br| ( fileId* - Unique identifier of the file. )

        :return: str
        """
        logger.info('FilesClient.download_file() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `download_file`')

        if request_object.file_id is None:
            raise exceptions.MindsphereClientError('The required parameter `fileId` is missing from `request_object`, when calling `download_file`')

        end_point_url = '/files/{fileId}/file'
        end_point_url = end_point_url.format(fileId=request_object.file_id)
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/base64, application/octet-stream, application/vnd.error+json', 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + str(token)}
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info('FilesClient.download_file()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'GET', query_params, form_params, body_params, local_var_files, 'str', self.__model_package__)

    def get_file(self, request_object):
        """Returns a file's metadata by its id

        Returns a file's metadata by its id 

        :param GetFileRequest request_object: It contains the below parameters --> |br| ( fileId* - Unique identifier of the file. ), |br| ( If-None-Match - ETag hash of previous request to allow caching )

        :return: FileMetadataResource
        """
        logger.info('FilesClient.get_file() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `get_file`')

        if request_object.file_id is None:
            raise exceptions.MindsphereClientError('The required parameter `fileId` is missing from `request_object`, when calling `get_file`')

        end_point_url = '/files/{fileId}'
        end_point_url = end_point_url.format(fileId=request_object.file_id)
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/hal+json, application/vnd.error+json', 'Content-Type': 'application/json', 'If-None-Match': request_object.if_none_match, 'Authorization': 'Bearer ' + str(token)}
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info('FilesClient.get_file()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'GET', query_params, form_params, body_params, local_var_files, 'FileMetadataResource', self.__model_package__)

    def list_files(self, request_object):
        """Get metadata of uploaded files.

        Returns all visible file metadata for the tenant. Will NOT return the files. 

        :param ListFilesRequest request_object: It contains the below parameters --> |br| ( page - Specifies the requested page index ), |br| ( size - Specifies the number of elements in a page ), |br| ( sort - Specifies the ordering of returned elements ), |br| ( filter - Specifies the additional filtering criteria ), |br| ( If-None-Match - ETag hash of previous request to allow caching )

        :return: FileMetadataListResource
        """
        logger.info('FilesClient.list_files() invoked.')

        end_point_url = '/files'
        end_point_url = end_point_url.format()
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/hal+json, application/vnd.error+json', 'Content-Type': 'application/json', 'If-None-Match': request_object.if_none_match, 'Authorization': 'Bearer ' + str(token)}
        query_params = {'page': request_object.page, 'size': request_object.size, 'sort': request_object.sort, 'filter': request_object.filter}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info('FilesClient.list_files()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'GET', query_params, form_params, body_params, local_var_files, 'FileMetadataListResource', self.__model_package__)

    def replace_file(self, request_object):
        """Update a file

        Update a previously uploaded file * Max file size is 5 MB. 

        :param ReplaceFileRequest request_object: It contains the below parameters --> |br| ( If-Match* - Last known version to facilitate optimistic locking ), |br| ( fileId* - Unique identifier of the file. ), |br| ( file* - The file to upload. The file size cannot be more than 5 MB. ), |br| ( name* - The name of the file ), |br| ( scope* - The scope of the file ), |br| ( description - The description of the file )

        :return: FileMetadataResource
        """
        logger.info('FilesClient.replace_file() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `replace_file`')

        if request_object.if_match is None:
            raise exceptions.MindsphereClientError('The required parameter `If-Match` is missing from `request_object`, when calling `replace_file`')

        if request_object.file_id is None:
            raise exceptions.MindsphereClientError('The required parameter `fileId` is missing from `request_object`, when calling `replace_file`')

        if request_object.file is None:
            raise exceptions.MindsphereClientError('The required parameter `file` is missing from `request_object`, when calling `replace_file`')

        if request_object.name is None:
            raise exceptions.MindsphereClientError('The required parameter `name` is missing from `request_object`, when calling `replace_file`')

        if request_object.scope is None:
            raise exceptions.MindsphereClientError('The required parameter `scope` is missing from `request_object`, when calling `replace_file`')

        end_point_url = '/files/{fileId}'
        end_point_url = end_point_url.format(fileId=request_object.file_id)
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/hal+json, application/vnd.error+json', 'If-Match': request_object.if_match, 'Authorization': 'Bearer ' + str(token)}
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, None
        if request_object.file is not None:
            local_var_files['file'] = request_object.file
        if request_object.name is not None:
            form_params['name'] = request_object.name
        if request_object.scope is not None:
            form_params['scope'] = request_object.scope
        if request_object.description is not None:
            form_params['description'] = request_object.description

        logger.info('FilesClient.replace_file()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'PUT', query_params, form_params, body_params, local_var_files, 'FileMetadataResource', self.__model_package__)

    def upload_file(self, request_object):
        """Upload files to be used in Asset Management.

        * Uploaded files are only visible for the uploader tenant. * Max file size is 5 MB. 

        :param UploadFileRequest request_object: It contains the below parameters --> |br| ( file* - The file to upload. The file size cannot be more than 5 MB. ), |br| ( name* - The name of the file ), |br| ( scope - The scope of the file ), |br| ( description - The description of the file )

        :return: FileMetadataResource
        """
        logger.info('FilesClient.upload_file() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `upload_file`')

        if request_object.file is None:
            raise exceptions.MindsphereClientError('The required parameter `file` is missing from `request_object`, when calling `upload_file`')

        if request_object.name is None:
            raise exceptions.MindsphereClientError('The required parameter `name` is missing from `request_object`, when calling `upload_file`')

        end_point_url = '/files'
        end_point_url = end_point_url.format()
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/hal+json, application/vnd.error+json', 'Authorization': 'Bearer ' + str(token)}
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, None
        if request_object.file is not None:
            local_var_files['file'] = request_object.file
        if request_object.name is not None:
            form_params['name'] = request_object.name
        if request_object.scope is not None:
            form_params['scope'] = request_object.scope
        if request_object.description is not None:
            form_params['description'] = request_object.description

        logger.info('FilesClient.upload_file()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'POST', query_params, form_params, body_params, local_var_files, 'FileMetadataResource', self.__model_package__)

