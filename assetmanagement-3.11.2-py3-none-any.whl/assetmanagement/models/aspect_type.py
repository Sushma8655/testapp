# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six

from assetmanagement.models.aspect_variable import AspectVariable
from mindsphere_core.exceptions import MindsphereClientError


class AspectType(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'name': 'str',
        'category': 'str',
        'scope': 'str',
        'description': 'str',
        'variables': 'list[AspectVariable]'
    }

    attribute_map = {
        'name': 'name',
        'category': 'category',
        'scope': 'scope',
        'description': 'description',
        'variables': 'variables'
    }

    def __init__(self, name=None, category=None, scope='private', description=None, variables=None):
        self._name = name
        self._category = category
        self._scope = scope
        self._description = description
        self._variables = variables
        self.discriminator = None

    @property
    def name(self):
        """Gets the name of this AspectType.
        Name of the aspect type. It has to be unique inside the tenant and cannot be changed later.

        :return: The name of this AspectType.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        """Sets the name of this AspectType.
        Name of the aspect type. It has to be unique inside the tenant and cannot be changed later.

        :param name: The name of this AspectType.
        :type: str
        """
        if name is None:
            raise MindsphereClientError("Invalid value for `name`, must not be `None`")
        if name is not None and len(name) > 128:
            raise MindsphereClientError("Invalid value for `name`, length must be less than or equal to `128`")
        if name is not None and len(name) < 1:
            raise MindsphereClientError("Invalid value for `name`, length must be greater than or equal to `1`")
        if name is not None and not re.search(r'[a-zA-Z0-9_]+', name):
            raise MindsphereClientError(r"Invalid value for `name`, must be a follow pattern or equal to `/[a-zA-Z0-9_]+/`")

        self._name = name

    @property
    def category(self):
        """Gets the category of this AspectType.
        If the aspect-type is used for static data or time-series. Cannot be changed once the aspect-type is created.

        :return: The category of this AspectType.
        :rtype: str
        """
        return self._category

    @category.setter
    def category(self, category):
        """Sets the category of this AspectType.
        If the aspect-type is used for static data or time-series. Cannot be changed once the aspect-type is created.

        :param category: The category of this AspectType.
        :type: str
        """
        if category is None:
            raise MindsphereClientError("Invalid value for `category`, must not be `None`")
        allowed_values = ["static", "dynamic"]
        if category.lower() not in [x.lower() for x in allowed_values]:
            raise MindsphereClientError(
                "Invalid value for `category` ({0}), must be one of {1}"
                .format(category, allowed_values)
            )

        self._category = category

    @property
    def scope(self):
        """Gets the scope of this AspectType.
        Visibility of aspecttype. Setting this property to public makes it available to other tenants. Private types are only visible to the user's own tenant. Currently only private types can be created.

        :return: The scope of this AspectType.
        :rtype: str
        """
        return self._scope

    @scope.setter
    def scope(self, scope):
        """Sets the scope of this AspectType.
        Visibility of aspecttype. Setting this property to public makes it available to other tenants. Private types are only visible to the user's own tenant. Currently only private types can be created.

        :param scope: The scope of this AspectType.
        :type: str
        """
        allowed_values = ["public", "private"]
        if scope.lower() not in [x.lower() for x in allowed_values]:
            raise MindsphereClientError(
                "Invalid value for `scope` ({0}), must be one of {1}"
                .format(scope, allowed_values)
            )

        self._scope = scope

    @property
    def description(self):
        """Gets the description of this AspectType.
        The description of the aspect type

        :return: The description of this AspectType.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        """Sets the description of this AspectType.
        The description of the aspect type

        :param description: The description of this AspectType.
        :type: str
        """
        if description is not None and len(description) > 255:
            raise MindsphereClientError("Invalid value for `description`, length must be less than or equal to `255`")
        if description is not None and not re.search(r'[^\\\']*', description):
            raise MindsphereClientError(r"Invalid value for `description`, must be a follow pattern or equal to `/[^\\']*/`")

        self._description = description

    @property
    def variables(self):
        """Gets the variables of this AspectType.
        Variables of the aspect-type. Variable names should be unique inside an aspect-type. Once a variable is added to the aspect that it cannot be renamed or removed. Only variables of static aspect-type can have default values.

        :return: The variables of this AspectType.
        :rtype: list[AspectVariable]
        """
        return self._variables

    @variables.setter
    def variables(self, variables):
        """Sets the variables of this AspectType.
        Variables of the aspect-type. Variable names should be unique inside an aspect-type. Once a variable is added to the aspect that it cannot be renamed or removed. Only variables of static aspect-type can have default values.

        :param variables: The variables of this AspectType.
        :type: list[AspectVariable]
        """
        if variables is None:
            raise MindsphereClientError("Invalid value for `variables`, must not be `None`")

        self._variables = variables

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(AspectType, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AspectType):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
