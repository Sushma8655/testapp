# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six

from assetmanagement.models.file_assignment_links_download import FileAssignmentLinksDownload
from assetmanagement.models.file_assignment_links_metadata import FileAssignmentLinksMetadata
from assetmanagement.models.file_assignment_links_origin import FileAssignmentLinksOrigin
from mindsphere_core.exceptions import MindsphereClientError


class FileAssignmentLinks(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'download': 'FileAssignmentLinksDownload',
        'metadata': 'FileAssignmentLinksMetadata',
        'origin': 'FileAssignmentLinksOrigin'
    }

    attribute_map = {
        'download': 'download',
        'metadata': 'metadata',
        'origin': 'origin'
    }

    def __init__(self, download=None, metadata=None, origin=None):
        self._download = download
        self._metadata = metadata
        self._origin = origin
        self.discriminator = None

    @property
    def download(self):
        """Gets the download of this FileAssignmentLinks.

        :return: The download of this FileAssignmentLinks.
        :rtype: FileAssignmentLinksDownload
        """
        return self._download

    @download.setter
    def download(self, download):
        """Sets the download of this FileAssignmentLinks.

        :param download: The download of this FileAssignmentLinks.
        :type: FileAssignmentLinksDownload
        """

        self._download = download

    @property
    def metadata(self):
        """Gets the metadata of this FileAssignmentLinks.

        :return: The metadata of this FileAssignmentLinks.
        :rtype: FileAssignmentLinksMetadata
        """
        return self._metadata

    @metadata.setter
    def metadata(self, metadata):
        """Sets the metadata of this FileAssignmentLinks.

        :param metadata: The metadata of this FileAssignmentLinks.
        :type: FileAssignmentLinksMetadata
        """

        self._metadata = metadata

    @property
    def origin(self):
        """Gets the origin of this FileAssignmentLinks.

        :return: The origin of this FileAssignmentLinks.
        :rtype: FileAssignmentLinksOrigin
        """
        return self._origin

    @origin.setter
    def origin(self, origin):
        """Sets the origin of this FileAssignmentLinks.

        :param origin: The origin of this FileAssignmentLinks.
        :type: FileAssignmentLinksOrigin
        """

        self._origin = origin

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(FileAssignmentLinks, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, FileAssignmentLinks):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
