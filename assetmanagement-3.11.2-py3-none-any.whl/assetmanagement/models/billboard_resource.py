# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six

from assetmanagement.models.billboard_resource_aspect_types import BillboardResourceAspectTypes
from assetmanagement.models.billboard_resource_asset_types import BillboardResourceAssetTypes
from assetmanagement.models.billboard_resource_assets import BillboardResourceAssets
from assetmanagement.models.billboard_resource_files import BillboardResourceFiles
from assetmanagement.models.billboard_resource_self import BillboardResourceSelf
from mindsphere_core.exceptions import MindsphereClientError


class BillboardResource(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        '_self': 'BillboardResourceSelf',
        'aspect_types': 'BillboardResourceAspectTypes',
        'asset_types': 'BillboardResourceAssetTypes',
        'assets': 'BillboardResourceAssets',
        'files': 'BillboardResourceFiles'
    }

    attribute_map = {
        '_self': 'self',
        'aspect_types': 'aspectTypes',
        'asset_types': 'assetTypes',
        'assets': 'assets',
        'files': 'files'
    }

    def __init__(self, _self=None, aspect_types=None, asset_types=None, assets=None, files=None):
        self.__self = _self
        self._aspect_types = aspect_types
        self._asset_types = asset_types
        self._assets = assets
        self._files = files
        self.discriminator = None

    @property
    def _self(self):
        """Gets the _self of this BillboardResource.

        :return: The _self of this BillboardResource.
        :rtype: BillboardResourceSelf
        """
        return self.__self

    @_self.setter
    def _self(self, _self):
        """Sets the _self of this BillboardResource.

        :param _self: The _self of this BillboardResource.
        :type: BillboardResourceSelf
        """

        self.__self = _self

    @property
    def aspect_types(self):
        """Gets the aspect_types of this BillboardResource.

        :return: The aspect_types of this BillboardResource.
        :rtype: BillboardResourceAspectTypes
        """
        return self._aspect_types

    @aspect_types.setter
    def aspect_types(self, aspect_types):
        """Sets the aspect_types of this BillboardResource.

        :param aspect_types: The aspect_types of this BillboardResource.
        :type: BillboardResourceAspectTypes
        """

        self._aspect_types = aspect_types

    @property
    def asset_types(self):
        """Gets the asset_types of this BillboardResource.

        :return: The asset_types of this BillboardResource.
        :rtype: BillboardResourceAssetTypes
        """
        return self._asset_types

    @asset_types.setter
    def asset_types(self, asset_types):
        """Sets the asset_types of this BillboardResource.

        :param asset_types: The asset_types of this BillboardResource.
        :type: BillboardResourceAssetTypes
        """

        self._asset_types = asset_types

    @property
    def assets(self):
        """Gets the assets of this BillboardResource.

        :return: The assets of this BillboardResource.
        :rtype: BillboardResourceAssets
        """
        return self._assets

    @assets.setter
    def assets(self, assets):
        """Sets the assets of this BillboardResource.

        :param assets: The assets of this BillboardResource.
        :type: BillboardResourceAssets
        """

        self._assets = assets

    @property
    def files(self):
        """Gets the files of this BillboardResource.

        :return: The files of this BillboardResource.
        :rtype: BillboardResourceFiles
        """
        return self._files

    @files.setter
    def files(self, files):
        """Sets the files of this BillboardResource.

        :param files: The files of this BillboardResource.
        :type: BillboardResourceFiles
        """

        self._files = files

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(BillboardResource, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, BillboardResource):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
