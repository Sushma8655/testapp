# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six

from assetmanagement.models.aspect_type_id import AspectTypeId
from mindsphere_core.exceptions import MindsphereClientError


class AssetTypeAspects(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'name': 'str',
        'aspect_type_id': 'AspectTypeId'
    }

    attribute_map = {
        'name': 'name',
        'aspect_type_id': 'aspectTypeId'
    }

    def __init__(self, name=None, aspect_type_id=None):
        self._name = name
        self._aspect_type_id = aspect_type_id
        self.discriminator = None

    @property
    def name(self):
        """Gets the name of this AssetTypeAspects.
        Name of the aspect. It has to be unique inside the type-family (ancestors and descendants).Cannot be changed. Reserved words (id, name, description, tenant, etag, scope, properties, propertySets, extends, variables, aspects, parentTypeId) cannot be used as aspect names.

        :return: The name of this AssetTypeAspects.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        """Sets the name of this AssetTypeAspects.
        Name of the aspect. It has to be unique inside the type-family (ancestors and descendants).Cannot be changed. Reserved words (id, name, description, tenant, etag, scope, properties, propertySets, extends, variables, aspects, parentTypeId) cannot be used as aspect names.

        :param name: The name of this AssetTypeAspects.
        :type: str
        """
        if name is not None and len(name) > 64:
            raise MindsphereClientError("Invalid value for `name`, length must be less than or equal to `64`")
        if name is not None and len(name) < 1:
            raise MindsphereClientError("Invalid value for `name`, length must be greater than or equal to `1`")
        if name is not None and not re.search(r'[a-zA-Z0-9_]+', name):
            raise MindsphereClientError(r"Invalid value for `name`, must be a follow pattern or equal to `/[a-zA-Z0-9_]+/`")

        self._name = name

    @property
    def aspect_type_id(self):
        """Gets the aspect_type_id of this AssetTypeAspects.

        :return: The aspect_type_id of this AssetTypeAspects.
        :rtype: AspectTypeId
        """
        return self._aspect_type_id

    @aspect_type_id.setter
    def aspect_type_id(self, aspect_type_id):
        """Sets the aspect_type_id of this AssetTypeAspects.

        :param aspect_type_id: The aspect_type_id of this AssetTypeAspects.
        :type: AspectTypeId
        """

        self._aspect_type_id = aspect_type_id

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(AssetTypeAspects, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AssetTypeAspects):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
