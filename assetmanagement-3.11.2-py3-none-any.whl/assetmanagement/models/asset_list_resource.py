# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six

from assetmanagement.models.asset_list_resource_embedded import AssetListResourceEmbedded
from assetmanagement.models.page import Page
from assetmanagement.models.paging_links import PagingLinks
from mindsphere_core.exceptions import MindsphereClientError


class AssetListResource(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'embedded': 'AssetListResourceEmbedded',
        'page': 'Page',
        'links': 'PagingLinks'
    }

    attribute_map = {
        'embedded': '_embedded',
        'page': 'page',
        'links': '_links'
    }

    def __init__(self, embedded=None, page=None, links=None):
        self._embedded = embedded
        self._page = page
        self._links = links
        self.discriminator = None

    @property
    def embedded(self):
        """Gets the embedded of this AssetListResource.

        :return: The embedded of this AssetListResource.
        :rtype: AssetListResourceEmbedded
        """
        return self._embedded

    @embedded.setter
    def embedded(self, embedded):
        """Sets the embedded of this AssetListResource.

        :param embedded: The embedded of this AssetListResource.
        :type: AssetListResourceEmbedded
        """

        self._embedded = embedded

    @property
    def page(self):
        """Gets the page of this AssetListResource.

        :return: The page of this AssetListResource.
        :rtype: Page
        """
        return self._page

    @page.setter
    def page(self, page):
        """Sets the page of this AssetListResource.

        :param page: The page of this AssetListResource.
        :type: Page
        """

        self._page = page

    @property
    def links(self):
        """Gets the links of this AssetListResource.

        :return: The links of this AssetListResource.
        :rtype: PagingLinks
        """
        return self._links

    @links.setter
    def links(self, links):
        """Sets the links of this AssetListResource.

        :param links: The links of this AssetListResource.
        :type: PagingLinks
        """

        self._links = links

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(AssetListResource, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AssetListResource):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
