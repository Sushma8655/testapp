# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six

from assetmanagement.models.aspect import Aspect
from assetmanagement.models.asset_links import AssetLinks
from assetmanagement.models.asset_resource import AssetResource
from assetmanagement.models.asset_resource_with_hierarchy_path_hierarchy_path import AssetResourceWithHierarchyPathHierarchyPath
from assetmanagement.models.asset_type_id import AssetTypeId
from assetmanagement.models.e_tag import ETag
from assetmanagement.models.file_assignment_resource import FileAssignmentResource
from assetmanagement.models.location import Location
from assetmanagement.models.lock_resource import LockResource
from assetmanagement.models.tenant_id import TenantId
from assetmanagement.models.timezone import Timezone
from assetmanagement.models.unique_id import UniqueId
from assetmanagement.models.variable import Variable
from mindsphere_core.exceptions import MindsphereClientError


class AssetResourceWithHierarchyPath(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'name': 'str',
        'external_id': 'str',
        'description': 'str',
        'location': 'Location',
        'variables': 'list[Variable]',
        'aspects': 'list[Aspect]',
        'file_assignments': 'list[FileAssignmentResource]',
        'type_id': 'AssetTypeId',
        'parent_id': 'UniqueId',
        'timezone': 'Timezone',
        'twin_type': 'str',
        'tenant_id': 'TenantId',
        'sub_tenant': 'str',
        't2_tenant': 'str',
        'asset_id': 'UniqueId',
        'locks': 'list[LockResource]',
        'deleted': 'datetime',
        'etag': 'ETag',
        'links': 'AssetLinks',
        'hierarchy_path': 'list[AssetResourceWithHierarchyPathHierarchyPath]'
    }

    attribute_map = {
        'name': 'name',
        'external_id': 'externalId',
        'description': 'description',
        'location': 'location',
        'variables': 'variables',
        'aspects': 'aspects',
        'file_assignments': 'fileAssignments',
        'type_id': 'typeId',
        'parent_id': 'parentId',
        'timezone': 'timezone',
        'twin_type': 'twinType',
        'tenant_id': 'tenantId',
        'sub_tenant': 'subTenant',
        't2_tenant': 't2Tenant',
        'asset_id': 'assetId',
        'locks': 'locks',
        'deleted': 'deleted',
        'etag': 'etag',
        'links': '_links',
        'hierarchy_path': 'hierarchyPath'
    }

    def __init__(self, name=None, external_id=None, description=None, location=None, variables=None, aspects=None, file_assignments=None, type_id=None, parent_id=None, timezone=None, twin_type='performance', tenant_id=None, sub_tenant=None, t2_tenant=None, asset_id=None, locks=None, deleted=None, etag=None, links=None, hierarchy_path=None):
        self._name = name
        self._external_id = external_id
        self._description = description
        self._location = location
        self._variables = variables
        self._aspects = aspects
        self._file_assignments = file_assignments
        self._type_id = type_id
        self._parent_id = parent_id
        self._timezone = timezone
        self._twin_type = twin_type
        self._tenant_id = tenant_id
        self._sub_tenant = sub_tenant
        self._t2_tenant = t2_tenant
        self._asset_id = asset_id
        self._locks = locks
        self._deleted = deleted
        self._etag = etag
        self._links = links
        self._hierarchy_path = hierarchy_path
        self.discriminator = None

    @property
    def name(self):
        """Gets the name of this AssetResourceWithHierarchyPath.
        Name of the asset

        :return: The name of this AssetResourceWithHierarchyPath.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        """Sets the name of this AssetResourceWithHierarchyPath.
        Name of the asset

        :param name: The name of this AssetResourceWithHierarchyPath.
        :type: str
        """
        if name is None:
            raise MindsphereClientError("Invalid value for `name`, must not be `None`")
        if name is not None and len(name) > 128:
            raise MindsphereClientError("Invalid value for `name`, length must be less than or equal to `128`")
        if name is not None and len(name) < 1:
            raise MindsphereClientError("Invalid value for `name`, length must be greater than or equal to `1`")
        if name is not None and not re.search(r'[^\/\\\\]*', name):
            raise MindsphereClientError(r"Invalid value for `name`, must be a follow pattern or equal to `/[^\/\\\\]*/`")

        self._name = name

    @property
    def external_id(self):
        """Gets the external_id of this AssetResourceWithHierarchyPath.
        The id given by the user

        :return: The external_id of this AssetResourceWithHierarchyPath.
        :rtype: str
        """
        return self._external_id

    @external_id.setter
    def external_id(self, external_id):
        """Sets the external_id of this AssetResourceWithHierarchyPath.
        The id given by the user

        :param external_id: The external_id of this AssetResourceWithHierarchyPath.
        :type: str
        """
        if external_id is not None and len(external_id) > 255:
            raise MindsphereClientError("Invalid value for `external_id`, length must be less than or equal to `255`")

        self._external_id = external_id

    @property
    def description(self):
        """Gets the description of this AssetResourceWithHierarchyPath.
        The description of the asset

        :return: The description of this AssetResourceWithHierarchyPath.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        """Sets the description of this AssetResourceWithHierarchyPath.
        The description of the asset

        :param description: The description of this AssetResourceWithHierarchyPath.
        :type: str
        """
        if description is not None and len(description) > 255:
            raise MindsphereClientError("Invalid value for `description`, length must be less than or equal to `255`")

        self._description = description

    @property
    def location(self):
        """Gets the location of this AssetResourceWithHierarchyPath.

        :return: The location of this AssetResourceWithHierarchyPath.
        :rtype: Location
        """
        return self._location

    @location.setter
    def location(self, location):
        """Sets the location of this AssetResourceWithHierarchyPath.

        :param location: The location of this AssetResourceWithHierarchyPath.
        :type: Location
        """

        self._location = location

    @property
    def variables(self):
        """Gets the variables of this AssetResourceWithHierarchyPath.

        :return: The variables of this AssetResourceWithHierarchyPath.
        :rtype: list[Variable]
        """
        return self._variables

    @variables.setter
    def variables(self, variables):
        """Sets the variables of this AssetResourceWithHierarchyPath.

        :param variables: The variables of this AssetResourceWithHierarchyPath.
        :type: list[Variable]
        """

        self._variables = variables

    @property
    def aspects(self):
        """Gets the aspects of this AssetResourceWithHierarchyPath.

        :return: The aspects of this AssetResourceWithHierarchyPath.
        :rtype: list[Aspect]
        """
        return self._aspects

    @aspects.setter
    def aspects(self, aspects):
        """Sets the aspects of this AssetResourceWithHierarchyPath.

        :param aspects: The aspects of this AssetResourceWithHierarchyPath.
        :type: list[Aspect]
        """

        self._aspects = aspects

    @property
    def file_assignments(self):
        """Gets the file_assignments of this AssetResourceWithHierarchyPath.

        :return: The file_assignments of this AssetResourceWithHierarchyPath.
        :rtype: list[FileAssignmentResource]
        """
        return self._file_assignments

    @file_assignments.setter
    def file_assignments(self, file_assignments):
        """Sets the file_assignments of this AssetResourceWithHierarchyPath.

        :param file_assignments: The file_assignments of this AssetResourceWithHierarchyPath.
        :type: list[FileAssignmentResource]
        """

        self._file_assignments = file_assignments

    @property
    def type_id(self):
        """Gets the type_id of this AssetResourceWithHierarchyPath.

        :return: The type_id of this AssetResourceWithHierarchyPath.
        :rtype: AssetTypeId
        """
        return self._type_id

    @type_id.setter
    def type_id(self, type_id):
        """Sets the type_id of this AssetResourceWithHierarchyPath.

        :param type_id: The type_id of this AssetResourceWithHierarchyPath.
        :type: AssetTypeId
        """

        self._type_id = type_id

    @property
    def parent_id(self):
        """Gets the parent_id of this AssetResourceWithHierarchyPath.

        :return: The parent_id of this AssetResourceWithHierarchyPath.
        :rtype: UniqueId
        """
        return self._parent_id

    @parent_id.setter
    def parent_id(self, parent_id):
        """Sets the parent_id of this AssetResourceWithHierarchyPath.

        :param parent_id: The parent_id of this AssetResourceWithHierarchyPath.
        :type: UniqueId
        """

        self._parent_id = parent_id

    @property
    def timezone(self):
        """Gets the timezone of this AssetResourceWithHierarchyPath.

        :return: The timezone of this AssetResourceWithHierarchyPath.
        :rtype: Timezone
        """
        return self._timezone

    @timezone.setter
    def timezone(self, timezone):
        """Sets the timezone of this AssetResourceWithHierarchyPath.

        :param timezone: The timezone of this AssetResourceWithHierarchyPath.
        :type: Timezone
        """

        self._timezone = timezone

    @property
    def twin_type(self):
        """Gets the twin_type of this AssetResourceWithHierarchyPath.

        :return: The twin_type of this AssetResourceWithHierarchyPath.
        :rtype: str
        """
        return self._twin_type

    @twin_type.setter
    def twin_type(self, twin_type):
        """Sets the twin_type of this AssetResourceWithHierarchyPath.

        :param twin_type: The twin_type of this AssetResourceWithHierarchyPath.
        :type: str
        """
        allowed_values = ["performance", "simulation"]
        if twin_type.lower() not in [x.lower() for x in allowed_values]:
            raise MindsphereClientError(
                "Invalid value for `twin_type` ({0}), must be one of {1}"
                .format(twin_type, allowed_values)
            )

        self._twin_type = twin_type

    @property
    def tenant_id(self):
        """Gets the tenant_id of this AssetResourceWithHierarchyPath.

        :return: The tenant_id of this AssetResourceWithHierarchyPath.
        :rtype: TenantId
        """
        return self._tenant_id

    @tenant_id.setter
    def tenant_id(self, tenant_id):
        """Sets the tenant_id of this AssetResourceWithHierarchyPath.

        :param tenant_id: The tenant_id of this AssetResourceWithHierarchyPath.
        :type: TenantId
        """

        self._tenant_id = tenant_id

    @property
    def sub_tenant(self):
        """Gets the sub_tenant of this AssetResourceWithHierarchyPath.
        The id of the end-customer.

        :return: The sub_tenant of this AssetResourceWithHierarchyPath.
        :rtype: str
        """
        return self._sub_tenant

    @sub_tenant.setter
    def sub_tenant(self, sub_tenant):
        """Sets the sub_tenant of this AssetResourceWithHierarchyPath.
        The id of the end-customer.

        :param sub_tenant: The sub_tenant of this AssetResourceWithHierarchyPath.
        :type: str
        """
        if sub_tenant is not None and len(sub_tenant) > 255:
            raise MindsphereClientError("Invalid value for `sub_tenant`, length must be less than or equal to `255`")

        self._sub_tenant = sub_tenant

    @property
    def t2_tenant(self):
        """Gets the t2_tenant of this AssetResourceWithHierarchyPath.
        The id of the end-customer. This field is DEPRECATED please use subTenant instead.

        :return: The t2_tenant of this AssetResourceWithHierarchyPath.
        :rtype: str
        """
        return self._t2_tenant

    @t2_tenant.setter
    def t2_tenant(self, t2_tenant):
        """Sets the t2_tenant of this AssetResourceWithHierarchyPath.
        The id of the end-customer. This field is DEPRECATED please use subTenant instead.

        :param t2_tenant: The t2_tenant of this AssetResourceWithHierarchyPath.
        :type: str
        """
        if t2_tenant is not None and len(t2_tenant) > 255:
            raise MindsphereClientError("Invalid value for `t2_tenant`, length must be less than or equal to `255`")

        self._t2_tenant = t2_tenant

    @property
    def asset_id(self):
        """Gets the asset_id of this AssetResourceWithHierarchyPath.

        :return: The asset_id of this AssetResourceWithHierarchyPath.
        :rtype: UniqueId
        """
        return self._asset_id

    @asset_id.setter
    def asset_id(self, asset_id):
        """Sets the asset_id of this AssetResourceWithHierarchyPath.

        :param asset_id: The asset_id of this AssetResourceWithHierarchyPath.
        :type: UniqueId
        """

        self._asset_id = asset_id

    @property
    def locks(self):
        """Gets the locks of this AssetResourceWithHierarchyPath.

        :return: The locks of this AssetResourceWithHierarchyPath.
        :rtype: list[LockResource]
        """
        return self._locks

    @locks.setter
    def locks(self, locks):
        """Sets the locks of this AssetResourceWithHierarchyPath.

        :param locks: The locks of this AssetResourceWithHierarchyPath.
        :type: list[LockResource]
        """

        self._locks = locks

    @property
    def deleted(self):
        """Gets the deleted of this AssetResourceWithHierarchyPath.

        :return: The deleted of this AssetResourceWithHierarchyPath.
        :rtype: datetime
        """
        return self._deleted

    @deleted.setter
    def deleted(self, deleted):
        """Sets the deleted of this AssetResourceWithHierarchyPath.

        :param deleted: The deleted of this AssetResourceWithHierarchyPath.
        :type: datetime
        """

        self._deleted = deleted

    @property
    def etag(self):
        """Gets the etag of this AssetResourceWithHierarchyPath.

        :return: The etag of this AssetResourceWithHierarchyPath.
        :rtype: ETag
        """
        return self._etag

    @etag.setter
    def etag(self, etag):
        """Sets the etag of this AssetResourceWithHierarchyPath.

        :param etag: The etag of this AssetResourceWithHierarchyPath.
        :type: ETag
        """

        self._etag = etag

    @property
    def links(self):
        """Gets the links of this AssetResourceWithHierarchyPath.

        :return: The links of this AssetResourceWithHierarchyPath.
        :rtype: AssetLinks
        """
        return self._links

    @links.setter
    def links(self, links):
        """Sets the links of this AssetResourceWithHierarchyPath.

        :param links: The links of this AssetResourceWithHierarchyPath.
        :type: AssetLinks
        """

        self._links = links

    @property
    def hierarchy_path(self):
        """Gets the hierarchy_path of this AssetResourceWithHierarchyPath.

        :return: The hierarchy_path of this AssetResourceWithHierarchyPath.
        :rtype: list[AssetResourceWithHierarchyPathHierarchyPath]
        """
        return self._hierarchy_path

    @hierarchy_path.setter
    def hierarchy_path(self, hierarchy_path):
        """Sets the hierarchy_path of this AssetResourceWithHierarchyPath.

        :param hierarchy_path: The hierarchy_path of this AssetResourceWithHierarchyPath.
        :type: list[AssetResourceWithHierarchyPathHierarchyPath]
        """

        self._hierarchy_path = hierarchy_path

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(AssetResourceWithHierarchyPath, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AssetResourceWithHierarchyPath):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
