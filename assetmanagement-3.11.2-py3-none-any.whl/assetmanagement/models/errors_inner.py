# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class ErrorsInner(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'errorcode': 'float',
        'logref': 'str',
        'message': 'str'
    }

    attribute_map = {
        'errorcode': 'errorcode',
        'logref': 'logref',
        'message': 'message'
    }

    def __init__(self, errorcode=None, logref=None, message=None):
        self._errorcode = errorcode
        self._logref = logref
        self._message = message
        self.discriminator = None

    @property
    def errorcode(self):
        """Gets the errorcode of this ErrorsInner.

        :return: The errorcode of this ErrorsInner.
        :rtype: float
        """
        return self._errorcode

    @errorcode.setter
    def errorcode(self, errorcode):
        """Sets the errorcode of this ErrorsInner.

        :param errorcode: The errorcode of this ErrorsInner.
        :type: float
        """

        self._errorcode = errorcode

    @property
    def logref(self):
        """Gets the logref of this ErrorsInner.

        :return: The logref of this ErrorsInner.
        :rtype: str
        """
        return self._logref

    @logref.setter
    def logref(self, logref):
        """Sets the logref of this ErrorsInner.

        :param logref: The logref of this ErrorsInner.
        :type: str
        """

        self._logref = logref

    @property
    def message(self):
        """Gets the message of this ErrorsInner.

        :return: The message of this ErrorsInner.
        :rtype: str
        """
        return self._message

    @message.setter
    def message(self, message):
        """Sets the message of this ErrorsInner.

        :param message: The message of this ErrorsInner.
        :type: str
        """

        self._message = message

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(ErrorsInner, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ErrorsInner):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
