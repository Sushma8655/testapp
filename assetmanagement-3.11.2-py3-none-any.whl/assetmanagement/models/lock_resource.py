# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six

from assetmanagement.models.lock_resource_links import LockResourceLinks
from assetmanagement.models.unique_id import UniqueId
from mindsphere_core.exceptions import MindsphereClientError


class LockResource(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'id': 'UniqueId',
        'service': 'str',
        'reason': 'str',
        'reason_code': 'str',
        'links': 'LockResourceLinks'
    }

    attribute_map = {
        'id': 'id',
        'service': 'service',
        'reason': 'reason',
        'reason_code': 'reasonCode',
        'links': '_links'
    }

    def __init__(self, id=None, service=None, reason=None, reason_code=None, links=None):
        self._id = id
        self._service = service
        self._reason = reason
        self._reason_code = reason_code
        self._links = links
        self.discriminator = None

    @property
    def id(self):
        """Gets the id of this LockResource.

        :return: The id of this LockResource.
        :rtype: UniqueId
        """
        return self._id

    @id.setter
    def id(self, id):
        """Sets the id of this LockResource.

        :param id: The id of this LockResource.
        :type: UniqueId
        """

        self._id = id

    @property
    def service(self):
        """Gets the service of this LockResource.
        Service creating the lock

        :return: The service of this LockResource.
        :rtype: str
        """
        return self._service

    @service.setter
    def service(self, service):
        """Sets the service of this LockResource.
        Service creating the lock

        :param service: The service of this LockResource.
        :type: str
        """

        self._service = service

    @property
    def reason(self):
        """Gets the reason of this LockResource.
        Reason of lock

        :return: The reason of this LockResource.
        :rtype: str
        """
        return self._reason

    @reason.setter
    def reason(self, reason):
        """Sets the reason of this LockResource.
        Reason of lock

        :param reason: The reason of this LockResource.
        :type: str
        """

        self._reason = reason

    @property
    def reason_code(self):
        """Gets the reason_code of this LockResource.
        Code of the reason

        :return: The reason_code of this LockResource.
        :rtype: str
        """
        return self._reason_code

    @reason_code.setter
    def reason_code(self, reason_code):
        """Sets the reason_code of this LockResource.
        Code of the reason

        :param reason_code: The reason_code of this LockResource.
        :type: str
        """

        self._reason_code = reason_code

    @property
    def links(self):
        """Gets the links of this LockResource.

        :return: The links of this LockResource.
        :rtype: LockResourceLinks
        """
        return self._links

    @links.setter
    def links(self, links):
        """Sets the links of this LockResource.

        :param links: The links of this LockResource.
        :type: LockResourceLinks
        """

        self._links = links

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(LockResource, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, LockResource):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
