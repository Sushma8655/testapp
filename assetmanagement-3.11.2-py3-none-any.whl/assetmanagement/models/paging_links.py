# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six

from assetmanagement.models.link_for_downloading_the_file import LinkForDownloadingTheFile
from assetmanagement.models.rel_self import RelSelf
from mindsphere_core.exceptions import MindsphereClientError


class PagingLinks(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        '_self': 'RelSelf',
        'first': 'LinkForDownloadingTheFile',
        'prev': 'LinkForDownloadingTheFile',
        'next': 'LinkForDownloadingTheFile',
        'last': 'LinkForDownloadingTheFile'
    }

    attribute_map = {
        '_self': 'self',
        'first': 'first',
        'prev': 'prev',
        'next': 'next',
        'last': 'last'
    }

    def __init__(self, _self=None, first=None, prev=None, next=None, last=None):
        self.__self = _self
        self._first = first
        self._prev = prev
        self._next = next
        self._last = last
        self.discriminator = None

    @property
    def _self(self):
        """Gets the _self of this PagingLinks.

        :return: The _self of this PagingLinks.
        :rtype: RelSelf
        """
        return self.__self

    @_self.setter
    def _self(self, _self):
        """Sets the _self of this PagingLinks.

        :param _self: The _self of this PagingLinks.
        :type: RelSelf
        """

        self.__self = _self

    @property
    def first(self):
        """Gets the first of this PagingLinks.

        :return: The first of this PagingLinks.
        :rtype: LinkForDownloadingTheFile
        """
        return self._first

    @first.setter
    def first(self, first):
        """Sets the first of this PagingLinks.

        :param first: The first of this PagingLinks.
        :type: LinkForDownloadingTheFile
        """

        self._first = first

    @property
    def prev(self):
        """Gets the prev of this PagingLinks.

        :return: The prev of this PagingLinks.
        :rtype: LinkForDownloadingTheFile
        """
        return self._prev

    @prev.setter
    def prev(self, prev):
        """Sets the prev of this PagingLinks.

        :param prev: The prev of this PagingLinks.
        :type: LinkForDownloadingTheFile
        """

        self._prev = prev

    @property
    def next(self):
        """Gets the next of this PagingLinks.

        :return: The next of this PagingLinks.
        :rtype: LinkForDownloadingTheFile
        """
        return self._next

    @next.setter
    def next(self, next):
        """Sets the next of this PagingLinks.

        :param next: The next of this PagingLinks.
        :type: LinkForDownloadingTheFile
        """

        self._next = next

    @property
    def last(self):
        """Gets the last of this PagingLinks.

        :return: The last of this PagingLinks.
        :rtype: LinkForDownloadingTheFile
        """
        return self._last

    @last.setter
    def last(self, last):
        """Sets the last of this PagingLinks.

        :param last: The last of this PagingLinks.
        :type: LinkForDownloadingTheFile
        """

        self._last = last

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(PagingLinks, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, PagingLinks):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
