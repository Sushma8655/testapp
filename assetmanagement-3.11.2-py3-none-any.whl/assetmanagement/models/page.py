# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class Page(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'size': 'int',
        'total_elements': 'int',
        'total_pages': 'int',
        'number': 'int'
    }

    attribute_map = {
        'size': 'size',
        'total_elements': 'totalElements',
        'total_pages': 'totalPages',
        'number': 'number'
    }

    def __init__(self, size=None, total_elements=None, total_pages=None, number=None):
        self._size = size
        self._total_elements = total_elements
        self._total_pages = total_pages
        self._number = number
        self.discriminator = None

    @property
    def size(self):
        """Gets the size of this Page.

        :return: The size of this Page.
        :rtype: int
        """
        return self._size

    @size.setter
    def size(self, size):
        """Sets the size of this Page.

        :param size: The size of this Page.
        :type: int
        """

        self._size = size

    @property
    def total_elements(self):
        """Gets the total_elements of this Page.

        :return: The total_elements of this Page.
        :rtype: int
        """
        return self._total_elements

    @total_elements.setter
    def total_elements(self, total_elements):
        """Sets the total_elements of this Page.

        :param total_elements: The total_elements of this Page.
        :type: int
        """

        self._total_elements = total_elements

    @property
    def total_pages(self):
        """Gets the total_pages of this Page.

        :return: The total_pages of this Page.
        :rtype: int
        """
        return self._total_pages

    @total_pages.setter
    def total_pages(self, total_pages):
        """Sets the total_pages of this Page.

        :param total_pages: The total_pages of this Page.
        :type: int
        """

        self._total_pages = total_pages

    @property
    def number(self):
        """Gets the number of this Page.

        :return: The number of this Page.
        :rtype: int
        """
        return self._number

    @number.setter
    def number(self, number):
        """Sets the number of this Page.

        :param number: The number of this Page.
        :type: int
        """

        self._number = number

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(Page, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, Page):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
