# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class GetAssetTypeRequest(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'if_none_match': 'str',
        'exploded': 'bool',
        'id': 'str'
    }

    attribute_map = {
        'if_none_match': 'If-None-Match',
        'exploded': 'exploded',
        'id': 'id'
    }

    def __init__(self, if_none_match=None, exploded=None, id=None):
        self._if_none_match = if_none_match
        self._exploded = exploded
        self._id = id
        self.discriminator = None

    @property
    def if_none_match(self):
        """Gets the if_none_match of this GetAssetTypeRequest.

        :return: The if_none_match of this GetAssetTypeRequest.
        :rtype: str
        """
        return self._if_none_match

    @if_none_match.setter
    def if_none_match(self, if_none_match):
        """Sets the if_none_match of this GetAssetTypeRequest.

        :param if_none_match: The if_none_match of this GetAssetTypeRequest.
        :type: str
        """

        self._if_none_match = if_none_match

    @property
    def exploded(self):
        """Gets the exploded of this GetAssetTypeRequest.

        :return: The exploded of this GetAssetTypeRequest.
        :rtype: bool
        """
        return self._exploded

    @exploded.setter
    def exploded(self, exploded):
        """Sets the exploded of this GetAssetTypeRequest.

        :param exploded: The exploded of this GetAssetTypeRequest.
        :type: bool
        """

        self._exploded = exploded

    @property
    def id(self):
        """Gets the id of this GetAssetTypeRequest.

        :return: The id of this GetAssetTypeRequest.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        """Sets the id of this GetAssetTypeRequest.

        :param id: The id of this GetAssetTypeRequest.
        :type: str
        """

        self._id = id

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(GetAssetTypeRequest, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, GetAssetTypeRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
