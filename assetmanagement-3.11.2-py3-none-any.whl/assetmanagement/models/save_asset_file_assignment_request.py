# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six

from assetmanagement.models.keyed_file_assignment import KeyedFileAssignment
from mindsphere_core.exceptions import MindsphereClientError


class SaveAssetFileAssignmentRequest(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'if_match': 'str',
        'assignment': 'KeyedFileAssignment',
        'id': 'str',
        'key': 'str'
    }

    attribute_map = {
        'if_match': 'If-Match',
        'assignment': 'assignment',
        'id': 'id',
        'key': 'key'
    }

    def __init__(self, if_match=None, assignment=None, id=None, key=None):
        self._if_match = if_match
        self._assignment = assignment
        self._id = id
        self._key = key
        self.discriminator = None

    @property
    def if_match(self):
        """Gets the if_match of this SaveAssetFileAssignmentRequest.

        :return: The if_match of this SaveAssetFileAssignmentRequest.
        :rtype: str
        """
        return self._if_match

    @if_match.setter
    def if_match(self, if_match):
        """Sets the if_match of this SaveAssetFileAssignmentRequest.

        :param if_match: The if_match of this SaveAssetFileAssignmentRequest.
        :type: str
        """

        self._if_match = if_match

    @property
    def assignment(self):
        """Gets the assignment of this SaveAssetFileAssignmentRequest.

        :return: The assignment of this SaveAssetFileAssignmentRequest.
        :rtype: KeyedFileAssignment
        """
        return self._assignment

    @assignment.setter
    def assignment(self, assignment):
        """Sets the assignment of this SaveAssetFileAssignmentRequest.

        :param assignment: The assignment of this SaveAssetFileAssignmentRequest.
        :type: KeyedFileAssignment
        """

        self._assignment = assignment

    @property
    def id(self):
        """Gets the id of this SaveAssetFileAssignmentRequest.

        :return: The id of this SaveAssetFileAssignmentRequest.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        """Sets the id of this SaveAssetFileAssignmentRequest.

        :param id: The id of this SaveAssetFileAssignmentRequest.
        :type: str
        """

        self._id = id

    @property
    def key(self):
        """Gets the key of this SaveAssetFileAssignmentRequest.

        :return: The key of this SaveAssetFileAssignmentRequest.
        :rtype: str
        """
        return self._key

    @key.setter
    def key(self, key):
        """Sets the key of this SaveAssetFileAssignmentRequest.

        :param key: The key of this SaveAssetFileAssignmentRequest.
        :type: str
        """

        self._key = key

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(SaveAssetFileAssignmentRequest, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, SaveAssetFileAssignmentRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
