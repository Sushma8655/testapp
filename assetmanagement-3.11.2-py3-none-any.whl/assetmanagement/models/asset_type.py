# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six

from assetmanagement.models.asset_type_aspects import AssetTypeAspects
from assetmanagement.models.asset_type_base import AssetTypeBase
from assetmanagement.models.asset_type_id import AssetTypeId
from assetmanagement.models.file_assignment import FileAssignment
from assetmanagement.models.variable_definition import VariableDefinition
from mindsphere_core.exceptions import MindsphereClientError


class AssetType(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'name': 'str',
        'description': 'str',
        'parent_type_id': 'AssetTypeId',
        'instantiable': 'bool',
        'scope': 'str',
        'aspects': 'list[AssetTypeAspects]',
        'variables': 'list[VariableDefinition]',
        'file_assignments': 'list[FileAssignment]'
    }

    attribute_map = {
        'name': 'name',
        'description': 'description',
        'parent_type_id': 'parentTypeId',
        'instantiable': 'instantiable',
        'scope': 'scope',
        'aspects': 'aspects',
        'variables': 'variables',
        'file_assignments': 'fileAssignments'
    }

    def __init__(self, name=None, description=None, parent_type_id=None, instantiable=True, scope='private', aspects=None, variables=None, file_assignments=None):
        self._name = name
        self._description = description
        self._parent_type_id = parent_type_id
        self._instantiable = instantiable
        self._scope = scope
        self._aspects = aspects
        self._variables = variables
        self._file_assignments = file_assignments
        self.discriminator = None

    @property
    def name(self):
        """Gets the name of this AssetType.
        The type's name.

        :return: The name of this AssetType.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        """Sets the name of this AssetType.
        The type's name.

        :param name: The name of this AssetType.
        :type: str
        """
        if name is None:
            raise MindsphereClientError("Invalid value for `name`, must not be `None`")
        if name is not None and len(name) > 128:
            raise MindsphereClientError("Invalid value for `name`, length must be less than or equal to `128`")
        if name is not None and len(name) < 1:
            raise MindsphereClientError("Invalid value for `name`, length must be greater than or equal to `1`")
        if name is not None and not re.search(r'[\\p{L}_0-9_\\. -]+', name):
            raise MindsphereClientError(r"Invalid value for `name`, must be a follow pattern or equal to `/[\\p{L}_0-9_\\. -]+/`")

        self._name = name

    @property
    def description(self):
        """Gets the description of this AssetType.
        description

        :return: The description of this AssetType.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        """Sets the description of this AssetType.
        description

        :param description: The description of this AssetType.
        :type: str
        """
        if description is not None and len(description) > 255:
            raise MindsphereClientError("Invalid value for `description`, length must be less than or equal to `255`")

        self._description = description

    @property
    def parent_type_id(self):
        """Gets the parent_type_id of this AssetType.

        :return: The parent_type_id of this AssetType.
        :rtype: AssetTypeId
        """
        return self._parent_type_id

    @parent_type_id.setter
    def parent_type_id(self, parent_type_id):
        """Sets the parent_type_id of this AssetType.

        :param parent_type_id: The parent_type_id of this AssetType.
        :type: AssetTypeId
        """

        self._parent_type_id = parent_type_id

    @property
    def instantiable(self):
        """Gets the instantiable of this AssetType.
        If instances can be created from this type. A non-instantiable type could be changed to be instantiable but not the other way around.

        :return: The instantiable of this AssetType.
        :rtype: bool
        """
        return self._instantiable

    @instantiable.setter
    def instantiable(self, instantiable):
        """Sets the instantiable of this AssetType.
        If instances can be created from this type. A non-instantiable type could be changed to be instantiable but not the other way around.

        :param instantiable: The instantiable of this AssetType.
        :type: bool
        """

        self._instantiable = instantiable

    @property
    def scope(self):
        """Gets the scope of this AssetType.
        Visibility of the assettype. Setting this property to public makes it available to other tenants. Private types are only visible to the user's own tenant. Currently only private types could be created.

        :return: The scope of this AssetType.
        :rtype: str
        """
        return self._scope

    @scope.setter
    def scope(self, scope):
        """Sets the scope of this AssetType.
        Visibility of the assettype. Setting this property to public makes it available to other tenants. Private types are only visible to the user's own tenant. Currently only private types could be created.

        :param scope: The scope of this AssetType.
        :type: str
        """
        allowed_values = ["public", "private"]
        if scope.lower() not in [x.lower() for x in allowed_values]:
            raise MindsphereClientError(
                "Invalid value for `scope` ({0}), must be one of {1}"
                .format(scope, allowed_values)
            )

        self._scope = scope

    @property
    def aspects(self):
        """Gets the aspects of this AssetType.
        Aspects of the asset-type. Once added aspects cannot be removed.

        :return: The aspects of this AssetType.
        :rtype: list[AssetTypeAspects]
        """
        return self._aspects

    @aspects.setter
    def aspects(self, aspects):
        """Sets the aspects of this AssetType.
        Aspects of the asset-type. Once added aspects cannot be removed.

        :param aspects: The aspects of this AssetType.
        :type: list[AssetTypeAspects]
        """

        self._aspects = aspects

    @property
    def variables(self):
        """Gets the variables of this AssetType.
        Direct variables of the asset-type. Variable names has to be unique inside the whole type-family (ancestors and descendants). Once added variables cannot be changed or removed.

        :return: The variables of this AssetType.
        :rtype: list[VariableDefinition]
        """
        return self._variables

    @variables.setter
    def variables(self, variables):
        """Sets the variables of this AssetType.
        Direct variables of the asset-type. Variable names has to be unique inside the whole type-family (ancestors and descendants). Once added variables cannot be changed or removed.

        :param variables: The variables of this AssetType.
        :type: list[VariableDefinition]
        """

        self._variables = variables

    @property
    def file_assignments(self):
        """Gets the file_assignments of this AssetType.

        :return: The file_assignments of this AssetType.
        :rtype: list[FileAssignment]
        """
        return self._file_assignments

    @file_assignments.setter
    def file_assignments(self, file_assignments):
        """Sets the file_assignments of this AssetType.

        :param file_assignments: The file_assignments of this AssetType.
        :type: list[FileAssignment]
        """

        self._file_assignments = file_assignments

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(AssetType, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AssetType):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
