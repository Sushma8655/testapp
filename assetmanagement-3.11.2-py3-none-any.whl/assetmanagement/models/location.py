# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class Location(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'country': 'str',
        'region': 'str',
        'locality': 'str',
        'street_address': 'str',
        'postal_code': 'str',
        'longitude': 'float',
        'latitude': 'float'
    }

    attribute_map = {
        'country': 'country',
        'region': 'region',
        'locality': 'locality',
        'street_address': 'streetAddress',
        'postal_code': 'postalCode',
        'longitude': 'longitude',
        'latitude': 'latitude'
    }

    def __init__(self, country=None, region=None, locality=None, street_address=None, postal_code=None, longitude=None, latitude=None):
        self._country = country
        self._region = region
        self._locality = locality
        self._street_address = street_address
        self._postal_code = postal_code
        self._longitude = longitude
        self._latitude = latitude
        self.discriminator = None

    @property
    def country(self):
        """Gets the country of this Location.

        :return: The country of this Location.
        :rtype: str
        """
        return self._country

    @country.setter
    def country(self, country):
        """Sets the country of this Location.

        :param country: The country of this Location.
        :type: str
        """
        if country is not None and len(country) > 255:
            raise MindsphereClientError("Invalid value for `country`, length must be less than or equal to `255`")

        self._country = country

    @property
    def region(self):
        """Gets the region of this Location.
        County or other region code or name

        :return: The region of this Location.
        :rtype: str
        """
        return self._region

    @region.setter
    def region(self, region):
        """Sets the region of this Location.
        County or other region code or name

        :param region: The region of this Location.
        :type: str
        """
        if region is not None and len(region) > 255:
            raise MindsphereClientError("Invalid value for `region`, length must be less than or equal to `255`")

        self._region = region

    @property
    def locality(self):
        """Gets the locality of this Location.

        :return: The locality of this Location.
        :rtype: str
        """
        return self._locality

    @locality.setter
    def locality(self, locality):
        """Sets the locality of this Location.

        :param locality: The locality of this Location.
        :type: str
        """
        if locality is not None and len(locality) > 255:
            raise MindsphereClientError("Invalid value for `locality`, length must be less than or equal to `255`")
        if locality is not None and not re.search(r'[\\p{L}0-9_ -\\\']*', locality):
            raise MindsphereClientError(r"Invalid value for `locality`, must be a follow pattern or equal to `/[\\p{L}0-9_ -\\']*/`")

        self._locality = locality

    @property
    def street_address(self):
        """Gets the street_address of this Location.

        :return: The street_address of this Location.
        :rtype: str
        """
        return self._street_address

    @street_address.setter
    def street_address(self, street_address):
        """Sets the street_address of this Location.

        :param street_address: The street_address of this Location.
        :type: str
        """
        if street_address is not None and len(street_address) > 255:
            raise MindsphereClientError("Invalid value for `street_address`, length must be less than or equal to `255`")

        self._street_address = street_address

    @property
    def postal_code(self):
        """Gets the postal_code of this Location.

        :return: The postal_code of this Location.
        :rtype: str
        """
        return self._postal_code

    @postal_code.setter
    def postal_code(self, postal_code):
        """Sets the postal_code of this Location.

        :param postal_code: The postal_code of this Location.
        :type: str
        """
        if postal_code is not None and len(postal_code) > 255:
            raise MindsphereClientError("Invalid value for `postal_code`, length must be less than or equal to `255`")

        self._postal_code = postal_code

    @property
    def longitude(self):
        """Gets the longitude of this Location.
        The longitude part of the geographic coordinates

        :return: The longitude of this Location.
        :rtype: float
        """
        return self._longitude

    @longitude.setter
    def longitude(self, longitude):
        """Sets the longitude of this Location.
        The longitude part of the geographic coordinates

        :param longitude: The longitude of this Location.
        :type: float
        """
        if longitude is not None and longitude > 180:
            raise MindsphereClientError("Invalid value for `longitude`, must be a value less than or equal to `180`")
        if longitude is not None and longitude < -180:
            raise MindsphereClientError("Invalid value for `longitude`, must be a value greater than or equal to `-180`")

        self._longitude = longitude

    @property
    def latitude(self):
        """Gets the latitude of this Location.
        The latitude part of the geographic coordinates

        :return: The latitude of this Location.
        :rtype: float
        """
        return self._latitude

    @latitude.setter
    def latitude(self, latitude):
        """Sets the latitude of this Location.
        The latitude part of the geographic coordinates

        :param latitude: The latitude of this Location.
        :type: float
        """
        if latitude is not None and latitude > 90:
            raise MindsphereClientError("Invalid value for `latitude`, must be a value less than or equal to `90`")
        if latitude is not None and latitude < -90:
            raise MindsphereClientError("Invalid value for `latitude`, must be a value greater than or equal to `-90`")

        self._latitude = latitude

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(Location, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, Location):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
