# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six

from assetmanagement.models.aspect import Aspect
from assetmanagement.models.asset_type_id import AssetTypeId
from assetmanagement.models.asset_update import AssetUpdate
from assetmanagement.models.file_assignment import FileAssignment
from assetmanagement.models.location import Location
from assetmanagement.models.timezone import Timezone
from assetmanagement.models.twin_type import TwinType
from assetmanagement.models.unique_id import UniqueId
from assetmanagement.models.variable import Variable
from mindsphere_core.exceptions import MindsphereClientError


class Asset(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'name': 'str',
        'external_id': 'str',
        'description': 'str',
        'location': 'Location',
        'variables': 'list[Variable]',
        'aspects': 'list[Aspect]',
        'file_assignments': 'list[FileAssignment]',
        'type_id': 'AssetTypeId',
        'parent_id': 'UniqueId',
        'timezone': 'Timezone',
        'twin_type': 'TwinType'
    }

    attribute_map = {
        'name': 'name',
        'external_id': 'externalId',
        'description': 'description',
        'location': 'location',
        'variables': 'variables',
        'aspects': 'aspects',
        'file_assignments': 'fileAssignments',
        'type_id': 'typeId',
        'parent_id': 'parentId',
        'timezone': 'timezone',
        'twin_type': 'twinType'
    }

    def __init__(self, name=None, external_id=None, description=None, location=None, variables=None, aspects=None, file_assignments=None, type_id=None, parent_id=None, timezone=None, twin_type=None):
        self._name = name
        self._external_id = external_id
        self._description = description
        self._location = location
        self._variables = variables
        self._aspects = aspects
        self._file_assignments = file_assignments
        self._type_id = type_id
        self._parent_id = parent_id
        self._timezone = timezone
        self._twin_type = twin_type
        self.discriminator = None

    @property
    def name(self):
        """Gets the name of this Asset.
        Name of the asset

        :return: The name of this Asset.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        """Sets the name of this Asset.
        Name of the asset

        :param name: The name of this Asset.
        :type: str
        """
        if name is None:
            raise MindsphereClientError("Invalid value for `name`, must not be `None`")
        if name is not None and len(name) > 128:
            raise MindsphereClientError("Invalid value for `name`, length must be less than or equal to `128`")
        if name is not None and len(name) < 1:
            raise MindsphereClientError("Invalid value for `name`, length must be greater than or equal to `1`")
        if name is not None and not re.search(r'[^\/\\\\]*', name):
            raise MindsphereClientError(r"Invalid value for `name`, must be a follow pattern or equal to `/[^\/\\\\]*/`")

        self._name = name

    @property
    def external_id(self):
        """Gets the external_id of this Asset.
        The id given by the user

        :return: The external_id of this Asset.
        :rtype: str
        """
        return self._external_id

    @external_id.setter
    def external_id(self, external_id):
        """Sets the external_id of this Asset.
        The id given by the user

        :param external_id: The external_id of this Asset.
        :type: str
        """
        if external_id is not None and len(external_id) > 255:
            raise MindsphereClientError("Invalid value for `external_id`, length must be less than or equal to `255`")

        self._external_id = external_id

    @property
    def description(self):
        """Gets the description of this Asset.
        The description of the asset

        :return: The description of this Asset.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        """Sets the description of this Asset.
        The description of the asset

        :param description: The description of this Asset.
        :type: str
        """
        if description is not None and len(description) > 255:
            raise MindsphereClientError("Invalid value for `description`, length must be less than or equal to `255`")

        self._description = description

    @property
    def location(self):
        """Gets the location of this Asset.

        :return: The location of this Asset.
        :rtype: Location
        """
        return self._location

    @location.setter
    def location(self, location):
        """Sets the location of this Asset.

        :param location: The location of this Asset.
        :type: Location
        """

        self._location = location

    @property
    def variables(self):
        """Gets the variables of this Asset.

        :return: The variables of this Asset.
        :rtype: list[Variable]
        """
        return self._variables

    @variables.setter
    def variables(self, variables):
        """Sets the variables of this Asset.

        :param variables: The variables of this Asset.
        :type: list[Variable]
        """

        self._variables = variables

    @property
    def aspects(self):
        """Gets the aspects of this Asset.

        :return: The aspects of this Asset.
        :rtype: list[Aspect]
        """
        return self._aspects

    @aspects.setter
    def aspects(self, aspects):
        """Sets the aspects of this Asset.

        :param aspects: The aspects of this Asset.
        :type: list[Aspect]
        """

        self._aspects = aspects

    @property
    def file_assignments(self):
        """Gets the file_assignments of this Asset.

        :return: The file_assignments of this Asset.
        :rtype: list[FileAssignment]
        """
        return self._file_assignments

    @file_assignments.setter
    def file_assignments(self, file_assignments):
        """Sets the file_assignments of this Asset.

        :param file_assignments: The file_assignments of this Asset.
        :type: list[FileAssignment]
        """

        self._file_assignments = file_assignments

    @property
    def type_id(self):
        """Gets the type_id of this Asset.

        :return: The type_id of this Asset.
        :rtype: AssetTypeId
        """
        return self._type_id

    @type_id.setter
    def type_id(self, type_id):
        """Sets the type_id of this Asset.

        :param type_id: The type_id of this Asset.
        :type: AssetTypeId
        """

        self._type_id = type_id

    @property
    def parent_id(self):
        """Gets the parent_id of this Asset.

        :return: The parent_id of this Asset.
        :rtype: UniqueId
        """
        return self._parent_id

    @parent_id.setter
    def parent_id(self, parent_id):
        """Sets the parent_id of this Asset.

        :param parent_id: The parent_id of this Asset.
        :type: UniqueId
        """

        self._parent_id = parent_id

    @property
    def timezone(self):
        """Gets the timezone of this Asset.

        :return: The timezone of this Asset.
        :rtype: Timezone
        """
        return self._timezone

    @timezone.setter
    def timezone(self, timezone):
        """Sets the timezone of this Asset.

        :param timezone: The timezone of this Asset.
        :type: Timezone
        """

        self._timezone = timezone

    @property
    def twin_type(self):
        """Gets the twin_type of this Asset.

        :return: The twin_type of this Asset.
        :rtype: TwinType
        """
        return self._twin_type

    @twin_type.setter
    def twin_type(self, twin_type):
        """Sets the twin_type of this Asset.

        :param twin_type: The twin_type of this Asset.
        :type: TwinType
        """

        self._twin_type = twin_type

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(Asset, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, Asset):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
