# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six

from assetmanagement.models.aspect import Aspect
from assetmanagement.models.file_assignment import FileAssignment
from assetmanagement.models.location import Location
from assetmanagement.models.variable import Variable
from mindsphere_core.exceptions import MindsphereClientError


class AssetUpdate(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'name': 'str',
        'external_id': 'str',
        'description': 'str',
        'location': 'Location',
        'variables': 'list[Variable]',
        'aspects': 'list[Aspect]',
        'file_assignments': 'list[FileAssignment]'
    }

    attribute_map = {
        'name': 'name',
        'external_id': 'externalId',
        'description': 'description',
        'location': 'location',
        'variables': 'variables',
        'aspects': 'aspects',
        'file_assignments': 'fileAssignments'
    }

    def __init__(self, name=None, external_id=None, description=None, location=None, variables=None, aspects=None, file_assignments=None):
        self._name = name
        self._external_id = external_id
        self._description = description
        self._location = location
        self._variables = variables
        self._aspects = aspects
        self._file_assignments = file_assignments
        self.discriminator = None

    @property
    def name(self):
        """Gets the name of this AssetUpdate.
        Name of the asset

        :return: The name of this AssetUpdate.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        """Sets the name of this AssetUpdate.
        Name of the asset

        :param name: The name of this AssetUpdate.
        :type: str
        """
        if name is None:
            raise MindsphereClientError("Invalid value for `name`, must not be `None`")
        if name is not None and len(name) > 128:
            raise MindsphereClientError("Invalid value for `name`, length must be less than or equal to `128`")
        if name is not None and len(name) < 1:
            raise MindsphereClientError("Invalid value for `name`, length must be greater than or equal to `1`")
        if name is not None and not re.search(r'[^\/\\\\]*', name):
            raise MindsphereClientError(r"Invalid value for `name`, must be a follow pattern or equal to `/[^\/\\\\]*/`")

        self._name = name

    @property
    def external_id(self):
        """Gets the external_id of this AssetUpdate.
        The id given by the user

        :return: The external_id of this AssetUpdate.
        :rtype: str
        """
        return self._external_id

    @external_id.setter
    def external_id(self, external_id):
        """Sets the external_id of this AssetUpdate.
        The id given by the user

        :param external_id: The external_id of this AssetUpdate.
        :type: str
        """
        if external_id is not None and len(external_id) > 255:
            raise MindsphereClientError("Invalid value for `external_id`, length must be less than or equal to `255`")

        self._external_id = external_id

    @property
    def description(self):
        """Gets the description of this AssetUpdate.
        The description of the asset

        :return: The description of this AssetUpdate.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        """Sets the description of this AssetUpdate.
        The description of the asset

        :param description: The description of this AssetUpdate.
        :type: str
        """
        if description is not None and len(description) > 255:
            raise MindsphereClientError("Invalid value for `description`, length must be less than or equal to `255`")

        self._description = description

    @property
    def location(self):
        """Gets the location of this AssetUpdate.

        :return: The location of this AssetUpdate.
        :rtype: Location
        """
        return self._location

    @location.setter
    def location(self, location):
        """Sets the location of this AssetUpdate.

        :param location: The location of this AssetUpdate.
        :type: Location
        """

        self._location = location

    @property
    def variables(self):
        """Gets the variables of this AssetUpdate.

        :return: The variables of this AssetUpdate.
        :rtype: list[Variable]
        """
        return self._variables

    @variables.setter
    def variables(self, variables):
        """Sets the variables of this AssetUpdate.

        :param variables: The variables of this AssetUpdate.
        :type: list[Variable]
        """

        self._variables = variables

    @property
    def aspects(self):
        """Gets the aspects of this AssetUpdate.

        :return: The aspects of this AssetUpdate.
        :rtype: list[Aspect]
        """
        return self._aspects

    @aspects.setter
    def aspects(self, aspects):
        """Sets the aspects of this AssetUpdate.

        :param aspects: The aspects of this AssetUpdate.
        :type: list[Aspect]
        """

        self._aspects = aspects

    @property
    def file_assignments(self):
        """Gets the file_assignments of this AssetUpdate.

        :return: The file_assignments of this AssetUpdate.
        :rtype: list[FileAssignment]
        """
        return self._file_assignments

    @file_assignments.setter
    def file_assignments(self, file_assignments):
        """Sets the file_assignments of this AssetUpdate.

        :param file_assignments: The file_assignments of this AssetUpdate.
        :type: list[FileAssignment]
        """

        self._file_assignments = file_assignments

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(AssetUpdate, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AssetUpdate):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
