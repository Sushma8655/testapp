# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six

from assetmanagement.models.asset_type import AssetType
from mindsphere_core.exceptions import MindsphereClientError


class SaveAssetTypeRequest(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'if_none_match': 'str',
        'if_match': 'str',
        'exploded': 'bool',
        'id': 'str',
        'assettype': 'AssetType'
    }

    attribute_map = {
        'if_none_match': 'If-None-Match',
        'if_match': 'If-Match',
        'exploded': 'exploded',
        'id': 'id',
        'assettype': 'assettype'
    }

    def __init__(self, if_none_match=None, if_match=None, exploded=None, id=None, assettype=None):
        self._if_none_match = if_none_match
        self._if_match = if_match
        self._exploded = exploded
        self._id = id
        self._assettype = assettype
        self.discriminator = None

    @property
    def if_none_match(self):
        """Gets the if_none_match of this SaveAssetTypeRequest.

        :return: The if_none_match of this SaveAssetTypeRequest.
        :rtype: str
        """
        return self._if_none_match

    @if_none_match.setter
    def if_none_match(self, if_none_match):
        """Sets the if_none_match of this SaveAssetTypeRequest.

        :param if_none_match: The if_none_match of this SaveAssetTypeRequest.
        :type: str
        """

        self._if_none_match = if_none_match

    @property
    def if_match(self):
        """Gets the if_match of this SaveAssetTypeRequest.

        :return: The if_match of this SaveAssetTypeRequest.
        :rtype: str
        """
        return self._if_match

    @if_match.setter
    def if_match(self, if_match):
        """Sets the if_match of this SaveAssetTypeRequest.

        :param if_match: The if_match of this SaveAssetTypeRequest.
        :type: str
        """

        self._if_match = if_match

    @property
    def exploded(self):
        """Gets the exploded of this SaveAssetTypeRequest.

        :return: The exploded of this SaveAssetTypeRequest.
        :rtype: bool
        """
        return self._exploded

    @exploded.setter
    def exploded(self, exploded):
        """Sets the exploded of this SaveAssetTypeRequest.

        :param exploded: The exploded of this SaveAssetTypeRequest.
        :type: bool
        """

        self._exploded = exploded

    @property
    def id(self):
        """Gets the id of this SaveAssetTypeRequest.

        :return: The id of this SaveAssetTypeRequest.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        """Sets the id of this SaveAssetTypeRequest.

        :param id: The id of this SaveAssetTypeRequest.
        :type: str
        """

        self._id = id

    @property
    def assettype(self):
        """Gets the assettype of this SaveAssetTypeRequest.

        :return: The assettype of this SaveAssetTypeRequest.
        :rtype: AssetType
        """
        return self._assettype

    @assettype.setter
    def assettype(self, assettype):
        """Sets the assettype of this SaveAssetTypeRequest.

        :param assettype: The assettype of this SaveAssetTypeRequest.
        :type: AssetType
        """

        self._assettype = assettype

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(SaveAssetTypeRequest, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, SaveAssetTypeRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
