# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six

from assetmanagement.models.variable_definition import VariableDefinition
from assetmanagement.models.variable_definition_resource_links import VariableDefinitionResourceLinks
from mindsphere_core.exceptions import MindsphereClientError


class VariableDefinitionResource(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'name': 'str',
        'data_type': 'str',
        'unit': 'str',
        'searchable': 'bool',
        'length': 'int',
        'default_value': 'str',
        'links': 'VariableDefinitionResourceLinks'
    }

    attribute_map = {
        'name': 'name',
        'data_type': 'dataType',
        'unit': 'unit',
        'searchable': 'searchable',
        'length': 'length',
        'default_value': 'defaultValue',
        'links': '_links'
    }

    def __init__(self, name=None, data_type=None, unit=None, searchable=False, length=None, default_value=None, links=None):
        self._name = name
        self._data_type = data_type
        self._unit = unit
        self._searchable = searchable
        self._length = length
        self._default_value = default_value
        self._links = links
        self.discriminator = None

    @property
    def name(self):
        """Gets the name of this VariableDefinitionResource.
        Name of the variable. Once set cannot be changed. Reserved words (id, name, description, tenant, etag, scope, properties, propertySets, extends, variables, aspects, parentTypeId) cannot be used as variable names.

        :return: The name of this VariableDefinitionResource.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        """Sets the name of this VariableDefinitionResource.
        Name of the variable. Once set cannot be changed. Reserved words (id, name, description, tenant, etag, scope, properties, propertySets, extends, variables, aspects, parentTypeId) cannot be used as variable names.

        :param name: The name of this VariableDefinitionResource.
        :type: str
        """
        if name is None:
            raise MindsphereClientError("Invalid value for `name`, must not be `None`")
        if name is not None and len(name) > 64:
            raise MindsphereClientError("Invalid value for `name`, length must be less than or equal to `64`")
        if name is not None and len(name) < 1:
            raise MindsphereClientError("Invalid value for `name`, length must be greater than or equal to `1`")
        if name is not None and not re.search(r'[a-zA-Z_][a-zA-Z0-9_]*', name):
            raise MindsphereClientError(r"Invalid value for `name`, must be a follow pattern or equal to `/[a-zA-Z_][a-zA-Z0-9_]*/`")

        self._name = name

    @property
    def data_type(self):
        """Gets the data_type of this VariableDefinitionResource.
        Data type of the variable. BIG_STRING could only be used by variables in dynamic aspect-types. Cannot be changed.

        :return: The data_type of this VariableDefinitionResource.
        :rtype: str
        """
        return self._data_type

    @data_type.setter
    def data_type(self, data_type):
        """Sets the data_type of this VariableDefinitionResource.
        Data type of the variable. BIG_STRING could only be used by variables in dynamic aspect-types. Cannot be changed.

        :param data_type: The data_type of this VariableDefinitionResource.
        :type: str
        """
        if data_type is None:
            raise MindsphereClientError("Invalid value for `data_type`, must not be `None`")
        allowed_values = ["BOOLEAN", "INT", "LONG", "DOUBLE", "STRING", "TIMESTAMP", "BIG_STRING"]
        if data_type.lower() not in [x.lower() for x in allowed_values]:
            raise MindsphereClientError(
                "Invalid value for `data_type` ({0}), must be one of {1}"
                .format(data_type, allowed_values)
            )

        self._data_type = data_type

    @property
    def unit(self):
        """Gets the unit of this VariableDefinitionResource.
        Unit of measurement. Cannot be changed.

        :return: The unit of this VariableDefinitionResource.
        :rtype: str
        """
        return self._unit

    @unit.setter
    def unit(self, unit):
        """Sets the unit of this VariableDefinitionResource.
        Unit of measurement. Cannot be changed.

        :param unit: The unit of this VariableDefinitionResource.
        :type: str
        """
        if unit is not None and len(unit) > 32:
            raise MindsphereClientError("Invalid value for `unit`, length must be less than or equal to `32`")
        if unit is not None and not re.search(r'[^\\\']*', unit):
            raise MindsphereClientError(r"Invalid value for `unit`, must be a follow pattern or equal to `/[^\\']*/`")

        self._unit = unit

    @property
    def searchable(self):
        """Gets the searchable of this VariableDefinitionResource.
        Indicates whether sorting and filtering is allowed on this variable. Only usable for static properties. Cannot be changed.

        :return: The searchable of this VariableDefinitionResource.
        :rtype: bool
        """
        return self._searchable

    @searchable.setter
    def searchable(self, searchable):
        """Sets the searchable of this VariableDefinitionResource.
        Indicates whether sorting and filtering is allowed on this variable. Only usable for static properties. Cannot be changed.

        :param searchable: The searchable of this VariableDefinitionResource.
        :type: bool
        """

        self._searchable = searchable

    @property
    def length(self):
        """Gets the length of this VariableDefinitionResource.
        The max length of the variable's value. The length field is only used for variables of string or big_string dataType. Max length for string is 255 and max length for big_string 100000. Cannot be changed.

        :return: The length of this VariableDefinitionResource.
        :rtype: int
        """
        return self._length

    @length.setter
    def length(self, length):
        """Sets the length of this VariableDefinitionResource.
        The max length of the variable's value. The length field is only used for variables of string or big_string dataType. Max length for string is 255 and max length for big_string 100000. Cannot be changed.

        :param length: The length of this VariableDefinitionResource.
        :type: int
        """
        if length is not None and length > 100000:
            raise MindsphereClientError("Invalid value for `length`, must be a value less than or equal to `100000`")
        if length is not None and length < 1:
            raise MindsphereClientError("Invalid value for `length`, must be a value greater than or equal to `1`")

        self._length = length

    @property
    def default_value(self):
        """Gets the default_value of this VariableDefinitionResource.
        The default value of the variable. It must be compatible with the dataType! The default value will be inherited by the asset type's child types and by the asset instantiating it. It can be defined in aspect types and asset types.

        :return: The default_value of this VariableDefinitionResource.
        :rtype: str
        """
        return self._default_value

    @default_value.setter
    def default_value(self, default_value):
        """Sets the default_value of this VariableDefinitionResource.
        The default value of the variable. It must be compatible with the dataType! The default value will be inherited by the asset type's child types and by the asset instantiating it. It can be defined in aspect types and asset types.

        :param default_value: The default_value of this VariableDefinitionResource.
        :type: str
        """
        if default_value is not None and len(default_value) > 255:
            raise MindsphereClientError("Invalid value for `default_value`, length must be less than or equal to `255`")
        if default_value is not None and len(default_value) < 1:
            raise MindsphereClientError("Invalid value for `default_value`, length must be greater than or equal to `1`")

        self._default_value = default_value

    @property
    def links(self):
        """Gets the links of this VariableDefinitionResource.

        :return: The links of this VariableDefinitionResource.
        :rtype: VariableDefinitionResourceLinks
        """
        return self._links

    @links.setter
    def links(self, links):
        """Sets the links of this VariableDefinitionResource.

        :param links: The links of this VariableDefinitionResource.
        :type: VariableDefinitionResourceLinks
        """

        self._links = links

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(VariableDefinitionResource, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, VariableDefinitionResource):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
