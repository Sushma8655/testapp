# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class ListFilesRequest(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'filter': 'str',
        'if_none_match': 'str',
        'size': 'int',
        'page': 'int',
        'sort': 'str'
    }

    attribute_map = {
        'filter': 'filter',
        'if_none_match': 'If-None-Match',
        'size': 'size',
        'page': 'page',
        'sort': 'sort'
    }

    def __init__(self, filter=None, if_none_match=None, size=None, page=None, sort=None):
        self._filter = filter
        self._if_none_match = if_none_match
        self._size = size
        self._page = page
        self._sort = sort
        self.discriminator = None

    @property
    def filter(self):
        """Gets the filter of this ListFilesRequest.

        :return: The filter of this ListFilesRequest.
        :rtype: str
        """
        return self._filter

    @filter.setter
    def filter(self, filter):
        """Sets the filter of this ListFilesRequest.

        :param filter: The filter of this ListFilesRequest.
        :type: str
        """

        self._filter = filter

    @property
    def if_none_match(self):
        """Gets the if_none_match of this ListFilesRequest.

        :return: The if_none_match of this ListFilesRequest.
        :rtype: str
        """
        return self._if_none_match

    @if_none_match.setter
    def if_none_match(self, if_none_match):
        """Sets the if_none_match of this ListFilesRequest.

        :param if_none_match: The if_none_match of this ListFilesRequest.
        :type: str
        """

        self._if_none_match = if_none_match

    @property
    def size(self):
        """Gets the size of this ListFilesRequest.

        :return: The size of this ListFilesRequest.
        :rtype: int
        """
        return self._size

    @size.setter
    def size(self, size):
        """Sets the size of this ListFilesRequest.

        :param size: The size of this ListFilesRequest.
        :type: int
        """

        self._size = size

    @property
    def page(self):
        """Gets the page of this ListFilesRequest.

        :return: The page of this ListFilesRequest.
        :rtype: int
        """
        return self._page

    @page.setter
    def page(self, page):
        """Sets the page of this ListFilesRequest.

        :param page: The page of this ListFilesRequest.
        :type: int
        """

        self._page = page

    @property
    def sort(self):
        """Gets the sort of this ListFilesRequest.

        :return: The sort of this ListFilesRequest.
        :rtype: str
        """
        return self._sort

    @sort.setter
    def sort(self, sort):
        """Sets the sort of this ListFilesRequest.

        :param sort: The sort of this ListFilesRequest.
        :type: str
        """

        self._sort = sort

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(ListFilesRequest, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListFilesRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
