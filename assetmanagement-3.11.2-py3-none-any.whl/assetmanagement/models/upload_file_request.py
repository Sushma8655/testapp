# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class UploadFileRequest(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'file': 'file',
        'scope': 'str',
        'name': 'str',
        'description': 'str'
    }

    attribute_map = {
        'file': 'file',
        'scope': 'scope',
        'name': 'name',
        'description': 'description'
    }

    def __init__(self, file=None, scope=None, name=None, description=None):
        self._file = file
        self._scope = scope
        self._name = name
        self._description = description
        self.discriminator = None

    @property
    def file(self):
        """Gets the file of this UploadFileRequest.

        :return: The file of this UploadFileRequest.
        :rtype: file
        """
        return self._file

    @file.setter
    def file(self, file):
        """Sets the file of this UploadFileRequest.

        :param file: The file of this UploadFileRequest.
        :type: file
        """

        self._file = file

    @property
    def scope(self):
        """Gets the scope of this UploadFileRequest.

        :return: The scope of this UploadFileRequest.
        :rtype: str
        """
        return self._scope

    @scope.setter
    def scope(self, scope):
        """Sets the scope of this UploadFileRequest.

        :param scope: The scope of this UploadFileRequest.
        :type: str
        """

        self._scope = scope

    @property
    def name(self):
        """Gets the name of this UploadFileRequest.

        :return: The name of this UploadFileRequest.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        """Sets the name of this UploadFileRequest.

        :param name: The name of this UploadFileRequest.
        :type: str
        """

        self._name = name

    @property
    def description(self):
        """Gets the description of this UploadFileRequest.

        :return: The description of this UploadFileRequest.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        """Sets the description of this UploadFileRequest.

        :param description: The description of this UploadFileRequest.
        :type: str
        """

        self._description = description

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(UploadFileRequest, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UploadFileRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
