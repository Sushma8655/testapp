from enum import Enum


class FieldTypeEnum(Enum):
    ASSET_ID = "assetId",
    TENANT_ID = "tenantId",
    NAME = 'name',
    EXTERNAL_ID = "externalId",
    SUBTENANT = "subTenant",
    DELETED = "deleted",
    PARENT_ID = "parentId",
    PARENT_TYPE_ID = "parentTypeId",
    TYPE_ID = "typeId"

    def __init__(self, value=None):
        self._value = value
        self.discriminator = None

    @property
    def value(self):
        return self._value

    @value.setter
    def value(self, value):
        """Sets the value of this FieldTypeEnum.

        :param value: The value of this FieldTypeEnum.
        :type: str
        """
        self._value = value
