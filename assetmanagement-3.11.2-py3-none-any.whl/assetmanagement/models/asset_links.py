# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six

from assetmanagement.models.asset_links_aspects import AssetLinksAspects
from assetmanagement.models.asset_links_children import AssetLinksChildren
from assetmanagement.models.asset_links_location import AssetLinksLocation
from assetmanagement.models.asset_links_parent import AssetLinksParent
from assetmanagement.models.asset_links_self import AssetLinksSelf
from assetmanagement.models.asset_links_t2_tenant import AssetLinksT2Tenant
from assetmanagement.models.asset_links_variables import AssetLinksVariables
from mindsphere_core.exceptions import MindsphereClientError


class AssetLinks(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        '_self': 'AssetLinksSelf',
        'parent': 'AssetLinksParent',
        'children': 'AssetLinksChildren',
        'variables': 'AssetLinksVariables',
        'aspects': 'AssetLinksAspects',
        't2_tenant': 'AssetLinksT2Tenant',
        'location': 'AssetLinksLocation'
    }

    attribute_map = {
        '_self': 'self',
        'parent': 'parent',
        'children': 'children',
        'variables': 'variables',
        'aspects': 'aspects',
        't2_tenant': 't2Tenant',
        'location': 'location'
    }

    def __init__(self, _self=None, parent=None, children=None, variables=None, aspects=None, t2_tenant=None, location=None):
        self.__self = _self
        self._parent = parent
        self._children = children
        self._variables = variables
        self._aspects = aspects
        self._t2_tenant = t2_tenant
        self._location = location
        self.discriminator = None

    @property
    def _self(self):
        """Gets the _self of this AssetLinks.

        :return: The _self of this AssetLinks.
        :rtype: AssetLinksSelf
        """
        return self.__self

    @_self.setter
    def _self(self, _self):
        """Sets the _self of this AssetLinks.

        :param _self: The _self of this AssetLinks.
        :type: AssetLinksSelf
        """

        self.__self = _self

    @property
    def parent(self):
        """Gets the parent of this AssetLinks.

        :return: The parent of this AssetLinks.
        :rtype: AssetLinksParent
        """
        return self._parent

    @parent.setter
    def parent(self, parent):
        """Sets the parent of this AssetLinks.

        :param parent: The parent of this AssetLinks.
        :type: AssetLinksParent
        """

        self._parent = parent

    @property
    def children(self):
        """Gets the children of this AssetLinks.

        :return: The children of this AssetLinks.
        :rtype: AssetLinksChildren
        """
        return self._children

    @children.setter
    def children(self, children):
        """Sets the children of this AssetLinks.

        :param children: The children of this AssetLinks.
        :type: AssetLinksChildren
        """

        self._children = children

    @property
    def variables(self):
        """Gets the variables of this AssetLinks.

        :return: The variables of this AssetLinks.
        :rtype: AssetLinksVariables
        """
        return self._variables

    @variables.setter
    def variables(self, variables):
        """Sets the variables of this AssetLinks.

        :param variables: The variables of this AssetLinks.
        :type: AssetLinksVariables
        """

        self._variables = variables

    @property
    def aspects(self):
        """Gets the aspects of this AssetLinks.

        :return: The aspects of this AssetLinks.
        :rtype: AssetLinksAspects
        """
        return self._aspects

    @aspects.setter
    def aspects(self, aspects):
        """Sets the aspects of this AssetLinks.

        :param aspects: The aspects of this AssetLinks.
        :type: AssetLinksAspects
        """

        self._aspects = aspects

    @property
    def t2_tenant(self):
        """Gets the t2_tenant of this AssetLinks.

        :return: The t2_tenant of this AssetLinks.
        :rtype: AssetLinksT2Tenant
        """
        return self._t2_tenant

    @t2_tenant.setter
    def t2_tenant(self, t2_tenant):
        """Sets the t2_tenant of this AssetLinks.

        :param t2_tenant: The t2_tenant of this AssetLinks.
        :type: AssetLinksT2Tenant
        """

        self._t2_tenant = t2_tenant

    @property
    def location(self):
        """Gets the location of this AssetLinks.

        :return: The location of this AssetLinks.
        :rtype: AssetLinksLocation
        """
        return self._location

    @location.setter
    def location(self, location):
        """Sets the location of this AssetLinks.

        :param location: The location of this AssetLinks.
        :type: AssetLinksLocation
        """

        self._location = location

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(AssetLinks, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AssetLinks):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
