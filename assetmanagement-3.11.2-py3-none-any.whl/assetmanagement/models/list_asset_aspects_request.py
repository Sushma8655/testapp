# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class ListAssetAspectsRequest(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'filter': 'str',
        'if_none_match': 'str',
        'size': 'int',
        'id': 'str',
        'page': 'int',
        'sort': 'str'
    }

    attribute_map = {
        'filter': 'filter',
        'if_none_match': 'If-None-Match',
        'size': 'size',
        'id': 'id',
        'page': 'page',
        'sort': 'sort'
    }

    def __init__(self, filter=None, if_none_match=None, size=None, id=None, page=None, sort=None):
        self._filter = filter
        self._if_none_match = if_none_match
        self._size = size
        self._id = id
        self._page = page
        self._sort = sort
        self.discriminator = None

    @property
    def filter(self):
        """Gets the filter of this ListAssetAspectsRequest.

        :return: The filter of this ListAssetAspectsRequest.
        :rtype: str
        """
        return self._filter

    @filter.setter
    def filter(self, filter):
        """Sets the filter of this ListAssetAspectsRequest.

        :param filter: The filter of this ListAssetAspectsRequest.
        :type: str
        """

        self._filter = filter

    @property
    def if_none_match(self):
        """Gets the if_none_match of this ListAssetAspectsRequest.

        :return: The if_none_match of this ListAssetAspectsRequest.
        :rtype: str
        """
        return self._if_none_match

    @if_none_match.setter
    def if_none_match(self, if_none_match):
        """Sets the if_none_match of this ListAssetAspectsRequest.

        :param if_none_match: The if_none_match of this ListAssetAspectsRequest.
        :type: str
        """

        self._if_none_match = if_none_match

    @property
    def size(self):
        """Gets the size of this ListAssetAspectsRequest.

        :return: The size of this ListAssetAspectsRequest.
        :rtype: int
        """
        return self._size

    @size.setter
    def size(self, size):
        """Sets the size of this ListAssetAspectsRequest.

        :param size: The size of this ListAssetAspectsRequest.
        :type: int
        """

        self._size = size

    @property
    def id(self):
        """Gets the id of this ListAssetAspectsRequest.

        :return: The id of this ListAssetAspectsRequest.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        """Sets the id of this ListAssetAspectsRequest.

        :param id: The id of this ListAssetAspectsRequest.
        :type: str
        """

        self._id = id

    @property
    def page(self):
        """Gets the page of this ListAssetAspectsRequest.

        :return: The page of this ListAssetAspectsRequest.
        :rtype: int
        """
        return self._page

    @page.setter
    def page(self, page):
        """Sets the page of this ListAssetAspectsRequest.

        :param page: The page of this ListAssetAspectsRequest.
        :type: int
        """

        self._page = page

    @property
    def sort(self):
        """Gets the sort of this ListAssetAspectsRequest.

        :return: The sort of this ListAssetAspectsRequest.
        :rtype: str
        """
        return self._sort

    @sort.setter
    def sort(self, sort):
        """Sets the sort of this ListAssetAspectsRequest.

        :param sort: The sort of this ListAssetAspectsRequest.
        :type: str
        """

        self._sort = sort

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(ListAssetAspectsRequest, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListAssetAspectsRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
