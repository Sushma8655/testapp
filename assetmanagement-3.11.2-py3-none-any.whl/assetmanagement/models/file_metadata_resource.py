# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six

from assetmanagement.models.e_tag import ETag
from assetmanagement.models.file_metadata_resource_links import FileMetadataResourceLinks
from assetmanagement.models.tenant_id import TenantId
from assetmanagement.models.unique_id import UniqueId
from mindsphere_core.exceptions import MindsphereClientError


class FileMetadataResource(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'id': 'UniqueId',
        'name': 'str',
        'original_file_name': 'str',
        'description': 'str',
        'tenant_id': 'TenantId',
        'sub_tenant': 'str',
        'uploaded': 'datetime',
        'last_modified': 'datetime',
        'is_assigned': 'bool',
        'scope': 'str',
        'etag': 'ETag',
        'links': 'FileMetadataResourceLinks'
    }

    attribute_map = {
        'id': 'id',
        'name': 'name',
        'original_file_name': 'originalFileName',
        'description': 'description',
        'tenant_id': 'tenantId',
        'sub_tenant': 'subTenant',
        'uploaded': 'uploaded',
        'last_modified': 'lastModified',
        'is_assigned': 'isAssigned',
        'scope': 'scope',
        'etag': 'etag',
        'links': '_links'
    }

    def __init__(self, id=None, name=None, original_file_name=None, description=None, tenant_id=None, sub_tenant=None, uploaded=None, last_modified=None, is_assigned=None, scope='PRIVATE', etag=None, links=None):
        self._id = id
        self._name = name
        self._original_file_name = original_file_name
        self._description = description
        self._tenant_id = tenant_id
        self._sub_tenant = sub_tenant
        self._uploaded = uploaded
        self._last_modified = last_modified
        self._is_assigned = is_assigned
        self._scope = scope
        self._etag = etag
        self._links = links
        self.discriminator = None

    @property
    def id(self):
        """Gets the id of this FileMetadataResource.

        :return: The id of this FileMetadataResource.
        :rtype: UniqueId
        """
        return self._id

    @id.setter
    def id(self, id):
        """Sets the id of this FileMetadataResource.

        :param id: The id of this FileMetadataResource.
        :type: UniqueId
        """

        self._id = id

    @property
    def name(self):
        """Gets the name of this FileMetadataResource.
        File name given by the user

        :return: The name of this FileMetadataResource.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        """Sets the name of this FileMetadataResource.
        File name given by the user

        :param name: The name of this FileMetadataResource.
        :type: str
        """

        self._name = name

    @property
    def original_file_name(self):
        """Gets the original_file_name of this FileMetadataResource.
        Original filename of the file

        :return: The original_file_name of this FileMetadataResource.
        :rtype: str
        """
        return self._original_file_name

    @original_file_name.setter
    def original_file_name(self, original_file_name):
        """Sets the original_file_name of this FileMetadataResource.
        Original filename of the file

        :param original_file_name: The original_file_name of this FileMetadataResource.
        :type: str
        """

        self._original_file_name = original_file_name

    @property
    def description(self):
        """Gets the description of this FileMetadataResource.
        File description

        :return: The description of this FileMetadataResource.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        """Sets the description of this FileMetadataResource.
        File description

        :param description: The description of this FileMetadataResource.
        :type: str
        """

        self._description = description

    @property
    def tenant_id(self):
        """Gets the tenant_id of this FileMetadataResource.

        :return: The tenant_id of this FileMetadataResource.
        :rtype: TenantId
        """
        return self._tenant_id

    @tenant_id.setter
    def tenant_id(self, tenant_id):
        """Sets the tenant_id of this FileMetadataResource.

        :param tenant_id: The tenant_id of this FileMetadataResource.
        :type: TenantId
        """

        self._tenant_id = tenant_id

    @property
    def sub_tenant(self):
        """Gets the sub_tenant of this FileMetadataResource.
        The id of the end-customer

        :return: The sub_tenant of this FileMetadataResource.
        :rtype: str
        """
        return self._sub_tenant

    @sub_tenant.setter
    def sub_tenant(self, sub_tenant):
        """Sets the sub_tenant of this FileMetadataResource.
        The id of the end-customer

        :param sub_tenant: The sub_tenant of this FileMetadataResource.
        :type: str
        """

        self._sub_tenant = sub_tenant

    @property
    def uploaded(self):
        """Gets the uploaded of this FileMetadataResource.
        The time of the file upload

        :return: The uploaded of this FileMetadataResource.
        :rtype: datetime
        """
        return self._uploaded

    @uploaded.setter
    def uploaded(self, uploaded):
        """Sets the uploaded of this FileMetadataResource.
        The time of the file upload

        :param uploaded: The uploaded of this FileMetadataResource.
        :type: datetime
        """

        self._uploaded = uploaded

    @property
    def last_modified(self):
        """Gets the last_modified of this FileMetadataResource.
        The time of the latest modification of the file

        :return: The last_modified of this FileMetadataResource.
        :rtype: datetime
        """
        return self._last_modified

    @last_modified.setter
    def last_modified(self, last_modified):
        """Sets the last_modified of this FileMetadataResource.
        The time of the latest modification of the file

        :param last_modified: The last_modified of this FileMetadataResource.
        :type: datetime
        """

        self._last_modified = last_modified

    @property
    def is_assigned(self):
        """Gets the is_assigned of this FileMetadataResource.
        Is the file used in any file assignment

        :return: The is_assigned of this FileMetadataResource.
        :rtype: bool
        """
        return self._is_assigned

    @is_assigned.setter
    def is_assigned(self, is_assigned):
        """Sets the is_assigned of this FileMetadataResource.
        Is the file used in any file assignment

        :param is_assigned: The is_assigned of this FileMetadataResource.
        :type: bool
        """

        self._is_assigned = is_assigned

    @property
    def scope(self):
        """Gets the scope of this FileMetadataResource.
        The visibility of the file. PRIVATE hides files between subTenants and the t1Tenant's files from the subTenants. PUBLIC is visible for every user of the tenant.

        :return: The scope of this FileMetadataResource.
        :rtype: str
        """
        return self._scope

    @scope.setter
    def scope(self, scope):
        """Sets the scope of this FileMetadataResource.
        The visibility of the file. PRIVATE hides files between subTenants and the t1Tenant's files from the subTenants. PUBLIC is visible for every user of the tenant.

        :param scope: The scope of this FileMetadataResource.
        :type: str
        """
        allowed_values = ["PUBLIC", "PRIVATE"]
        if scope.lower() not in [x.lower() for x in allowed_values]:
            raise MindsphereClientError(
                "Invalid value for `scope` ({0}), must be one of {1}"
                .format(scope, allowed_values)
            )

        self._scope = scope

    @property
    def etag(self):
        """Gets the etag of this FileMetadataResource.

        :return: The etag of this FileMetadataResource.
        :rtype: ETag
        """
        return self._etag

    @etag.setter
    def etag(self, etag):
        """Sets the etag of this FileMetadataResource.

        :param etag: The etag of this FileMetadataResource.
        :type: ETag
        """

        self._etag = etag

    @property
    def links(self):
        """Gets the links of this FileMetadataResource.

        :return: The links of this FileMetadataResource.
        :rtype: FileMetadataResourceLinks
        """
        return self._links

    @links.setter
    def links(self, links):
        """Sets the links of this FileMetadataResource.

        :param links: The links of this FileMetadataResource.
        :type: FileMetadataResourceLinks
        """

        self._links = links

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(FileMetadataResource, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, FileMetadataResource):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
