# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six

from assetmanagement.models.aspect_links import AspectLinks
from assetmanagement.models.aspect_variable import AspectVariable
from assetmanagement.models.unique_id import UniqueId
from mindsphere_core.exceptions import MindsphereClientError


class AspectResource(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'aspect_type_id': 'str',
        'holder_asset_id': 'UniqueId',
        'name': 'str',
        'category': 'str',
        'description': 'str',
        'variables': 'list[AspectVariable]',
        'links': 'AspectLinks'
    }

    attribute_map = {
        'aspect_type_id': 'aspectTypeId',
        'holder_asset_id': 'holderAssetId',
        'name': 'name',
        'category': 'category',
        'description': 'description',
        'variables': 'variables',
        'links': '_links'
    }

    def __init__(self, aspect_type_id=None, holder_asset_id=None, name=None, category=None, description=None, variables=None, links=None):
        self._aspect_type_id = aspect_type_id
        self._holder_asset_id = holder_asset_id
        self._name = name
        self._category = category
        self._description = description
        self._variables = variables
        self._links = links
        self.discriminator = None

    @property
    def aspect_type_id(self):
        """Gets the aspect_type_id of this AspectResource.
        ID of the Aspect type

        :return: The aspect_type_id of this AspectResource.
        :rtype: str
        """
        return self._aspect_type_id

    @aspect_type_id.setter
    def aspect_type_id(self, aspect_type_id):
        """Sets the aspect_type_id of this AspectResource.
        ID of the Aspect type

        :param aspect_type_id: The aspect_type_id of this AspectResource.
        :type: str
        """

        self._aspect_type_id = aspect_type_id

    @property
    def holder_asset_id(self):
        """Gets the holder_asset_id of this AspectResource.

        :return: The holder_asset_id of this AspectResource.
        :rtype: UniqueId
        """
        return self._holder_asset_id

    @holder_asset_id.setter
    def holder_asset_id(self, holder_asset_id):
        """Sets the holder_asset_id of this AspectResource.

        :param holder_asset_id: The holder_asset_id of this AspectResource.
        :type: UniqueId
        """

        self._holder_asset_id = holder_asset_id

    @property
    def name(self):
        """Gets the name of this AspectResource.
        Name of the aspect

        :return: The name of this AspectResource.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        """Sets the name of this AspectResource.
        Name of the aspect

        :param name: The name of this AspectResource.
        :type: str
        """
        if name is None:
            raise MindsphereClientError("Invalid value for `name`, must not be `None`")
        if name is not None and not re.search(r'[a-zA-Z0-9_]+', name):
            raise MindsphereClientError(r"Invalid value for `name`, must be a follow pattern or equal to `/[a-zA-Z0-9_]+/`")

        self._name = name

    @property
    def category(self):
        """Gets the category of this AspectResource.

        :return: The category of this AspectResource.
        :rtype: str
        """
        return self._category

    @category.setter
    def category(self, category):
        """Sets the category of this AspectResource.

        :param category: The category of this AspectResource.
        :type: str
        """
        allowed_values = ["dynamic", "static"]
        if category.lower() not in [x.lower() for x in allowed_values]:
            raise MindsphereClientError(
                "Invalid value for `category` ({0}), must be one of {1}"
                .format(category, allowed_values)
            )

        self._category = category

    @property
    def description(self):
        """Gets the description of this AspectResource.
        The description of the aspect

        :return: The description of this AspectResource.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        """Sets the description of this AspectResource.
        The description of the aspect

        :param description: The description of this AspectResource.
        :type: str
        """
        if description is not None and not re.search(r'[^\\\']*', description):
            raise MindsphereClientError(r"Invalid value for `description`, must be a follow pattern or equal to `/[^\\']*/`")

        self._description = description

    @property
    def variables(self):
        """Gets the variables of this AspectResource.

        :return: The variables of this AspectResource.
        :rtype: list[AspectVariable]
        """
        return self._variables

    @variables.setter
    def variables(self, variables):
        """Sets the variables of this AspectResource.

        :param variables: The variables of this AspectResource.
        :type: list[AspectVariable]
        """

        self._variables = variables

    @property
    def links(self):
        """Gets the links of this AspectResource.

        :return: The links of this AspectResource.
        :rtype: AspectLinks
        """
        return self._links

    @links.setter
    def links(self, links):
        """Sets the links of this AspectResource.

        :param links: The links of this AspectResource.
        :type: AspectLinks
        """

        self._links = links

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(AspectResource, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AspectResource):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
