# coding: utf-8

"""
    Asset Management API

    Service for configuring, reading and managing assets, asset ~ and aspect types.  # noqa: E501
"""


import pprint
import re
import six

from assetmanagement.models.asset_type_base import AssetTypeBase
from assetmanagement.models.asset_type_id import AssetTypeId
from assetmanagement.models.asset_type_links import AssetTypeLinks
from assetmanagement.models.asset_type_resource_aspects import AssetTypeResourceAspects
from assetmanagement.models.e_tag import ETag
from assetmanagement.models.file_assignment_resource import FileAssignmentResource
from assetmanagement.models.tenant_id import TenantId
from assetmanagement.models.variable_definition_resource import VariableDefinitionResource
from mindsphere_core.exceptions import MindsphereClientError


class AssetTypeResource(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'name': 'str',
        'description': 'str',
        'parent_type_id': 'AssetTypeId',
        'instantiable': 'bool',
        'scope': 'str',
        'id': 'AssetTypeId',
        'tenant_id': 'TenantId',
        'etag': 'ETag',
        'aspects': 'list[AssetTypeResourceAspects]',
        'variables': 'list[VariableDefinitionResource]',
        'file_assignments': 'list[FileAssignmentResource]',
        'links': 'AssetTypeLinks'
    }

    attribute_map = {
        'name': 'name',
        'description': 'description',
        'parent_type_id': 'parentTypeId',
        'instantiable': 'instantiable',
        'scope': 'scope',
        'id': 'id',
        'tenant_id': 'tenantId',
        'etag': 'etag',
        'aspects': 'aspects',
        'variables': 'variables',
        'file_assignments': 'fileAssignments',
        'links': '_links'
    }

    def __init__(self, name=None, description=None, parent_type_id=None, instantiable=True, scope='private', id=None, tenant_id=None, etag=None, aspects=None, variables=None, file_assignments=None, links=None):
        self._name = name
        self._description = description
        self._parent_type_id = parent_type_id
        self._instantiable = instantiable
        self._scope = scope
        self._id = id
        self._tenant_id = tenant_id
        self._etag = etag
        self._aspects = aspects
        self._variables = variables
        self._file_assignments = file_assignments
        self._links = links
        self.discriminator = None

    @property
    def name(self):
        """Gets the name of this AssetTypeResource.
        The type's name.

        :return: The name of this AssetTypeResource.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        """Sets the name of this AssetTypeResource.
        The type's name.

        :param name: The name of this AssetTypeResource.
        :type: str
        """
        if name is None:
            raise MindsphereClientError("Invalid value for `name`, must not be `None`")
        if name is not None and len(name) > 128:
            raise MindsphereClientError("Invalid value for `name`, length must be less than or equal to `128`")
        if name is not None and len(name) < 1:
            raise MindsphereClientError("Invalid value for `name`, length must be greater than or equal to `1`")
        if name is not None and not re.search(r'[\\p{L}_0-9_\\. -]+', name):
            raise MindsphereClientError(r"Invalid value for `name`, must be a follow pattern or equal to `/[\\p{L}_0-9_\\. -]+/`")

        self._name = name

    @property
    def description(self):
        """Gets the description of this AssetTypeResource.
        description

        :return: The description of this AssetTypeResource.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        """Sets the description of this AssetTypeResource.
        description

        :param description: The description of this AssetTypeResource.
        :type: str
        """
        if description is not None and len(description) > 255:
            raise MindsphereClientError("Invalid value for `description`, length must be less than or equal to `255`")

        self._description = description

    @property
    def parent_type_id(self):
        """Gets the parent_type_id of this AssetTypeResource.

        :return: The parent_type_id of this AssetTypeResource.
        :rtype: AssetTypeId
        """
        return self._parent_type_id

    @parent_type_id.setter
    def parent_type_id(self, parent_type_id):
        """Sets the parent_type_id of this AssetTypeResource.

        :param parent_type_id: The parent_type_id of this AssetTypeResource.
        :type: AssetTypeId
        """

        self._parent_type_id = parent_type_id

    @property
    def instantiable(self):
        """Gets the instantiable of this AssetTypeResource.
        If instances can be created from this type. A non-instantiable type could be changed to be instantiable but not the other way around.

        :return: The instantiable of this AssetTypeResource.
        :rtype: bool
        """
        return self._instantiable

    @instantiable.setter
    def instantiable(self, instantiable):
        """Sets the instantiable of this AssetTypeResource.
        If instances can be created from this type. A non-instantiable type could be changed to be instantiable but not the other way around.

        :param instantiable: The instantiable of this AssetTypeResource.
        :type: bool
        """

        self._instantiable = instantiable

    @property
    def scope(self):
        """Gets the scope of this AssetTypeResource.
        Visibility of the assettype. Setting this property to public makes it available to other tenants. Private types are only visible to the user's own tenant. Currently only private types could be created.

        :return: The scope of this AssetTypeResource.
        :rtype: str
        """
        return self._scope

    @scope.setter
    def scope(self, scope):
        """Sets the scope of this AssetTypeResource.
        Visibility of the assettype. Setting this property to public makes it available to other tenants. Private types are only visible to the user's own tenant. Currently only private types could be created.

        :param scope: The scope of this AssetTypeResource.
        :type: str
        """
        allowed_values = ["public", "private"]
        if scope.lower() not in [x.lower() for x in allowed_values]:
            raise MindsphereClientError(
                "Invalid value for `scope` ({0}), must be one of {1}"
                .format(scope, allowed_values)
            )

        self._scope = scope

    @property
    def id(self):
        """Gets the id of this AssetTypeResource.

        :return: The id of this AssetTypeResource.
        :rtype: AssetTypeId
        """
        return self._id

    @id.setter
    def id(self, id):
        """Sets the id of this AssetTypeResource.

        :param id: The id of this AssetTypeResource.
        :type: AssetTypeId
        """

        self._id = id

    @property
    def tenant_id(self):
        """Gets the tenant_id of this AssetTypeResource.

        :return: The tenant_id of this AssetTypeResource.
        :rtype: TenantId
        """
        return self._tenant_id

    @tenant_id.setter
    def tenant_id(self, tenant_id):
        """Sets the tenant_id of this AssetTypeResource.

        :param tenant_id: The tenant_id of this AssetTypeResource.
        :type: TenantId
        """

        self._tenant_id = tenant_id

    @property
    def etag(self):
        """Gets the etag of this AssetTypeResource.

        :return: The etag of this AssetTypeResource.
        :rtype: ETag
        """
        return self._etag

    @etag.setter
    def etag(self, etag):
        """Sets the etag of this AssetTypeResource.

        :param etag: The etag of this AssetTypeResource.
        :type: ETag
        """

        self._etag = etag

    @property
    def aspects(self):
        """Gets the aspects of this AssetTypeResource.

        :return: The aspects of this AssetTypeResource.
        :rtype: list[AssetTypeResourceAspects]
        """
        return self._aspects

    @aspects.setter
    def aspects(self, aspects):
        """Sets the aspects of this AssetTypeResource.

        :param aspects: The aspects of this AssetTypeResource.
        :type: list[AssetTypeResourceAspects]
        """

        self._aspects = aspects

    @property
    def variables(self):
        """Gets the variables of this AssetTypeResource.
        Direct variables of the asset-type. Variable names has to be unique inside the whole type-family (ancestors and descendants). Once added variables cannot be changed or removed.

        :return: The variables of this AssetTypeResource.
        :rtype: list[VariableDefinitionResource]
        """
        return self._variables

    @variables.setter
    def variables(self, variables):
        """Sets the variables of this AssetTypeResource.
        Direct variables of the asset-type. Variable names has to be unique inside the whole type-family (ancestors and descendants). Once added variables cannot be changed or removed.

        :param variables: The variables of this AssetTypeResource.
        :type: list[VariableDefinitionResource]
        """

        self._variables = variables

    @property
    def file_assignments(self):
        """Gets the file_assignments of this AssetTypeResource.

        :return: The file_assignments of this AssetTypeResource.
        :rtype: list[FileAssignmentResource]
        """
        return self._file_assignments

    @file_assignments.setter
    def file_assignments(self, file_assignments):
        """Sets the file_assignments of this AssetTypeResource.

        :param file_assignments: The file_assignments of this AssetTypeResource.
        :type: list[FileAssignmentResource]
        """

        self._file_assignments = file_assignments

    @property
    def links(self):
        """Gets the links of this AssetTypeResource.

        :return: The links of this AssetTypeResource.
        :rtype: AssetTypeLinks
        """
        return self._links

    @links.setter
    def links(self, links):
        """Sets the links of this AssetTypeResource.

        :param links: The links of this AssetTypeResource.
        :type: AssetTypeLinks
        """

        self._links = links

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(AssetTypeResource, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AssetTypeResource):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
