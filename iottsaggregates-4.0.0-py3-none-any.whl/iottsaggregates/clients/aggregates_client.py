# coding: utf-8

"""
    IoT TS Aggregates API

     The aggregate service enables querying aggregated time series data for performance assets based on pre-calculated aggregate values.  Precalculated aggregates are available in the following aggregate intervals * 2 minute * 1 hour * 1 day  ## Generic Errors The following generic error codes (with status codes) can occur at the operations of this API. Generic error codes are prefixed with 'mdsp.core.generic.'.  - unauthorized (401) - forbidden (403) - tooManyRequests (429) - internalServerError (500)   # noqa: E501
"""


from __future__ import absolute_import

from mindsphere_core.mindsphere_core import logger
from mindsphere_core import mindsphere_core, exceptions, token_service
from mindsphere_core.token_service import init_credentials


class AggregatesClient:
    __base_path__ = "/api/iottsaggregates/v4"
    __model_package__ = __name__.split(".")[0]

    def __init__(self, rest_client_config=None, mindsphere_credentials=None):
        self.rest_client_config = rest_client_config
        self.mindsphere_credentials = init_credentials(mindsphere_credentials)

    def retrieve_aggregates(self, request_object):
        """Get aggregated time series data for one aspect of an asset.

        Returns a list of aggregates for a given asset and aspect. The time range of the aggregates can be defined by a combination of parameters; such as from, to, intervalUnit, intervalValue and count. Time range can be specified anywhere in past or future for which timeseries data is present. In the case no time series data was available for an aggregation interval, no aggregate will be returned. Pre-computed aggregates are aligned with the tenant's time zone.   **Limitations** - The maximum time range for querying DAY/WEEK/MONTH aggregates is 90 days. - The maximum time range for querying HOUR aggregates is 7 days. - The maximum time range for querying 2 MINUTE aggregates is 24 hours.  **Parameter Auto-Completion** The parameters *from*, *to*, *intervalUnit*, *intervalValue*, and *count* are used to determine the time range and interval length to return aggregates for. Intelligent auto-completion is applied to allow clients to only provide a subset of the parameters, according to the following rules: 1. In case none of the parameters is provided, *intervalUnit* is set to DAY, *intervalValue* is set to 1, *to* is set to the current time, and *from* is set to the current time minus 7 days. 1. If only *from* is provided, *to* is set such that a 90 day time range results or, in case a larger range would result, to the current time. *from* is truncated to date-only for this calculation. 1. If only *to* is provided, *from* is set such that a 90 day time range results. 1. If *intervalUnit*, *intervalValue* and *count* are provided, it suffices to either provide *to* or *from* in addition. The missing parameter is determined based on the time range computed from *intervalUnit*, *intervlValue* and *count*. 1. If *intervalUnit* and *intervalValue* are not provided, the largest available interval length fitting into the used time range is chosen. 1. If *count* is not provided, but the other parameters are, *count* will be derived based on the time range divided by the *intervalUnit* and *intervalValue*. 1. In case parameters *from* or *to* are provided but do not coincide with the pre-calculated interval boundaries of the used interval, *from* and *to* are shifted such that the overall time range contains the provided one and time range boundaries coincide with interval boundaries. 1. If *from*, *to* and *count* are provided, *intervalUnit*, *intervalValue* is determined based on the time range divided by count.    **Examples**  *Example 1: use of intervalUnit, intervalValue and count to derive end of time range.*      A request with open time range is made            from = 2019-02-01Z       intervalUnit = day       intervalValue = 1       count = 7            Rule 4 is applied to determine the 'to' parameter        to = 2019-02-08Z       *Example 2: time range auto-extension and count derivation.*       A request with missing 'to' and 'count' parameters is made, and current system time is 2019-02-01T20:00:00Z        from = 2019-02-01T10:00:00Z       intervalUnit = hour       intervalValue = 1           The 'to' time is derived based on Rule 2 to be the current time and 'count' is determined applying Rule 6        to = 2019-02-01T20:00:00Z       count = 10           *Example 3: intervalUnit and intervalValue auto-completion.*      A request without 'intervalUnit', 'intervalValue' and 'count' is made          from = 2020-10-10T10:00:00Z       to = 2020-10-10T10:30:00Z           Rule 5 is applied to determine the interval length based on the time range only. The count is derived based on rule 6 in the following.        intervalUnit = minute       intervalValue = 2       count = 15       *Example 4: intervalUnit and intervalValue auto-completion with larger interval*      Similar as Example 3, a request without 'intervalUnit', 'intervalValue' and 'count' is made            from = 2020-10-10T10:00:00Z       to = 2020-10-10T12:00:00Z             Rules 5 and 6 are applied, but since the time range is multiple hours long, the interval is determined to be HOUR            intervalUnit = hour       intervalValue = 1       count = 2        *Example 5: intervalUnit and intervalValue auto-completion with much larger interval*      Similar as Example 3 and 4, a request without 'intervalUnit', 'intervalValue' and 'count' is made            from = 2020-10-10T00:00:00Z      to = 2020-10-15T00:00:00Z             Rules 5 and 6 are applied, but since the time range is multiple days long, the interval is determined to be DAY            intervalUnit = day       intervalValue = 1       count = 5        *Example 6: intervalUnit and intervalValue auto-completion when count is also provided.*      A request without 'intervalUnit' and 'intervalValue' is made          from = 2020-10-10T10:00:00Z       to = 2020-10-10T10:30:00Z       count = 3           Since the difference between from and to date is 30 minute, and count asked is 3. Rule 8 is applied and 3 aggregate buckets of 10 minute is returned        intervalUnit = minute       intervalValue = 10  *Example 7: to and from date adjusted to pre-computed aggregate boundary*      Following request is made           from = 2020-10-10T02:10:00Z      to = 2020-10-10T09:10:00Z      intervalUnit = hour      intervalValue = 1             Rule 7 is applied since aggregate is queried for 1 hour and dates are not aligned to Hour boundary, *from* and *to* dates are adjusted to Hour boundary          from = 2020-10-10T02:00:00Z     to = 2020-10-10T10:00:00Z        *Example 8: to, from, intervalUnit and intervalValue asking for 4 hour aggregate*      Following request is made           from = 2020-10-10T00:00:00Z      to = 2020-10-11T00:00:00Z      intervalUnit = hour      intervalValue = 4             Since pre-computed aggregate exists for every HOUR, Hourly aggregates will be combined and a response bucket every 4 hours will be returned

        :param RetrieveAggregatesRequest request_object: It contains the below parameters --> |br| ( assetId* - Unique identifier of the asset. ), |br| ( aspectName* - Name of the aspect. ), |br| ( from - Beginning of the time range to read. ISO date format is supported with timezone. If no timezone is provided then it is considered as UTC aligned date-time. Example date time values are <table> <tr> <td>Date-time with no timezone provided</td> <td> 2020-02-20Z<br/> 2020-02-20T10Z<br/> 2020-02-20T10:30Z<br/> 2020-02-20T10:30:00Z<br/> 2020-02-20T10:30:00.000Z </td> </tr> <tr> <td>Date-time with timezone provided</td> <td> 2020-02-20-05:00<br/> 2020-02-20T10-05:00<br/> 2020-02-20T10:30-05:00<br/> 2020-02-20T10:30:00-05:00<br/> 2020-02-20T10:30:00.000-05:00 </td> </tr> </table> ), |br| ( to - End of the time range to read. ISO date format is supported with timezone. If no timezone is provided then it is considered as UTC aligned date-time. Example date time values are <table> <tr> <td>Date-time with no timezone provided</td> <td> 2020-02-20Z<br/> 2020-02-20T10Z<br/> 2020-02-20T10:30Z<br/> 2020-02-20T10:30:00Z<br/> 2020-02-20T10:30:00.000Z </td> </tr> <tr> <td>Date-time with timezone provided</td> <td> 2020-02-20-05:00<br/> 2020-02-20T10-05:00<br/> 2020-02-20T10:30-05:00<br/> 2020-02-20T10:30:00-05:00<br/> 2020-02-20T10:30:00.000-05:00 </td> </tr> </table> ), |br| ( intervalValue - Interval duration for the aggregates in intervalUnits. Supported values depends upon intervalUnit <br/> <table> <tr><td><b>intervalUnit</b></td><td><b>Supported intervalValue</b></td></tr> <tr><td>minute</td><td>2,4,6,8...58,60 (multiple of 2)</td></tr> <tr><td>hour</td><td>1,2,3,4,...23,24</td></tr> <tr><td>day</td><td>1,2,3,4,...89,90</td></tr> <tr><td>week</td><td>1,2,3,4,...11,12</td></tr> <tr><td>month</td><td>1,2,3</td></tr> </table> ), |br| ( intervalUnit - Interval duration unit for the aggregates. Supported values are <ul> <li>minute</li> <li>hour</li> <li>day</li> <li>week</li> <li>month</li> </ul> ), |br| ( select - If this parameter is not provided all variables of aspect are returned in response. User can provide comma separated variables names in order to filter out variables. Variable names followed by '.' and aggregate field will return specific fields of aggregate object.<br/> Example 1- select=variable1,variable2 If above parameter provided in request, agregate response will only contain variable1 and variable2. <br/> Example 2- select=variable1.sum,variable2.sum If above parameter provided in request, agregate response will only contain variable1 and variable2 with only sum in aggregate response object. ), |br| ( count - This parameter is used to get number of aggregate objects in response. )

        :return: AggregatesV4
        """
        logger.info("AggregatesClient.retrieve_aggregates() invoked.")
        if request_object is None:
            raise exceptions.MindsphereClientError(
                "`request_object` is not passed when calling `retrieve_aggregates`"
            )

        if request_object.asset_id is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `assetId` is missing from `request_object`, when calling `retrieve_aggregates`"
            )

        if request_object.aspect_name is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `aspectName` is missing from `request_object`, when calling `retrieve_aggregates`"
            )

        end_point_url = "/aggregates"
        end_point_url = end_point_url.format()
        token = token_service.fetch_token(
            self.rest_client_config, self.mindsphere_credentials
        )
        api_url = mindsphere_core.build_url(
            self.__base_path__, end_point_url, self.rest_client_config
        )
        headers = {
            "Accept": "application/json",
            "Authorization": "Bearer " + str(token),
        }
        query_params = {
            "assetId": request_object.asset_id,
            "aspectName": request_object.aspect_name,
            "from": request_object._from,
            "to": request_object.to,
            "intervalValue": request_object.interval_value,
            "intervalUnit": request_object.interval_unit,
            "select": request_object.select,
            "count": request_object.count,
        }
        form_params, local_var_files, body_params = {}, {}, None

        logger.info(
            "AggregatesClient.retrieve_aggregates()  --> Proceeding for API Invoker."
        )
        return mindsphere_core.invoke_service(
            self.rest_client_config,
            api_url,
            headers,
            "GET",
            query_params,
            form_params,
            body_params,
            local_var_files,
            "AggregatesV4",
            self.__model_package__,
        )
