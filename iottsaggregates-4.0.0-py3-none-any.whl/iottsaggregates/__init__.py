# coding: utf-8

# flake8: noqa

"""
    IoT TS Aggregates API

     The aggregate service enables querying aggregated time series data for performance assets based on pre-calculated aggregate values.  Precalculated aggregates are available in the following aggregate intervals * 2 minute * 1 hour * 1 day  ## Generic Errors The following generic error codes (with status codes) can occur at the operations of this API. Generic error codes are prefixed with 'mdsp.core.generic.'.  - unauthorized (401) - forbidden (403) - tooManyRequests (429) - internalServerError (500)   # noqa: E501
"""


from __future__ import absolute_import

# import apis into sdk package
from iottsaggregates.clients.aggregates_client import AggregatesClient


# import models into model package
from iottsaggregates.models.aggregatesv4 import AggregatesV4
from iottsaggregates.models.aggregatesResponse import AggregatesResponse
from iottsaggregates.models.errors import Errors
from iottsaggregates.models.errors_errors import ErrorsErrors
from iottsaggregates.models.errors_message_parameters import ErrorsMessageParameters
from iottsaggregates.models.retrieve_aggregates_request import RetrieveAggregatesRequest
from iottsaggregates.models.variable import Variable
