# coding: utf-8

"""
    IoT TS Aggregates API

     The aggregate service enables querying aggregated time series data for performance assets based on pre-calculated aggregate values.  Precalculated aggregates are available in the following aggregate intervals * 2 minute * 1 hour * 1 day  ## Generic Errors The following generic error codes (with status codes) can occur at the operations of this API. Generic error codes are prefixed with 'mdsp.core.generic.'.  - unauthorized (401) - forbidden (403) - tooManyRequests (429) - internalServerError (500)   # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class RetrieveAggregatesRequest(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """

    attribute_types = {
        "aspect_name": "str",
        "select": "str",
        "asset_id": "str",
        "interval_unit": "str",
        "count": "str",
        "_from": "str",
        "to": "str",
        "interval_value": "float",
    }

    attribute_map = {
        "aspect_name": "aspectName",
        "select": "select",
        "asset_id": "assetId",
        "interval_unit": "intervalUnit",
        "count": "count",
        "_from": "from",
        "to": "to",
        "interval_value": "intervalValue",
    }

    def __init__(
        self,
        aspect_name=None,
        select=None,
        asset_id=None,
        interval_unit=None,
        count=None,
        _from=None,
        to=None,
        interval_value=None,
    ):
        self._aspect_name = aspect_name
        self._select = select
        self._asset_id = asset_id
        self._interval_unit = interval_unit
        self._count = count
        self.__from = _from
        self._to = to
        self._interval_value = interval_value
        self.discriminator = None

    @property
    def aspect_name(self):
        """Gets the aspect_name of this RetrieveAggregatesRequest.

        :return: The aspect_name of this RetrieveAggregatesRequest.
        :rtype: str
        """
        return self._aspect_name

    @aspect_name.setter
    def aspect_name(self, aspect_name):
        """Sets the aspect_name of this RetrieveAggregatesRequest.

        :param aspect_name: The aspect_name of this RetrieveAggregatesRequest.
        :type: str
        """

        self._aspect_name = aspect_name

    @property
    def select(self):
        """Gets the select of this RetrieveAggregatesRequest.

        :return: The select of this RetrieveAggregatesRequest.
        :rtype: str
        """
        return self._select

    @select.setter
    def select(self, select):
        """Sets the select of this RetrieveAggregatesRequest.

        :param select: The select of this RetrieveAggregatesRequest.
        :type: str
        """

        self._select = select

    @property
    def asset_id(self):
        """Gets the asset_id of this RetrieveAggregatesRequest.

        :return: The asset_id of this RetrieveAggregatesRequest.
        :rtype: str
        """
        return self._asset_id

    @asset_id.setter
    def asset_id(self, asset_id):
        """Sets the asset_id of this RetrieveAggregatesRequest.

        :param asset_id: The asset_id of this RetrieveAggregatesRequest.
        :type: str
        """

        self._asset_id = asset_id

    @property
    def interval_unit(self):
        """Gets the interval_unit of this RetrieveAggregatesRequest.

        :return: The interval_unit of this RetrieveAggregatesRequest.
        :rtype: str
        """
        return self._interval_unit

    @interval_unit.setter
    def interval_unit(self, interval_unit):
        """Sets the interval_unit of this RetrieveAggregatesRequest.

        :param interval_unit: The interval_unit of this RetrieveAggregatesRequest.
        :type: str
        """

        self._interval_unit = interval_unit

    @property
    def count(self):
        """Gets the count of this RetrieveAggregatesRequest.

        :return: The count of this RetrieveAggregatesRequest.
        :rtype: str
        """
        return self._count

    @count.setter
    def count(self, count):
        """Sets the count of this RetrieveAggregatesRequest.

        :param count: The count of this RetrieveAggregatesRequest.
        :type: str
        """

        self._count = count

    @property
    def _from(self):
        """Gets the _from of this RetrieveAggregatesRequest.

        :return: The _from of this RetrieveAggregatesRequest.
        :rtype: str
        """
        return self.__from

    @_from.setter
    def _from(self, _from):
        """Sets the _from of this RetrieveAggregatesRequest.

        :param _from: The _from of this RetrieveAggregatesRequest.
        :type: str
        """

        self.__from = _from

    @property
    def to(self):
        """Gets the to of this RetrieveAggregatesRequest.

        :return: The to of this RetrieveAggregatesRequest.
        :rtype: str
        """
        return self._to

    @to.setter
    def to(self, to):
        """Sets the to of this RetrieveAggregatesRequest.

        :param to: The to of this RetrieveAggregatesRequest.
        :type: str
        """

        self._to = to

    @property
    def interval_value(self):
        """Gets the interval_value of this RetrieveAggregatesRequest.

        :return: The interval_value of this RetrieveAggregatesRequest.
        :rtype: float
        """
        return self._interval_value

    @interval_value.setter
    def interval_value(self, interval_value):
        """Sets the interval_value of this RetrieveAggregatesRequest.

        :param interval_value: The interval_value of this RetrieveAggregatesRequest.
        :type: float
        """

        self._interval_value = interval_value

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(
                    map(lambda x: x.to_dict() if hasattr(x, "to_dict") else x, value)
                )
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(
                    map(
                        lambda item: (item[0], item[1].to_dict())
                        if hasattr(item[1], "to_dict")
                        else item,
                        value.items(),
                    )
                )
            else:
                result[attr] = value
        if issubclass(RetrieveAggregatesRequest, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, RetrieveAggregatesRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
