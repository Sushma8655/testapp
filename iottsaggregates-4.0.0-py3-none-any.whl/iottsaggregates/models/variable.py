# coding: utf-8

"""
    IoT TS Aggregates API

     The aggregate service enables querying aggregated time series data for performance assets based on pre-calculated aggregate values.  Precalculated aggregates are available in the following aggregate intervals * 2 minute * 1 hour * 1 day  ## Generic Errors The following generic error codes (with status codes) can occur at the operations of this API. Generic error codes are prefixed with 'mdsp.core.generic.'.  - unauthorized (401) - forbidden (403) - tooManyRequests (429) - internalServerError (500)   # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class Variable(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """

    attribute_types = {
        "countgood": "int",
        "countuncertain": "int",
        "countbad": "int",
        "sum": "float",
        "average": "float",
        "mintime": "datetime",
        "minvalue": "float",
        "maxtime": "datetime",
        "maxvalue": "float",
        "firsttime": "datetime",
        "firstvalue": "float",
        "lasttime": "datetime",
        "lastvalue": "float",
        "sd": "float",
    }

    attribute_map = {
        "countgood": "countgood",
        "countuncertain": "countuncertain",
        "countbad": "countbad",
        "sum": "sum",
        "average": "average",
        "mintime": "mintime",
        "minvalue": "minvalue",
        "maxtime": "maxtime",
        "maxvalue": "maxvalue",
        "firsttime": "firsttime",
        "firstvalue": "firstvalue",
        "lasttime": "lasttime",
        "lastvalue": "lastvalue",
        "sd": "sd",
    }

    def __init__(
        self,
        countgood=None,
        countuncertain=None,
        countbad=None,
        sum=None,
        average=None,
        mintime=None,
        minvalue=None,
        maxtime=None,
        maxvalue=None,
        firsttime=None,
        firstvalue=None,
        lasttime=None,
        lastvalue=None,
        sd=None,
    ):
        self._countgood = countgood
        self._countuncertain = countuncertain
        self._countbad = countbad
        self._sum = sum
        self._average = average
        self._mintime = mintime
        self._minvalue = minvalue
        self._maxtime = maxtime
        self._maxvalue = maxvalue
        self._firsttime = firsttime
        self._firstvalue = firstvalue
        self._lasttime = lasttime
        self._lastvalue = lastvalue
        self._sd = sd
        self.discriminator = None

    @property
    def countgood(self):
        """Gets the countgood of this Variable.
        Number of good records in the aggregated interval.

        :return: The countgood of this Variable.
        :rtype: int
        """
        return self._countgood

    @countgood.setter
    def countgood(self, countgood):
        """Sets the countgood of this Variable.
        Number of good records in the aggregated interval.

        :param countgood: The countgood of this Variable.
        :type: int
        """

        self._countgood = countgood

    @property
    def countuncertain(self):
        """Gets the countuncertain of this Variable.
        Number of uncertain records in the aggregated interval.

        :return: The countuncertain of this Variable.
        :rtype: int
        """
        return self._countuncertain

    @countuncertain.setter
    def countuncertain(self, countuncertain):
        """Sets the countuncertain of this Variable.
        Number of uncertain records in the aggregated interval.

        :param countuncertain: The countuncertain of this Variable.
        :type: int
        """

        self._countuncertain = countuncertain

    @property
    def countbad(self):
        """Gets the countbad of this Variable.
        Number of bad records in the aggregated interval.

        :return: The countbad of this Variable.
        :rtype: int
        """
        return self._countbad

    @countbad.setter
    def countbad(self, countbad):
        """Sets the countbad of this Variable.
        Number of bad records in the aggregated interval.

        :param countbad: The countbad of this Variable.
        :type: int
        """

        self._countbad = countbad

    @property
    def sum(self):
        """Gets the sum of this Variable.
        Sum of the values within the interval.

        :return: The sum of this Variable.
        :rtype: float
        """
        return self._sum

    @sum.setter
    def sum(self, sum):
        """Sets the sum of this Variable.
        Sum of the values within the interval.

        :param sum: The sum of this Variable.
        :type: float
        """

        self._sum = sum

    @property
    def average(self):
        """Gets the average of this Variable.
        Average of the values within the interval.

        :return: The average of this Variable.
        :rtype: float
        """
        return self._average

    @average.setter
    def average(self, average):
        """Sets the average of this Variable.
        Average of the values within the interval.

        :param average: The average of this Variable.
        :type: float
        """

        self._average = average

    @property
    def mintime(self):
        """Gets the mintime of this Variable.
        Timestamp of the minimum value within the interval.

        :return: The mintime of this Variable.
        :rtype: datetime
        """
        return self._mintime

    @mintime.setter
    def mintime(self, mintime):
        """Sets the mintime of this Variable.
        Timestamp of the minimum value within the interval.

        :param mintime: The mintime of this Variable.
        :type: datetime
        """

        self._mintime = mintime

    @property
    def minvalue(self):
        """Gets the minvalue of this Variable.
        Minimum value within the interval.

        :return: The minvalue of this Variable.
        :rtype: float
        """
        return self._minvalue

    @minvalue.setter
    def minvalue(self, minvalue):
        """Sets the minvalue of this Variable.
        Minimum value within the interval.

        :param minvalue: The minvalue of this Variable.
        :type: float
        """

        self._minvalue = minvalue

    @property
    def maxtime(self):
        """Gets the maxtime of this Variable.
        Timestamp of the maximum value within the interval.

        :return: The maxtime of this Variable.
        :rtype: datetime
        """
        return self._maxtime

    @maxtime.setter
    def maxtime(self, maxtime):
        """Sets the maxtime of this Variable.
        Timestamp of the maximum value within the interval.

        :param maxtime: The maxtime of this Variable.
        :type: datetime
        """

        self._maxtime = maxtime

    @property
    def maxvalue(self):
        """Gets the maxvalue of this Variable.
        Maximum value within the interval.

        :return: The maxvalue of this Variable.
        :rtype: float
        """
        return self._maxvalue

    @maxvalue.setter
    def maxvalue(self, maxvalue):
        """Sets the maxvalue of this Variable.
        Maximum value within the interval.

        :param maxvalue: The maxvalue of this Variable.
        :type: float
        """

        self._maxvalue = maxvalue

    @property
    def firsttime(self):
        """Gets the firsttime of this Variable.
        Timestamp of the first value within the interval.

        :return: The firsttime of this Variable.
        :rtype: datetime
        """
        return self._firsttime

    @firsttime.setter
    def firsttime(self, firsttime):
        """Sets the firsttime of this Variable.
        Timestamp of the first value within the interval.

        :param firsttime: The firsttime of this Variable.
        :type: datetime
        """

        self._firsttime = firsttime

    @property
    def firstvalue(self):
        """Gets the firstvalue of this Variable.
        First value within the interval.

        :return: The firstvalue of this Variable.
        :rtype: float
        """
        return self._firstvalue

    @firstvalue.setter
    def firstvalue(self, firstvalue):
        """Sets the firstvalue of this Variable.
        First value within the interval.

        :param firstvalue: The firstvalue of this Variable.
        :type: float
        """

        self._firstvalue = firstvalue

    @property
    def lasttime(self):
        """Gets the lasttime of this Variable.
        Timestamp of the last measurement within the interval.

        :return: The lasttime of this Variable.
        :rtype: datetime
        """
        return self._lasttime

    @lasttime.setter
    def lasttime(self, lasttime):
        """Sets the lasttime of this Variable.
        Timestamp of the last measurement within the interval.

        :param lasttime: The lasttime of this Variable.
        :type: datetime
        """

        self._lasttime = lasttime

    @property
    def lastvalue(self):
        """Gets the lastvalue of this Variable.
        Last value within the interval.

        :return: The lastvalue of this Variable.
        :rtype: float
        """
        return self._lastvalue

    @lastvalue.setter
    def lastvalue(self, lastvalue):
        """Sets the lastvalue of this Variable.
        Last value within the interval.

        :param lastvalue: The lastvalue of this Variable.
        :type: float
        """

        self._lastvalue = lastvalue

    @property
    def sd(self):
        """Gets the sd of this Variable.
        Standard deviation of the values within the interval. It will return null, if number goes beyond Double range during calculation of Standard Deviation.

        :return: The sd of this Variable.
        :rtype: float
        """
        return self._sd

    @sd.setter
    def sd(self, sd):
        """Sets the sd of this Variable.
        Standard deviation of the values within the interval. It will return null, if number goes beyond Double range during calculation of Standard Deviation.

        :param sd: The sd of this Variable.
        :type: float
        """

        self._sd = sd

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(
                    map(lambda x: x.to_dict() if hasattr(x, "to_dict") else x, value)
                )
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(
                    map(
                        lambda item: (item[0], item[1].to_dict())
                        if hasattr(item[1], "to_dict")
                        else item,
                        value.items(),
                    )
                )
            else:
                result[attr] = value
        if issubclass(Variable, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, Variable):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
