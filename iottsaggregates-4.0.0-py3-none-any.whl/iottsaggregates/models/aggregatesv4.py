# coding: utf-8

"""
    IoT TS Aggregates API

     The aggregate service enables querying aggregated time series data for performance assets based on pre-calculated aggregate values.  Precalculated aggregates are available in the following aggregate intervals * 2 minute * 1 hour * 1 day  ## Generic Errors The following generic error codes (with status codes) can occur at the operations of this API. Generic error codes are prefixed with 'mdsp.core.generic.'.  - unauthorized (401) - forbidden (403) - tooManyRequests (429) - internalServerError (500)   # noqa: E501
"""


import pprint
import re
import six

from iottsaggregates.models.aggregatesResponse import AggregatesResponse
from mindsphere_core.exceptions import MindsphereClientError


class AggregatesV4(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """

    attribute_types = {"aggregates": "list[AggregatesResponse]"}

    attribute_map = {"aggregates": "aggregates"}

    def __init__(self, aggregates=None):
        self._aggregates = aggregates
        self.discriminator = None

    @property
    def aggregates(self):
        """Gets the aggregates of this Aggregates.

        :return: The aggregates of this Aggregates.
        :rtype: list[AggregatesResponse]
        """
        return self._aggregates

    @aggregates.setter
    def aggregates(self, aggregates):
        """Sets the aggregates of this Aggregates.

        :param aggregates: The aggregates of this Aggregates.
        :type: list[AggregatesResponse]
        """

        self._aggregates = aggregates

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(
                    map(lambda x: x.to_dict() if hasattr(x, "to_dict") else x, value)
                )
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(
                    map(
                        lambda item: (item[0], item[1].to_dict())
                        if hasattr(item[1], "to_dict")
                        else item,
                        value.items(),
                    )
                )
            else:
                result[attr] = value
        if issubclass(AggregatesV4, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, AggregatesV4):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
