# coding: utf-8

"""
    IoT TS Aggregates API

     The aggregate service enables querying aggregated time series data for performance assets based on pre-calculated aggregate values.  Precalculated aggregates are available in the following aggregate intervals * 2 minute * 1 hour * 1 day  ## Generic Errors The following generic error codes (with status codes) can occur at the operations of this API. Generic error codes are prefixed with 'mdsp.core.generic.'.  - unauthorized (401) - forbidden (403) - tooManyRequests (429) - internalServerError (500)   # noqa: E501
"""


from __future__ import absolute_import

import unittest
from unittest.mock import MagicMock
from iottsaggregates.clients import AggregatesClient
from iottsaggregates.models import *
from tests.unit.test_util import TestUtil, MOCK_VALUE, MOCK_SUCCESS
from mindsphere_core.exceptions import MindsphereError
from mindsphere_core import TenantCredentials, mindsphere_core, token_service


class AggregatesClientUnitTest(unittest.TestCase):
    """AggregatesClient unit test stubs"""

    def setUp(self):
        credentials = TenantCredentials(client_id=MOCK_VALUE, client_secret=MOCK_VALUE, tenant=MOCK_VALUE)
        config = mindsphere_core.RestClientConfig(MOCK_VALUE, MOCK_VALUE)
        self.client = AggregatesClient(config, credentials)
        token_service._invoke_token_endpoint = MagicMock(return_value=MOCK_SUCCESS)

    def test_retrieve_aggregates(self):
        """Test case for retrieve_aggregates
        Get aggregated time series data for one aspect of an asset.
        """
        package_name = "iottsaggregates.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = RetrieveAggregatesRequest()
        request_object.asset_id = TestUtil.get_mock_data(package_name, "str")
        request_object.aspect_name = TestUtil.get_mock_data(package_name, "str")
        response = self.client.retrieve_aggregates(request_object)
        self.assertEqual(200, response)

    def test_negative_retrieve_aggregates(self):
        """Negative test case for retrieve_aggregates
        Get aggregated time series data for one aspect of an asset.
        """
        request_object = RetrieveAggregatesRequest()
        with self.assertRaises(MindsphereError):
            self.client.retrieve_aggregates(request_object)

    def test_negative_request_retrieve_aggregates(self):
        """Negative test case for retrieve_aggregates
        Get aggregated time series data for one aspect of an asset.
        """
        with self.assertRaises(MindsphereError):
            self.client.retrieve_aggregates(None)


if __name__ == '__main__':
    unittest.main()
