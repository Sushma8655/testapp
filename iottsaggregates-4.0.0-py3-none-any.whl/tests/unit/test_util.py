from unittest.mock import MagicMock
from pydoc import locate

MOCK_VALUE = 'mock'
MOCK_SUCCESS = 'success'


class TestUtil:
    @staticmethod
    def get_mock_data(package_name, return_type):
        if return_type is 'str':
            return_value = 'Mock'
        elif return_type is 'int' or return_type is 'float':
            return_value = 0
        elif return_type is 'bool':
            return_value = False
        else:
            module = locate(package_name+".."+return_type)
            return_value = MagicMock(module)
        return return_value
