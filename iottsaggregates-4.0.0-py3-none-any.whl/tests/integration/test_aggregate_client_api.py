import json
import unittest
import random
from mindsphere_core import mindsphere_core

from mindsphere_core.exceptions import MindsphereError

from iottsaggregates import AggregatesClient, RetrieveAggregatesRequest


class TestAspectTypeApi(unittest.TestCase):
    def setUp(self):
        config = mindsphere_core.RestClientConfig()
        self.client = AggregatesClient(rest_client_config=config)

    def test_getAggregateTimeseriesMandatoryparams(self):
        retrieveAggregatesRequest = RetrieveAggregatesRequest()
        retrieveAggregatesRequest.asset_id = "5908ae5c5e4f4e18b0be58cd21ee675f"
        retrieveAggregatesRequest.aspect_name = "test_2020_11_11"

        response = self.client.retrieve_aggregates(retrieveAggregatesRequest)
        print(response)


    def test_getAggregateTimeserieswithfromandto(self):
        retrieveAggregatesRequest = RetrieveAggregatesRequest()
        retrieveAggregatesRequest.asset_id = "5908ae5c5e4f4e18b0be58cd21ee675f"
        retrieveAggregatesRequest.aspect_name = "test_2020_11_11"
        retrieveAggregatesRequest._from = "2020-11-06T09:00:00Z"
        retrieveAggregatesRequest.to = "2020-11-06T12:00:00Z"

        response = self.client.retrieve_aggregates(retrieveAggregatesRequest)
        print(response)



    def test_getAggregateTimeserieswithselect(self):
        retrieveAggregatesRequest = RetrieveAggregatesRequest()
        retrieveAggregatesRequest.asset_id = "5908ae5c5e4f4e18b0be58cd21ee675f"
        retrieveAggregatesRequest.aspect_name = "test_2020_11_11"
        retrieveAggregatesRequest._from = "2020-11-06T09:00:00Z"
        retrieveAggregatesRequest.to = "2020-11-06T12:00:00Z"
        retrieveAggregatesRequest.select = "test"

        response = self.client.retrieve_aggregates(retrieveAggregatesRequest)
        print(response)

    def test_getAggregateTimeserieswithintervalunit(self):
        retrieveAggregatesRequest = RetrieveAggregatesRequest()
        retrieveAggregatesRequest.asset_id = "5908ae5c5e4f4e18b0be58cd21ee675f"
        retrieveAggregatesRequest.aspect_name = "test_2020_11_11"
        retrieveAggregatesRequest._from = "2020-11-06T09:00:00Z"
        retrieveAggregatesRequest.to = "2020-11-06T12:00:00Z"
        retrieveAggregatesRequest.select = "test"
        retrieveAggregatesRequest.interval_unit= "minute"

        response = self.client.retrieve_aggregates(retrieveAggregatesRequest)
        print(response)

    def test_getAggregateTimeserieswithcount(self):
        retrieveAggregatesRequest = RetrieveAggregatesRequest()
        retrieveAggregatesRequest.asset_id = "5908ae5c5e4f4e18b0be58cd21ee675f"
        retrieveAggregatesRequest.aspect_name = "test_2020_11_11"
        retrieveAggregatesRequest._from = "2020-11-06T09:00:00Z"
        retrieveAggregatesRequest.to = "2020-11-06T12:00:00Z"
        retrieveAggregatesRequest.select = "test"
        retrieveAggregatesRequest.interval_unit = "minute"
        retrieveAggregatesRequest.count = 2

        response = self.client.retrieve_aggregates(retrieveAggregatesRequest)
        print(response)

    def test_getAggregateTimeserieswithoutasset(self):
        retrieveAggregatesRequest = RetrieveAggregatesRequest()
        retrieveAggregatesRequest.aspect_name = "test_2020_11_11"
        retrieveAggregatesRequest._from = "2020-11-06T09:00:00Z"
        retrieveAggregatesRequest.to = "2020-11-06T12:00:00Z"
        retrieveAggregatesRequest.select = "test"
        retrieveAggregatesRequest.interval_unit = "minute"
        retrieveAggregatesRequest.count = 2

        with self.assertRaises(MindsphereError):
            self.client.retrieve_aggregates(retrieveAggregatesRequest)


    def test_getAggregateTimeserieswithaspect(self):
        retrieveAggregatesRequest = RetrieveAggregatesRequest()
        retrieveAggregatesRequest.asset_id = "5908ae5c5e4f4e18b0be58cd21ee675f"
        retrieveAggregatesRequest._from = "2020-11-06T09:00:00Z"
        retrieveAggregatesRequest.to = "2020-11-06T12:00:00Z"
        retrieveAggregatesRequest.select = "test"
        retrieveAggregatesRequest.interval_unit = "minute"
        retrieveAggregatesRequest.count = 2

        with self.assertRaises(MindsphereError):
            self.client.retrieve_aggregates(retrieveAggregatesRequest)


if __name__ == "__main__":
    unittest.main()
