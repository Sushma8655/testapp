# coding: utf-8

"""
    IoT File API

    The IoT File API enables storing and retrieving files for entity instances.  # noqa: E501
"""


from __future__ import absolute_import

from mindsphere_core.mindsphere_core import logger
from mindsphere_core import mindsphere_core, exceptions, token_service
from mindsphere_core.token_service import init_credentials


class FileServiceClient:
    __base_path__ = '/api/iotfile/v3'
    __model_package__ = __name__.split('.')[0]

    def __init__(self, rest_client_config=None, mindsphere_credentials=None):
        self.rest_client_config = rest_client_config
        self.mindsphere_credentials = init_credentials(mindsphere_credentials)

    def delete_file(self, request_object):
        """delete a file

        Delete a file for the specified entity and path.

        :param DeleteFileRequest request_object: It contains the below parameters --> |br| ( entityId* - unique identifier of the entity ), |br| ( filepath* - unique identifier of the file )

        :return: None
        """
        logger.info('FileServiceClient.delete_file() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `delete_file`')

        if request_object.entity_id is None:
            raise exceptions.MindsphereClientError('The required parameter `entityId` is missing from `request_object`, when calling `delete_file`')

        if request_object.filepath is None:
            raise exceptions.MindsphereClientError('The required parameter `filepath` is missing from `request_object`, when calling `delete_file`')

        end_point_url = '/files/{entityId}/{filepath}'
        end_point_url = end_point_url.format(entityId=request_object.entity_id, filepath=request_object.filepath)
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Authorization': 'Bearer ' + str(token)}
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info('FileServiceClient.delete_file()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'DELETE', query_params, form_params, body_params, local_var_files, None, self.__model_package__)

    def get_file(self, request_object):
        """read a file

        Read a file for the specified entity and path

        :param GetIOTFileRequest request_object: It contains the below parameters --> |br| ( entityId* - Id to instance of entity ), |br| ( filepath* - path of the file along with filename ), |br| ( If-None-Match - ETag of the latest version (not supported in this release) ), |br| ( range - Part of a file to return in Bytes, eg bytes=200-600 )

        :return: str
        """
        logger.info('FileServiceClient.get_file() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `get_file`')

        if request_object.entity_id is None:
            raise exceptions.MindsphereClientError('The required parameter `entityId` is missing from `request_object`, when calling `get_file`')

        if request_object.filepath is None:
            raise exceptions.MindsphereClientError('The required parameter `filepath` is missing from `request_object`, when calling `get_file`')

        end_point_url = '/files/{entityId}/{filepath}'
        end_point_url = end_point_url.format(entityId=request_object.entity_id, filepath=request_object.filepath)
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/octet-stream, application/json', 'If-None-Match': request_object.if_none_match, 'range': request_object.range, 'Authorization': 'Bearer ' + str(token)}
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info('FileServiceClient.get_file()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'GET', query_params, form_params, body_params, local_var_files, 'str', self.__model_package__)

    def get_file_list(self, request_object):
        """list multi part uploads

        List multi part uploads

        :param GetFileListRequest request_object: It contains the below parameters --> |br| ( entityId* - Id to instance of entity ), |br| ( filepath* - path of the file )

        :return: list[Fileslist]
        """
        logger.info('FileServiceClient.get_file_list() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `get_file_list`')

        if request_object.entity_id is None:
            raise exceptions.MindsphereClientError('The required parameter `entityId` is missing from `request_object`, when calling `get_file_list`')

        if request_object.filepath is None:
            raise exceptions.MindsphereClientError('The required parameter `filepath` is missing from `request_object`, when calling `get_file_list`')

        end_point_url = '/fileslist/{entityId}/{filepath}'
        end_point_url = end_point_url.format(entityId=request_object.entity_id, filepath=request_object.filepath)
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/json', 'Authorization': 'Bearer ' + str(token)}
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info('FileServiceClient.get_file_list()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'GET', query_params, form_params, body_params, local_var_files, 'list[Fileslist]', self.__model_package__)

    def put_file(self, request_object):
        """write a file

        Create or update a file for the specified entity and path, with the provided content. 

        :param PutFileRequest request_object: It contains the below parameters --> |br| ( file* - the file attached content ), |br| ( entityId* - unique identifier of the entity ), |br| ( filepath* - url path of the file along with filename ), |br| ( part - Part number to upload ), |br| ( upload - Upload status to start, complete, and abort multi-part uploads ), |br| ( If-Match - ETag of the latest version for optimistic locking ), |br| ( timestamp - file timestamp ), |br| ( description - description of the file ), |br| ( type - type of the file )

        :return: None
        """
        logger.info('FileServiceClient.put_file() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `put_file`')

        if request_object.file is None:
            raise exceptions.MindsphereClientError('The required parameter `file` is missing from `request_object`, when calling `put_file`')

        if request_object.entity_id is None:
            raise exceptions.MindsphereClientError('The required parameter `entityId` is missing from `request_object`, when calling `put_file`')

        if request_object.filepath is None:
            raise exceptions.MindsphereClientError('The required parameter `filepath` is missing from `request_object`, when calling `put_file`')

        end_point_url = '/files/{entityId}/{filepath}'
        end_point_url = end_point_url.format(entityId=request_object.entity_id, filepath=request_object.filepath)
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Content-Type': 'application/octet-stream', 'If-Match': request_object.if_match, 'timestamp': request_object.timestamp, 'description': request_object.description, 'type': request_object.type, 'Authorization': 'Bearer ' + str(token)}
        query_params = {'part': request_object.part, 'upload': request_object.upload}
        form_params, local_var_files, body_params = {}, {}, request_object.file

        logger.info('FileServiceClient.put_file()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'PUT', query_params, form_params, body_params, local_var_files, None, self.__model_package__)

    def search_files(self, request_object):
        """search files

        Search files for the specified entity.

        :param SearchFilesRequest request_object: It contains the below parameters --> |br| ( entityId* - entity instance id ), |br| ( offset - number of files to skip ), |br| ( limit - maximum number of files to return (max 200) ), |br| ( count - return total number of matching files ), |br| ( order - sort based on supported fields - see order syntax for more details (name, path, type, size, timestamp, created, updated) ), |br| ( filter - filter based on supported fields - see filter syntax for more details (name, path, type, size, timestamp, created, updated) )

        :return: list[FileResponse]
        """
        logger.info('FileServiceClient.search_files() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `search_files`')

        if request_object.entity_id is None:
            raise exceptions.MindsphereClientError('The required parameter `entityId` is missing from `request_object`, when calling `search_files`')

        end_point_url = '/files/{entityId}'
        end_point_url = end_point_url.format(entityId=request_object.entity_id)
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/json', 'Authorization': 'Bearer ' + str(token)}
        query_params = {'offset': request_object.offset, 'limit': request_object.limit, 'count': request_object.count, 'order': request_object.order, 'filter': request_object.filter}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info('FileServiceClient.search_files()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'GET', query_params, form_params, body_params, local_var_files, 'list[FileResponse]', self.__model_package__)

    def initiate_multi_part_upload(self, request_object):
        """initiate a multi part file upload

        Initiate a multi part upload for a file for the specified entity and path, with the provided content.
        :param PutFileRequest request_object: It contains the below parameters -->
                                                ( entityId* - unique identifier of the entity )
                                                     ,( filepath* - url path of the file along with filename )
                                                     ,( If-Match - ETag of the latest version for optimistic locking )
                                                     ,( timestamp - file timestamp )
                                                     ,( description - description of the file )
                                                     ,( type - type of the file )

        :return: None
        """
        logger.info("FileServiceClient.initiate_multi_part_upload() invoked.")
        if request_object is None:
            raise exceptions.MindsphereClientError(
                "`request_object` is not passed when calling `initiate_multi_part_upload`"
            )

        if request_object.entity_id is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `entityId` is missing from `request_object`, when calling "
                "`initiate_multi_part_upload`"
            )

        if request_object.filepath is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `filepath` is missing from `request_object`, when calling "
                "`initiate_multi_part_upload`"
            )

        request_object.upload = "start"
        request_object.file = None
        request_object.part = None
        return self._handle_multi_part_upload(request_object)

    def create_multi_part_file(self, request_object):
        """write a multi part file

        Create a multi part file for the specified entity and path, with the provided content.
        :param PutFileRequest request_object: It contains the below parameters -->
                                                ( file* - the file attached content )
                                                     ,( entityId* - unique identifier of the entity )
                                                     ,( filepath* - url path of the file along with filename )
                                                     ,( part* - Part number to upload )
                                                     ,( timestamp - file timestamp )
                                                     ,( description - description of the file )
                                                     ,( type - type of the file )

        :return: None
        """
        logger.info("FileServiceClient.create_multi_part_file() invoked.")
        if request_object is None:
            raise exceptions.MindsphereClientError(
                "`request_object` is not passed when calling `create_multi_part_file`"
            )
        if request_object.file is None:
            raise exceptions.MindsphereClientError(
                "The Required parameter `file` is not passed when calling `create_multi_part_file`"
            )
        if request_object.entity_id is None:
            raise exceptions.MindsphereClientError(
                "The Required parameter `entity_id` is not passed when calling `create_multi_part_file`"
            )
        if request_object.filepath is None:
            raise exceptions.MindsphereClientError(
                "The Required parameter `filepath` is not passed when calling `create_multi_part_file`"
            )
        if request_object.part is None:
            raise exceptions.MindsphereClientError(
                "The Required parameter `path` is not passed when calling `create_multi_part_file`"
            )

        request_object.upload = None
        request_object.if_match = None
        return self._handle_multi_part_upload(request_object)

    def update_multi_part_file(self, request_object):
        """update a multi part file

        Update a multi part file for the specified entity and path, with the provided content.
        :param PutFileRequest request_object: It contains the below parameters -->
                                                ( file* - the file attached content )
                                                     ,( entityId* - unique identifier of the entity )
                                                     ,( filepath* - url path of the file along with filename )
                                                     ,( part* - Part number to upload )
                                                     ,( If-Match* - ETag of the latest version for optimistic locking )
                                                     ,( timestamp - file timestamp )
                                                     ,( description - description of the file )
                                                     ,( type - type of the file )

        :return: None
        """
        logger.info("FileServiceClient.update_multi_part_file() invoked.")
        if request_object is None:
            raise exceptions.MindsphereClientError(
                "`request_object` is not passed when calling `update_multi_part_file`"
            )
        if request_object.file is None:
            raise exceptions.MindsphereClientError(
                "The Required parameter `file` is not passed when calling `update_multi_part_file`"
            )
        if request_object.entity_id is None:
            raise exceptions.MindsphereClientError(
                "The Required parameter `entity_id` is not passed when calling `update_multi_part_file`"
            )
        if request_object.filepath is None:
            raise exceptions.MindsphereClientError(
                "The Required parameter `filepath` is not passed when calling `update_multi_part_file`"
            )
        if request_object.if_match is None:
            raise exceptions.MindsphereClientError(
                "The Required parameter `if_match` is not passed when calling `update_multi_part_file`"
            )
        if request_object.part is None:
            raise exceptions.MindsphereClientError(
                "The Required parameter `path` is not passed when calling `update_multi_part_file`"
            )

        request_object.upload = None
        return self._handle_multi_part_upload(request_object)

    def complete_multi_part_upload(self, request_object):
        """complete a multi part file upload

        Complete a multi part file upload for the specified entity and path, with the provided content.
        :param PutFileRequest request_object: It contains the below parameters -->
                                                ( file - the file attached content )
                                                     ,( entityId* - unique identifier of the entity )
                                                     ,( filepath* - url path of the file along with filename )
                                                     ,( If-Match - ETag of the latest version for optimistic locking )
                                                     ,( timestamp - file timestamp )
                                                     ,( description - description of the file )
                                                     ,( type - type of the file )

        :return: None
        """
        logger.info("FileServiceClient.complete_multi_part_upload() invoked.")
        if request_object is None:
            raise exceptions.MindsphereClientError(
                "`request_object` is not passed when calling `complete_multi_part_upload`"
            )
        if request_object.entity_id is None:
            raise exceptions.MindsphereClientError(
                "The Required parameter `entity_id` is not passed when calling `complete_multi_part_upload`"
            )
        if request_object.filepath is None:
            raise exceptions.MindsphereClientError(
                "The Required parameter `filepath` is not passed when calling `complete_multi_part_upload`"
            )

        request_object.upload = "complete"
        request_object.part = None
        return self._handle_multi_part_upload(request_object)

    def abort_multi_part_upload(self, request_object):
        """abort a multi part file upload. Used to abort both new and existing multi part file uploads.

        Abort a multi part file upload for the specified entity and path, with the provided content.
        :param PutFileRequest request_object: It contains the below parameters -->
                                                ( entityId* - unique identifier of the entity )
                                                     ,( filepath* - url path of the file along with filename )
                                                     ,( If-Match - ETag of the latest version for optimistic locking )
                                                     ,( timestamp - file timestamp )
                                                     ,( description - description of the file )
                                                     ,( type - type of the file )

        :return: None
        """
        logger.info("FileServiceClient.abort_multi_part_upload() invoked.")
        if request_object is None:
            raise exceptions.MindsphereClientError(
                "`request_object` is not passed when calling `abort_multi_part_upload`"
            )
        if request_object.entity_id is None:
            raise exceptions.MindsphereClientError(
                "The Required parameter `entity_id` is not passed when calling `abort_multi_part_upload`"
            )
        if request_object.filepath is None:
            raise exceptions.MindsphereClientError(
                "The Required parameter `filepath` is not passed when calling `abort_multi_part_upload`"
            )

        request_object.upload = "abort"
        request_object.file = None
        request_object.part = None
        return self._handle_multi_part_upload(request_object)

    def _handle_multi_part_upload(self, request_object):
        end_point_url = "/files/{entityId}/{filepath}"
        end_point_url = end_point_url.format(
            entityId=request_object.entity_id, filepath=request_object.filepath
        )
        token = mindsphere_core.fetch_token(
            self.rest_client_config, self.mindsphere_credentials
        )
        api_url = mindsphere_core.build_url(
            self.__base_path__, end_point_url, self.rest_client_config
        )
        headers = {
            "Content-Type": "application/octet-stream",
            "If-Match": request_object.if_match,
            "timestamp": request_object.timestamp,
            "description": request_object.description,
            "type": request_object.type,
            "Authorization": "Bearer " + str(token),
        }
        query_params = {"part": request_object.part, "upload": request_object.upload}
        form_params, local_var_files, body_params = {}, {}, request_object.file
        return mindsphere_core.invoke_service(
            self.rest_client_config,
            api_url,
            headers,
            "PUT",
            query_params,
            form_params,
            body_params,
            local_var_files,
            None,
        )
