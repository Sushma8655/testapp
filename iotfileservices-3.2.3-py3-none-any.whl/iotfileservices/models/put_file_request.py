# coding: utf-8

"""
    IoT File API

    The IoT File API enables storing and retrieving files for entity instances.  # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class PutFileRequest(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'file': 'str',
        'if_match': 'int',
        'filepath': 'str',
        'upload': 'str',
        'part': 'int',
        'description': 'str',
        'entity_id': 'str',
        'type': 'str',
        'timestamp': 'str'
    }

    attribute_map = {
        'file': 'file',
        'if_match': 'If-Match',
        'filepath': 'filepath',
        'upload': 'upload',
        'part': 'part',
        'description': 'description',
        'entity_id': 'entityId',
        'type': 'type',
        'timestamp': 'timestamp'
    }

    def __init__(self, file=None, if_match=None, filepath=None, upload=None, part=None, description=None, entity_id=None, type=None, timestamp=None):
        self._file = file
        self._if_match = if_match
        self._filepath = filepath
        self._upload = upload
        self._part = part
        self._description = description
        self._entity_id = entity_id
        self._type = type
        self._timestamp = timestamp
        self.discriminator = None

    @property
    def file(self):
        """Gets the file of this PutFileRequest.

        :return: The file of this PutFileRequest.
        :rtype: str
        """
        return self._file

    @file.setter
    def file(self, file):
        """Sets the file of this PutFileRequest.

        :param file: The file of this PutFileRequest.
        :type: str
        """

        self._file = file

    @property
    def if_match(self):
        """Gets the if_match of this PutFileRequest.

        :return: The if_match of this PutFileRequest.
        :rtype: int
        """
        return self._if_match

    @if_match.setter
    def if_match(self, if_match):
        """Sets the if_match of this PutFileRequest.

        :param if_match: The if_match of this PutFileRequest.
        :type: int
        """

        self._if_match = if_match

    @property
    def filepath(self):
        """Gets the filepath of this PutFileRequest.

        :return: The filepath of this PutFileRequest.
        :rtype: str
        """
        return self._filepath

    @filepath.setter
    def filepath(self, filepath):
        """Sets the filepath of this PutFileRequest.

        :param filepath: The filepath of this PutFileRequest.
        :type: str
        """

        self._filepath = filepath

    @property
    def upload(self):
        """Gets the upload of this PutFileRequest.

        :return: The upload of this PutFileRequest.
        :rtype: str
        """
        return self._upload

    @upload.setter
    def upload(self, upload):
        """Sets the upload of this PutFileRequest.

        :param upload: The upload of this PutFileRequest.
        :type: str
        """

        self._upload = upload

    @property
    def part(self):
        """Gets the part of this PutFileRequest.

        :return: The part of this PutFileRequest.
        :rtype: int
        """
        return self._part

    @part.setter
    def part(self, part):
        """Sets the part of this PutFileRequest.

        :param part: The part of this PutFileRequest.
        :type: int
        """

        self._part = part

    @property
    def description(self):
        """Gets the description of this PutFileRequest.

        :return: The description of this PutFileRequest.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        """Sets the description of this PutFileRequest.

        :param description: The description of this PutFileRequest.
        :type: str
        """

        self._description = description

    @property
    def entity_id(self):
        """Gets the entity_id of this PutFileRequest.

        :return: The entity_id of this PutFileRequest.
        :rtype: str
        """
        return self._entity_id

    @entity_id.setter
    def entity_id(self, entity_id):
        """Sets the entity_id of this PutFileRequest.

        :param entity_id: The entity_id of this PutFileRequest.
        :type: str
        """

        self._entity_id = entity_id

    @property
    def type(self):
        """Gets the type of this PutFileRequest.

        :return: The type of this PutFileRequest.
        :rtype: str
        """
        return self._type

    @type.setter
    def type(self, type):
        """Sets the type of this PutFileRequest.

        :param type: The type of this PutFileRequest.
        :type: str
        """

        self._type = type

    @property
    def timestamp(self):
        """Gets the timestamp of this PutFileRequest.

        :return: The timestamp of this PutFileRequest.
        :rtype: str
        """
        return self._timestamp

    @timestamp.setter
    def timestamp(self, timestamp):
        """Sets the timestamp of this PutFileRequest.

        :param timestamp: The timestamp of this PutFileRequest.
        :type: str
        """

        self._timestamp = timestamp

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(PutFileRequest, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, PutFileRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
