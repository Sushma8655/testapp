# coding: utf-8

"""
    IoT File API

    The IoT File API enables storing and retrieving files for entity instances.  # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class FileResponse(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'name': 'str',
        'path': 'str',
        'type': 'str',
        'size': 'int',
        'timestamp': 'datetime',
        'created': 'datetime',
        'updated': 'datetime',
        'created_by': 'str',
        'updated_by': 'str',
        'description': 'str',
        'etag': 'int'
    }

    attribute_map = {
        'name': 'name',
        'path': 'path',
        'type': 'type',
        'size': 'size',
        'timestamp': 'timestamp',
        'created': 'created',
        'updated': 'updated',
        'created_by': 'createdBy',
        'updated_by': 'updatedBy',
        'description': 'description',
        'etag': 'etag'
    }

    def __init__(self, name=None, path=None, type=None, size=None, timestamp=None, created=None, updated=None, created_by=None, updated_by=None, description=None, etag=None):
        self._name = name
        self._path = path
        self._type = type
        self._size = size
        self._timestamp = timestamp
        self._created = created
        self._updated = updated
        self._created_by = created_by
        self._updated_by = updated_by
        self._description = description
        self._etag = etag
        self.discriminator = None

    @property
    def name(self):
        """Gets the name of this FileResponse.

        :return: The name of this FileResponse.
        :rtype: str
        """
        return self._name

    @name.setter
    def name(self, name):
        """Sets the name of this FileResponse.

        :param name: The name of this FileResponse.
        :type: str
        """

        self._name = name

    @property
    def path(self):
        """Gets the path of this FileResponse.

        :return: The path of this FileResponse.
        :rtype: str
        """
        return self._path

    @path.setter
    def path(self, path):
        """Sets the path of this FileResponse.

        :param path: The path of this FileResponse.
        :type: str
        """

        self._path = path

    @property
    def type(self):
        """Gets the type of this FileResponse.

        :return: The type of this FileResponse.
        :rtype: str
        """
        return self._type

    @type.setter
    def type(self, type):
        """Sets the type of this FileResponse.

        :param type: The type of this FileResponse.
        :type: str
        """

        self._type = type

    @property
    def size(self):
        """Gets the size of this FileResponse.

        :return: The size of this FileResponse.
        :rtype: int
        """
        return self._size

    @size.setter
    def size(self, size):
        """Sets the size of this FileResponse.

        :param size: The size of this FileResponse.
        :type: int
        """

        self._size = size

    @property
    def timestamp(self):
        """Gets the timestamp of this FileResponse.

        :return: The timestamp of this FileResponse.
        :rtype: datetime
        """
        return self._timestamp

    @timestamp.setter
    def timestamp(self, timestamp):
        """Sets the timestamp of this FileResponse.

        :param timestamp: The timestamp of this FileResponse.
        :type: datetime
        """

        self._timestamp = timestamp

    @property
    def created(self):
        """Gets the created of this FileResponse.

        :return: The created of this FileResponse.
        :rtype: datetime
        """
        return self._created

    @created.setter
    def created(self, created):
        """Sets the created of this FileResponse.

        :param created: The created of this FileResponse.
        :type: datetime
        """

        self._created = created

    @property
    def updated(self):
        """Gets the updated of this FileResponse.

        :return: The updated of this FileResponse.
        :rtype: datetime
        """
        return self._updated

    @updated.setter
    def updated(self, updated):
        """Sets the updated of this FileResponse.

        :param updated: The updated of this FileResponse.
        :type: datetime
        """

        self._updated = updated

    @property
    def created_by(self):
        """Gets the created_by of this FileResponse.

        :return: The created_by of this FileResponse.
        :rtype: str
        """
        return self._created_by

    @created_by.setter
    def created_by(self, created_by):
        """Sets the created_by of this FileResponse.

        :param created_by: The created_by of this FileResponse.
        :type: str
        """

        self._created_by = created_by

    @property
    def updated_by(self):
        """Gets the updated_by of this FileResponse.

        :return: The updated_by of this FileResponse.
        :rtype: str
        """
        return self._updated_by

    @updated_by.setter
    def updated_by(self, updated_by):
        """Sets the updated_by of this FileResponse.

        :param updated_by: The updated_by of this FileResponse.
        :type: str
        """

        self._updated_by = updated_by

    @property
    def description(self):
        """Gets the description of this FileResponse.

        :return: The description of this FileResponse.
        :rtype: str
        """
        return self._description

    @description.setter
    def description(self, description):
        """Sets the description of this FileResponse.

        :param description: The description of this FileResponse.
        :type: str
        """

        self._description = description

    @property
    def etag(self):
        """Gets the etag of this FileResponse.

        :return: The etag of this FileResponse.
        :rtype: int
        """
        return self._etag

    @etag.setter
    def etag(self, etag):
        """Sets the etag of this FileResponse.

        :param etag: The etag of this FileResponse.
        :type: int
        """

        self._etag = etag

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(FileResponse, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, FileResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
