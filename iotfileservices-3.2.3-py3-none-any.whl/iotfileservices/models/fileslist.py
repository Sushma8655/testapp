# coding: utf-8

"""
    IoT File API

    The IoT File API enables storing and retrieving files for entity instances.  # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class Fileslist(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'object_key': 'str',
        'part_no': 'int',
        'created': 'int'
    }

    attribute_map = {
        'object_key': 'objectKey',
        'part_no': 'partNo',
        'created': 'created'
    }

    def __init__(self, object_key=None, part_no=None, created=None):
        self._object_key = object_key
        self._part_no = part_no
        self._created = created
        self.discriminator = None

    @property
    def object_key(self):
        """Gets the object_key of this Fileslist.

        :return: The object_key of this Fileslist.
        :rtype: str
        """
        return self._object_key

    @object_key.setter
    def object_key(self, object_key):
        """Sets the object_key of this Fileslist.

        :param object_key: The object_key of this Fileslist.
        :type: str
        """

        self._object_key = object_key

    @property
    def part_no(self):
        """Gets the part_no of this Fileslist.

        :return: The part_no of this Fileslist.
        :rtype: int
        """
        return self._part_no

    @part_no.setter
    def part_no(self, part_no):
        """Sets the part_no of this Fileslist.

        :param part_no: The part_no of this Fileslist.
        :type: int
        """

        self._part_no = part_no

    @property
    def created(self):
        """Gets the created of this Fileslist.

        :return: The created of this Fileslist.
        :rtype: int
        """
        return self._created

    @created.setter
    def created(self, created):
        """Sets the created of this Fileslist.

        :param created: The created of this Fileslist.
        :type: int
        """

        self._created = created

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(Fileslist, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, Fileslist):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
