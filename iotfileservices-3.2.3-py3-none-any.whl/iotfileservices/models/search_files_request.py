# coding: utf-8

"""
    IoT File API

    The IoT File API enables storing and retrieving files for entity instances.  # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class SearchFilesRequest(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'filter': 'str',
        'offset': 'float',
        'limit': 'int',
        'count': 'bool',
        'entity_id': 'str',
        'order': 'str'
    }

    attribute_map = {
        'filter': 'filter',
        'offset': 'offset',
        'limit': 'limit',
        'count': 'count',
        'entity_id': 'entityId',
        'order': 'order'
    }

    def __init__(self, filter=None, offset=None, limit=None, count=None, entity_id=None, order=None):
        self._filter = filter
        self._offset = offset
        self._limit = limit
        self._count = count
        self._entity_id = entity_id
        self._order = order
        self.discriminator = None

    @property
    def filter(self):
        """Gets the filter of this SearchFilesRequest.

        :return: The filter of this SearchFilesRequest.
        :rtype: str
        """
        return self._filter

    @filter.setter
    def filter(self, filter):
        """Sets the filter of this SearchFilesRequest.

        :param filter: The filter of this SearchFilesRequest.
        :type: str
        """

        self._filter = filter

    @property
    def offset(self):
        """Gets the offset of this SearchFilesRequest.

        :return: The offset of this SearchFilesRequest.
        :rtype: float
        """
        return self._offset

    @offset.setter
    def offset(self, offset):
        """Sets the offset of this SearchFilesRequest.

        :param offset: The offset of this SearchFilesRequest.
        :type: float
        """

        self._offset = offset

    @property
    def limit(self):
        """Gets the limit of this SearchFilesRequest.

        :return: The limit of this SearchFilesRequest.
        :rtype: int
        """
        return self._limit

    @limit.setter
    def limit(self, limit):
        """Sets the limit of this SearchFilesRequest.

        :param limit: The limit of this SearchFilesRequest.
        :type: int
        """

        self._limit = limit

    @property
    def count(self):
        """Gets the count of this SearchFilesRequest.

        :return: The count of this SearchFilesRequest.
        :rtype: bool
        """
        return self._count

    @count.setter
    def count(self, count):
        """Sets the count of this SearchFilesRequest.

        :param count: The count of this SearchFilesRequest.
        :type: bool
        """

        self._count = count

    @property
    def entity_id(self):
        """Gets the entity_id of this SearchFilesRequest.

        :return: The entity_id of this SearchFilesRequest.
        :rtype: str
        """
        return self._entity_id

    @entity_id.setter
    def entity_id(self, entity_id):
        """Sets the entity_id of this SearchFilesRequest.

        :param entity_id: The entity_id of this SearchFilesRequest.
        :type: str
        """

        self._entity_id = entity_id

    @property
    def order(self):
        """Gets the order of this SearchFilesRequest.

        :return: The order of this SearchFilesRequest.
        :rtype: str
        """
        return self._order

    @order.setter
    def order(self, order):
        """Sets the order of this SearchFilesRequest.

        :param order: The order of this SearchFilesRequest.
        :type: str
        """

        self._order = order

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(SearchFilesRequest, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, SearchFilesRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
