# coding: utf-8

"""
    IoT File API

    The IoT File API enables storing and retrieving files for entity instances.  # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class GetIOTFileRequest(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'if_none_match': 'int',
        'filepath': 'str',
        'range': 'str',
        'entity_id': 'str'
    }

    attribute_map = {
        'if_none_match': 'If-None-Match',
        'filepath': 'filepath',
        'range': 'range',
        'entity_id': 'entityId'
    }

    def __init__(self, if_none_match=None, filepath=None, range=None, entity_id=None):
        self._if_none_match = if_none_match
        self._filepath = filepath
        self._range = range
        self._entity_id = entity_id
        self.discriminator = None

    @property
    def if_none_match(self):
        """Gets the if_none_match of this GetFileRequest.

        :return: The if_none_match of this GetFileRequest.
        :rtype: int
        """
        return self._if_none_match

    @if_none_match.setter
    def if_none_match(self, if_none_match):
        """Sets the if_none_match of this GetFileRequest.

        :param if_none_match: The if_none_match of this GetFileRequest.
        :type: int
        """

        self._if_none_match = if_none_match

    @property
    def filepath(self):
        """Gets the filepath of this GetFileRequest.

        :return: The filepath of this GetFileRequest.
        :rtype: str
        """
        return self._filepath

    @filepath.setter
    def filepath(self, filepath):
        """Sets the filepath of this GetFileRequest.

        :param filepath: The filepath of this GetFileRequest.
        :type: str
        """

        self._filepath = filepath

    @property
    def range(self):
        """Gets the range of this GetFileRequest.

        :return: The range of this GetFileRequest.
        :rtype: str
        """
        return self._range

    @range.setter
    def range(self, range):
        """Sets the range of this GetFileRequest.

        :param range: The range of this GetFileRequest.
        :type: str
        """

        self._range = range

    @property
    def entity_id(self):
        """Gets the entity_id of this GetFileRequest.

        :return: The entity_id of this GetFileRequest.
        :rtype: str
        """
        return self._entity_id

    @entity_id.setter
    def entity_id(self, entity_id):
        """Sets the entity_id of this GetFileRequest.

        :param entity_id: The entity_id of this GetFileRequest.
        :type: str
        """

        self._entity_id = entity_id

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(GetFileRequest, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, GetFileRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
