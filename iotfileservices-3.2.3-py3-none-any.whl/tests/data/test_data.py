
# common Values
TENANT = 'mdspsdk'
CLIENT_ID = ""
CLIENT_SECRET = ""

# file service client
FILE_ENTITY_ID = "078b1908bc9347678168760934465587"
FILE_PATH_NAME = "Integ"
