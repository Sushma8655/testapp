# coding: utf-8

"""
    Event Analytics API

    Provides the essential functionality for a data-driven analysis of the event data.  # noqa: E501
"""


from __future__ import absolute_import

import unittest
from unittest.mock import MagicMock
from eventanalytics.clients import EventOperationsClient
from eventanalytics.models import *
from tests.unit.test_util import TestUtil, MOCK_VALUE, MOCK_SUCCESS
from mindsphere_core.exceptions import MindsphereError
from mindsphere_core import TenantCredentials, mindsphere_core, token_service


class EventOperationsClientUnitTest(unittest.TestCase):
    """EventOperationsClient unit test stubs"""

    def setUp(self):
        credentials = TenantCredentials(client_id=MOCK_VALUE, client_secret=MOCK_VALUE, tenant=MOCK_VALUE)
        config = mindsphere_core.RestClientConfig(MOCK_VALUE, MOCK_VALUE)
        self.client = EventOperationsClient(config, credentials)
        token_service._invoke_token_endpoint = MagicMock(return_value=MOCK_SUCCESS)

    def test_count_events(self):
        """Test case for count_events
        Determines the number of events for a required time resolution.
        """
        package_name = "eventanalytics.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = CountEventsRequest()
        request_object.data = TestUtil.get_mock_data(package_name, "EventInput")
        response = self.client.count_events(request_object)
        self.assertEqual(200, response)

    def test_negative_count_events(self):
        """Negative test case for count_events
        Determines the number of events for a required time resolution.
        """
        request_object = CountEventsRequest()
        with self.assertRaises(MindsphereError):
            self.client.count_events(request_object)

    def test_negative_request_count_events(self):
        """Negative test case for count_events
        Determines the number of events for a required time resolution.
        """
        with self.assertRaises(MindsphereError):
            self.client.count_events(None)

    def test_filter_events(self):
        """Test case for filter_events
        Simplifies the dataset to the most meaningful data
        """
        package_name = "eventanalytics.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = FilterEventsRequest()
        request_object.data = TestUtil.get_mock_data(package_name, "EventSearchInputDataModel")
        response = self.client.filter_events(request_object)
        self.assertEqual(200, response)

    def test_negative_filter_events(self):
        """Negative test case for filter_events
        Simplifies the dataset to the most meaningful data
        """
        request_object = FilterEventsRequest()
        with self.assertRaises(MindsphereError):
            self.client.filter_events(request_object)

    def test_negative_request_filter_events(self):
        """Negative test case for filter_events
        Simplifies the dataset to the most meaningful data
        """
        with self.assertRaises(MindsphereError):
            self.client.filter_events(None)

    def test_remove_duplicate_events(self):
        """Test case for remove_duplicate_events
        Removes the duplicate events
        """
        package_name = "eventanalytics.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = RemoveDuplicateEventsRequest()
        request_object.data = TestUtil.get_mock_data(package_name, "EventInput")
        response = self.client.remove_duplicate_events(request_object)
        self.assertEqual(200, response)

    def test_negative_remove_duplicate_events(self):
        """Negative test case for remove_duplicate_events
        Removes the duplicate events
        """
        request_object = RemoveDuplicateEventsRequest()
        with self.assertRaises(MindsphereError):
            self.client.remove_duplicate_events(request_object)

    def test_negative_request_remove_duplicate_events(self):
        """Negative test case for remove_duplicate_events
        Removes the duplicate events
        """
        with self.assertRaises(MindsphereError):
            self.client.remove_duplicate_events(None)

    def test_top_events(self):
        """Test case for top_events
        Find most frequent top N events
        """
        package_name = "eventanalytics.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = TopEventsRequest()
        request_object.data = TestUtil.get_mock_data(package_name, "TopEventsInputDataModel")
        response = self.client.top_events(request_object)
        self.assertEqual(200, response)

    def test_negative_top_events(self):
        """Negative test case for top_events
        Find most frequent top N events
        """
        request_object = TopEventsRequest()
        with self.assertRaises(MindsphereError):
            self.client.top_events(request_object)

    def test_negative_request_top_events(self):
        """Negative test case for top_events
        Find most frequent top N events
        """
        with self.assertRaises(MindsphereError):
            self.client.top_events(None)


if __name__ == '__main__':
    unittest.main()
