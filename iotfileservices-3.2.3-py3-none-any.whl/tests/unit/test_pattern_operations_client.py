# coding: utf-8

"""
    Event Analytics API

    Provides the essential functionality for a data-driven analysis of the event data.  # noqa: E501
"""


from __future__ import absolute_import

import unittest
from unittest.mock import MagicMock
from eventanalytics.clients import PatternOperationsClient
from eventanalytics.models import *
from tests.unit.test_util import TestUtil, MOCK_VALUE, MOCK_SUCCESS
from mindsphere_core.exceptions import MindsphereError
from mindsphere_core import TenantCredentials, mindsphere_core, token_service


class PatternOperationsClientUnitTest(unittest.TestCase):
    """PatternOperationsClient unit test stubs"""

    def setUp(self):
        credentials = TenantCredentials(client_id=MOCK_VALUE, client_secret=MOCK_VALUE, tenant=MOCK_VALUE)
        config = mindsphere_core.RestClientConfig(MOCK_VALUE, MOCK_VALUE)
        self.client = PatternOperationsClient(config, credentials)
        token_service._invoke_token_endpoint = MagicMock(return_value=MOCK_SUCCESS)

    def test_match_patterns_over_events(self):
        """Test case for match_patterns_over_events
        Applies the patterns specified in body on a list of events
        """
        package_name = "eventanalytics.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = MatchPatternsOverEventsRequest()
        request_object.data = TestUtil.get_mock_data(package_name, "PatternMatchingInputDataModel")
        response = self.client.match_patterns_over_events(request_object)
        self.assertEqual(200, response)

    def test_negative_match_patterns_over_events(self):
        """Negative test case for match_patterns_over_events
        Applies the patterns specified in body on a list of events
        """
        request_object = MatchPatternsOverEventsRequest()
        with self.assertRaises(MindsphereError):
            self.client.match_patterns_over_events(request_object)

    def test_negative_request_match_patterns_over_events(self):
        """Negative test case for match_patterns_over_events
        Applies the patterns specified in body on a list of events
        """
        with self.assertRaises(MindsphereError):
            self.client.match_patterns_over_events(None)


if __name__ == '__main__':
    unittest.main()
