# coding: utf-8

"""
    IoT File API

    The IoT File API enables storing and retrieving files for entity instances.  # noqa: E501
"""


from __future__ import absolute_import

import unittest
from unittest.mock import MagicMock
from iotfileservices.clients import FileServiceClient
from iotfileservices.models import *
from tests.unit.test_util import TestUtil, MOCK_VALUE, MOCK_SUCCESS
from mindsphere_core.exceptions import MindsphereError
from mindsphere_core import TenantCredentials, mindsphere_core, token_service


class FileServiceClientUnitTest(unittest.TestCase):
    """FileServiceClient unit test stubs"""

    def setUp(self):
        credentials = TenantCredentials(client_id=MOCK_VALUE, client_secret=MOCK_VALUE, tenant=MOCK_VALUE)
        config = mindsphere_core.RestClientConfig(MOCK_VALUE, MOCK_VALUE)
        self.client = FileServiceClient(config, credentials)
        token_service._invoke_token_endpoint = MagicMock(return_value=MOCK_SUCCESS)

    def test_delete_file(self):
        """Test case for delete_file
        delete a file
        """
        package_name = "iotfileservices.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = DeleteFileRequest()
        request_object.entity_id = TestUtil.get_mock_data(package_name, "str")
        request_object.filepath = TestUtil.get_mock_data(package_name, "str")
        response = self.client.delete_file(request_object)
        self.assertEqual(200, response)

    def test_negative_delete_file(self):
        """Negative test case for delete_file
        delete a file
        """
        request_object = DeleteFileRequest()
        with self.assertRaises(MindsphereError):
            self.client.delete_file(request_object)

    def test_negative_request_delete_file(self):
        """Negative test case for delete_file
        delete a file
        """
        with self.assertRaises(MindsphereError):
            self.client.delete_file(None)

    def test_get_file(self):
        """Test case for get_file
        read a file
        """
        package_name = "iotfileservices.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = GetFileRequest()
        request_object.entity_id = TestUtil.get_mock_data(package_name, "str")
        request_object.filepath = TestUtil.get_mock_data(package_name, "str")
        response = self.client.get_file(request_object)
        self.assertEqual(200, response)

    def test_negative_get_file(self):
        """Negative test case for get_file
        read a file
        """
        request_object = GetFileRequest()
        with self.assertRaises(MindsphereError):
            self.client.get_file(request_object)

    def test_negative_request_get_file(self):
        """Negative test case for get_file
        read a file
        """
        with self.assertRaises(MindsphereError):
            self.client.get_file(None)

    def test_get_file_list(self):
        """Test case for get_file_list
        list multi part uploads
        """
        package_name = "iotfileservices.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = GetFileListRequest()
        request_object.entity_id = TestUtil.get_mock_data(package_name, "str")
        request_object.filepath = TestUtil.get_mock_data(package_name, "str")
        response = self.client.get_file_list(request_object)
        self.assertEqual(200, response)

    def test_negative_get_file_list(self):
        """Negative test case for get_file_list
        list multi part uploads
        """
        request_object = GetFileListRequest()
        with self.assertRaises(MindsphereError):
            self.client.get_file_list(request_object)

    def test_negative_request_get_file_list(self):
        """Negative test case for get_file_list
        list multi part uploads
        """
        with self.assertRaises(MindsphereError):
            self.client.get_file_list(None)

    def test_put_file(self):
        """Test case for put_file
        write a file
        """
        package_name = "iotfileservices.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = PutFileRequest()
        request_object.file = TestUtil.get_mock_data(package_name, "str")
        request_object.entity_id = TestUtil.get_mock_data(package_name, "str")
        request_object.filepath = TestUtil.get_mock_data(package_name, "str")
        response = self.client.put_file(request_object)
        self.assertEqual(200, response)

    def test_negative_put_file(self):
        """Negative test case for put_file
        write a file
        """
        request_object = PutFileRequest()
        with self.assertRaises(MindsphereError):
            self.client.put_file(request_object)

    def test_negative_request_put_file(self):
        """Negative test case for put_file
        write a file
        """
        with self.assertRaises(MindsphereError):
            self.client.put_file(None)

    def test_search_files(self):
        """Test case for search_files
        search files
        """
        package_name = "iotfileservices.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = SearchFilesRequest()
        request_object.entity_id = TestUtil.get_mock_data(package_name, "str")
        response = self.client.search_files(request_object)
        self.assertEqual(200, response)

    def test_negative_search_files(self):
        """Negative test case for search_files
        search files
        """
        request_object = SearchFilesRequest()
        with self.assertRaises(MindsphereError):
            self.client.search_files(request_object)

    def test_negative_request_search_files(self):
        """Negative test case for search_files
        search files
        """
        with self.assertRaises(MindsphereError):
            self.client.search_files(None)

    def test_initiate_multi_part_upload(self):
        """Test case for test_initiate_multi_part_upload
                initiate a multi part file upload
                """
        package_name = "iotfile.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = PutFileRequest()
        request_object.entity_id = TestUtil.get_mock_data(package_name, "str")
        request_object.filepath = TestUtil.get_mock_data(package_name, "str")
        response = self.client.initiate_multi_part_upload(request_object)
        self.assertEqual(200, response)

    def test_negative_initiate_multi_part_upload(self):
        """Negative test case for test_initiate_multi_part_upload
        initiate a multi part file upload
        """
        request_object = PutFileRequest()
        with self.assertRaises(MindsphereError):
            self.client.initiate_multi_part_upload(request_object)

    def test_negative_request_initiate_multi_part_upload(self):
        """Negative test case for test_initiate_multi_part_upload
        initiate a multi part file upload
        """
        with self.assertRaises(MindsphereError):
            self.client.initiate_multi_part_upload(None)

    def test_create_multi_part_file(self):
        """Test case for test_create_multi_part_file
                Create a multi part file upload
                """
        package_name = "iotfile.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = PutFileRequest()
        request_object.file = TestUtil.get_mock_data(package_name, "str")
        request_object.entity_id = TestUtil.get_mock_data(package_name, "str")
        request_object.filepath = TestUtil.get_mock_data(package_name, "str")
        request_object.part = TestUtil.get_mock_data(package_name, "int")
        response = self.client.create_multi_part_file(request_object)
        self.assertEqual(200, response)

    def test_negative_create_multi_part_file(self):
        """Negative test case for test_create_multi_part_file
        Create a multi part file upload
        """
        request_object = PutFileRequest()
        with self.assertRaises(MindsphereError):
            self.client.create_multi_part_file(request_object)

    def test_negative_request_create_multi_part_file(self):
        """Negative test case for test_create_multi_part_file
        Create a multi part file upload
        """
        with self.assertRaises(MindsphereError):
            self.client.create_multi_part_file(None)

    def test_update_multi_part_file(self):
        """Test case for test_update_multi_part_file
                Update a multi part file upload
                """
        package_name = "iotfile.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = PutFileRequest()
        request_object.file = TestUtil.get_mock_data(package_name, "str")
        request_object.entity_id = TestUtil.get_mock_data(package_name, "str")
        request_object.filepath = TestUtil.get_mock_data(package_name, "str")
        request_object.part = TestUtil.get_mock_data(package_name, "int")
        request_object.if_match = TestUtil.get_mock_data(package_name, "int")
        response = self.client.update_multi_part_file(request_object)
        self.assertEqual(200, response)

    def test_negative_update_multi_part_file(self):
        """Negative test case for test_update_multi_part_file
        Update a multi part file upload
        """
        request_object = PutFileRequest()
        with self.assertRaises(MindsphereError):
            self.client.update_multi_part_file(request_object)

    def test_negative_request_update_multi_part_file(self):
        """Negative test case for test_update_multi_part_file
        Update a multi part file upload
        """
        with self.assertRaises(MindsphereError):
            self.client.update_multi_part_file(None)

    def test_complete_multi_part_upload(self):
        """Test case for test_complete_multi_part_upload
                Complete a multi part file upload
                """
        package_name = "iotfile.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = PutFileRequest()
        request_object.entity_id = TestUtil.get_mock_data(package_name, "str")
        request_object.filepath = TestUtil.get_mock_data(package_name, "str")
        response = self.client.complete_multi_part_upload(request_object)
        self.assertEqual(200, response)

    def test_negative_complete_multi_part_upload(self):
        """Negative test case for test_complete_multi_part_upload
        Complete a multi part file upload
        """
        request_object = PutFileRequest()
        with self.assertRaises(MindsphereError):
            self.client.complete_multi_part_upload(request_object)

    def test_negative_request_complete_multi_part_upload(self):
        """Negative test case for test_complete_multi_part_upload
        Complete a multi part file upload
        """
        with self.assertRaises(MindsphereError):
            self.client.complete_multi_part_upload(None)

    def test_abort_multi_part_upload(self):
        """Test case for test_abort_multi_part_upload
                Abort a multi part file upload
                """
        package_name = "iotfile.models"
        mindsphere_core.invoke_service = MagicMock(return_value=204)
        request_object = PutFileRequest()
        request_object.entity_id = TestUtil.get_mock_data(package_name, "str")
        request_object.filepath = TestUtil.get_mock_data(package_name, "str")
        response = self.client.abort_multi_part_upload(request_object)
        self.assertEqual(204, response)

    def test_negative_abort_multi_part_upload(self):
        """Negative test case for test_abort_multi_part_upload
        Abort a multi part file upload
        """
        request_object = PutFileRequest()
        with self.assertRaises(MindsphereError):
            self.client.abort_multi_part_upload(request_object)

    def test_negative_request_abort_multi_part_upload(self):
        """Negative test case for test_abort_multi_part_upload
        Abort a multi part file upload
        """
        with self.assertRaises(MindsphereError):
            self.client.abort_multi_part_upload(None)


if __name__ == '__main__':
    unittest.main()
