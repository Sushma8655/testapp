import unittest
import random
import os
import os.path
from mindsphere_core import mindsphere_core, TenantCredentials
from mindsphere_core.exceptions import MindsphereError
from iotfileservices.clients.file_service_client import FileServiceClient
from iotfileservices.models import *
from tests.data.test_data import *


class TestFileServiceApi(unittest.TestCase):
    def setUp(self):
        config = mindsphere_core.RestClientConfig("194.138.0.25", "9400")
        credentials = None
        self.client = FileServiceClient(rest_client_config=config, mindsphere_credentials=credentials)

    def test_put_file(self):
        # generating path value random

        path = FILE_PATH_NAME + str(self.get_random_number())
        with open(
            os.path.dirname(os.path.abspath(__file__ + "/../.."))
            + "\\"
            + os.path.join("tests")
            + "\\"
            + os.path.join("data")
            + r"\test.txt",
            "r",
            encoding="utf-8",
        ) as f:
            file_data = f.read().splitlines()
            print(path)
        # put Api call
        request_object = PutFileRequest(
            file=file_data,
            if_match=None,
            filepath=path,
            upload=None,
            part=None,
            description="lorem test3",
            entity_id=FILE_ENTITY_ID,
            type="txt",
            timestamp="2018-09-10T05:03:42.363Z",
        )
        resource = self.client.put_file(request_object)
        print(resource)

    def test_should_throw_file_not_found_exception_file(self):
        # generating path value random
        path = FILE_PATH_NAME + str(self.get_random_number())
        with self.assertRaises(FileNotFoundError):
            with open(
                os.path.dirname(os.path.abspath(__file__ + "/../.."))
                + "\\"
                + os.path.join("tests")
                + "\\"
                + os.path.join("data")
                + r"\invalid.txt",
                "r",
                encoding="utf-8",
            ) as f:
                file_data = f.read().splitlines()
            print(path)
            request_object = PutFileRequest(
                file=file_data,
                if_match=None,
                filepath=path,
                upload=None,
                part=None,
                description="lorem test3",
                entity_id=FILE_ENTITY_ID,
                type="txt",
                timestamp="2018-09-10T05:03:42.363Z",
            )
            # put Api call
            self.client.put_file(request_object)

    def test_should_throw_exception_for_conflict_path_file(self):
        # generating path value random
        path = FILE_PATH_NAME + str(self.get_random_number())
        with open(
            os.path.dirname(os.path.abspath(__file__ + "/../.."))
            + "\\"
            + os.path.join("tests")
            + "\\"
            + os.path.join("data")
            + r"\test.txt",
            "r",
            encoding="utf-8",
        ) as f:
            file_data = f.read().splitlines()
        print(path)
        with self.assertRaises(MindsphereError):
            request_object = PutFileRequest(
                file=file_data,
                if_match=None,
                filepath=path,
                upload=None,
                part=None,
                description="lorem test3",
                entity_id=FILE_ENTITY_ID,
                type="txt",
                timestamp="2018-09-10T05:03:42.363Z",
            )
            # put Api call
            self.client.put_file(request_object)
            self.client.put_file(request_object)

    def test_should_throw_unauthorized_exception(self):
        credentials = TenantCredentials(
            client_id="INVALID", client_secret="INVALID", tenant=TENANT
        )
        config = mindsphere_core.RestClientConfig("194.138.0.25", "9400")
        client = FileServiceClient(config, credentials)
        path = FILE_PATH_NAME + str(self.get_random_number())
        with open(
            os.path.dirname(os.path.abspath(__file__ + "/../.."))
            + "\\"
            + os.path.join("tests")
            + "\\"
            + os.path.join("data")
            + r"\test.txt",
            "r",
        ) as f:
            file_data = f.read()
        with self.assertRaises(MindsphereError):
            request_object1 = PutFileRequest(
                file=file_data,
                if_match=None,
                filepath=path,
                upload=None,
                part=None,
                description="lorem test3",
                entity_id=FILE_ENTITY_ID,
                type="txt",
                timestamp="2018-09-10T05:03:42.363Z",
            )
            # put Api call
            client.put_file(request_object1)

    def test_get_file(self):
        # generating path value random
        path = FILE_PATH_NAME + str(self.get_random_number())
        with open(
            os.path.dirname(os.path.abspath(__file__ + "/../.."))
            + "\\"
            + os.path.join("tests")
            + "\\"
            + os.path.join("data")
            + r"\test.txt",
            "r",
        ) as f:
            file_data = f.read()
        request_object1 = PutFileRequest(
            file=file_data,
            if_match=None,
            filepath=path,
            upload=None,
            part=None,
            description="lorem test3",
            entity_id=FILE_ENTITY_ID,
            type="txt",
            timestamp="2018-09-10T05:03:42.363Z",
        )
        # put Api call
        self.client.put_file(request_object1)
        request_object2 = GetIOTFileRequest(
            if_none_match=None, filepath=path, range=None, entity_id=FILE_ENTITY_ID
        )
        # get Api call
        get_file_response = self.client.get_file(request_object2)
        print("path : " + path)
        self.assertIsNotNone(get_file_response)

    def test_should_throw_service_exception_invalid_file_path(self):
        with self.assertRaises(MindsphereError):
            # get Api call
            request_object = GetIOTFileRequest(
                if_none_match=None,
                filepath="invalid",
                range=None,
                entity_id=FILE_ENTITY_ID,
            )
            self.client.get_file(request_object)

    def test_should_throw_service_exception_invalid_entity(self):
        # generating path value random
        path = FILE_PATH_NAME + str(self.get_random_number())
        with self.assertRaises(MindsphereError):
            request_object = GetIOTFileRequest(
                if_none_match=None, filepath=path, range=None, entity_id="invalid"
            )
            # get Api call
            self.client.get_file(request_object)

    def test_search_file(self):
        request_object = SearchFilesRequest(
            filter=None,
            offset=None,
            limit=None,
            count=None,
            entity_id=FILE_ENTITY_ID,
            order=None,
        )
        # search Api call
        response = self.client.search_files(request_object)
        # response = self.client.search_files(FILE_ENTITY_ID)
        self.assertIsNotNone(len(response))

    def test_should_throw_service_exception_for_invalid_entity_for_search_file(self):
        with self.assertRaises(MindsphereError):
            request_object = SearchFilesRequest(entity_id="invalid")
            # search Api call
            self.client.search_files(request_object)

    def test_should_throw_client_exception_for_entity_is_null_for_search_file(self):
        with self.assertRaises(MindsphereError):
            request_object = SearchFilesRequest(entity_id=None)
            # search Api call
            self.client.search_files(request_object)

    def test_delete_file(self):
        # generating path value random
        path = FILE_PATH_NAME + str(self.get_random_number())
        with open(
            os.path.dirname(os.path.abspath(__file__ + "/../.."))
            + "\\"
            + os.path.join("tests")
            + "\\"
            + os.path.join("data")
            + r"\test.txt",
            "r",
        ) as f:
            file_data = f.read()
        request_object1 = PutFileRequest(
            file=file_data,
            filepath=path,
            description="lorem test3",
            entity_id=FILE_ENTITY_ID,
            type="txt",
            timestamp="2018-09-10T05:03:42.363Z",
        )
        # put Api call
        self.client.put_file(request_object1)
        request_object2 = GetIOTFileRequest(filepath=path, entity_id=FILE_ENTITY_ID)
        # get Api call
        self.client.get_file(request_object2)
        print("path : " + path)
        request_object3 = DeleteFileRequest(filepath=path, entity_id=FILE_ENTITY_ID)
        # delete Api call
        self.client.delete_file(request_object3)

    def test_should_throw_exception_for_null_entity_id_for_delete_file(self):
        with self.assertRaises(MindsphereError):
            request_object = DeleteFileRequest(filepath="integ1234", entity_id=None)
            # delete Api call
            self.client.delete_file(request_object)

    def test_should_throw_exception_for_invalid_path_for_delete_file(self):
        with self.assertRaises(MindsphereError):
            request_object = DeleteFileRequest(
                filepath="ing1234", entity_id=FILE_ENTITY_ID
            )
            # delete Api call
            self.client.delete_file(request_object)

    def test_integration(self):
        path = FILE_PATH_NAME + str(self.get_random_number())
        with open(
            os.path.dirname(os.path.abspath(__file__ + "/../.."))
            + "\\"
            + os.path.join("tests")
            + "\\"
            + os.path.join("data")
            + r"\test.txt",
            "r",
        ) as f:
            file_data = f.read()
        request_object1 = PutFileRequest(
            file=file_data,
            if_match=None,
            filepath=path,
            upload=None,
            part=None,
            description="lorem test3",
            entity_id=FILE_ENTITY_ID,
            type="txt",
            timestamp="2018-09-10T05:03:42.363Z",
        )
        # put Api call
        self.client.put_file(request_object1)
        request_object2 = GetIOTFileRequest(
            if_none_match=None, filepath=path, range=None, entity_id=FILE_ENTITY_ID
        )
        # get Api call
        self.client.get_file(request_object2)
        request_object3 = SearchFilesRequest(
            filter="path eq '" + path + "'",
            offset=None,
            limit=None,
            count=None,
            entity_id=FILE_ENTITY_ID,
            order=None,
        )
        # search Api call
        self.client.search_files(request_object3)
        request_object4 = DeleteFileRequest(filepath=path, entity_id=FILE_ENTITY_ID)
        # delete Api call
        self.client.delete_file(request_object4)

    def test_create_multi_part(self):
        path = FILE_PATH_NAME + str(self.get_random_number())
        # Initialising file
        request_object = PutFileRequest(
            file=None,
            entity_id=FILE_ENTITY_ID,
            filepath=path,
            description="trial",
            timestamp="2018-09-10T05:03:42.363Z",
            type="txt",
        )
        self.client.initiate_multi_part_upload(request_object=request_object)

        with open(
            os.path.dirname(os.path.abspath(__file__ + "/../.."))
            + "\\"
            + os.path.join("tests")
            + "\\"
            + os.path.join("data")
            + r"\filepart1.txt",
            "r",
        ) as f:
            file_part1 = f.read().splitlines()

        request_object.file = file_part1
        request_object.part = 1
        self.client.create_multi_part_file(request_object)

        with open(
            os.path.dirname(os.path.abspath(__file__ + "/../.."))
            + "\\"
            + os.path.join("tests")
            + "\\"
            + os.path.join("data")
            + r"\filepart2.txt",
            "r",
        ) as f:
            file_part2 = f.read().splitlines()
        request_object.file = file_part2
        request_object.part = 2
        self.client.create_multi_part_file(request_object)

        request_object2 = GetFileListRequest(filepath=path, entity_id=FILE_ENTITY_ID)
        file_parts = self.client.get_file_list(request_object2)
        print(file_parts)
        self.client.complete_multi_part_upload(request_object)
        # upload is completed

        print(path)

    def test_should_throw_exception_for_file_not_found_error_in_create_multi_part(self):
        with self.assertRaises(FileNotFoundError):
            path = FILE_PATH_NAME + str(self.get_random_number())
            request_object1 = PutFileRequest(
                file=None,
                entity_id=FILE_ENTITY_ID,
                filepath=path,
                description="trial",
                timestamp="2018-09-10T05:03:42.363Z",
                type="txt",
                upload="start",
            )
            self.client.initiate_multi_part_upload(request_object1)
            # uploading file part 1
            with open(
                os.path.dirname(os.path.abspath(__file__ + "/../.."))
                + "\\"
                + os.path.join("tests")
                + "\\"
                + os.path.join("data")
                + r"\invalid.txt",
                "r",
            ) as f:
                file_part1 = f.read().splitlines()
            request_object2 = PutFileRequest(
                file=file_part1,
                entity_id=FILE_ENTITY_ID,
                filepath=path,
                description="trial",
                timestamp="2018-09-10T05:03:42.363Z",
                type="txt",
                part=1,
            )
            self.client.create_multi_part_file(request_object2)

    def test_should_throw_exception_not_initialised_file_error_in_create_multi_part(
        self
    ):
        with self.assertRaises(MindsphereError):
            path = FILE_PATH_NAME + str(self.get_random_number())
            # uploading file part 1
            with open(
                os.path.dirname(os.path.abspath(__file__ + "/../.."))
                + "\\"
                + os.path.join("tests")
                + "\\"
                + os.path.join("data")
                + r"\filepart1.txt",
                "r",
            ) as f:
                file_part1 = f.read().splitlines()
            request_object = PutFileRequest(
                file=file_part1,
                entity_id=FILE_ENTITY_ID,
                filepath=path,
                description="trial",
                timestamp="2018-09-10T05:03:42.363Z",
                type="txt",
                part=1,
            )
            self.client.create_multi_part_file(request_object)

    def test_should_throw_exception_for_invalid_path_filelist(self):
        with self.assertRaises(MindsphereError):
            request_object = GetFileListRequest(
                filepath="invalid", entity_id=FILE_ENTITY_ID
            )
            self.client.get_file_list(request_object)

    def test_should_throw_exception_for_invalid_entity_filelist(self):
        with self.assertRaises(MindsphereError):
            path = "Integ15806"
            request_object = GetFileListRequest(filepath=path, entity_id="invalid")
            self.client.get_file_list(request_object)

    def test_update_multi_part(self):
        # Initializing file
        path = FILE_PATH_NAME + str(self.get_random_number())
        request_object = PutFileRequest(
            file=None,
            entity_id=FILE_ENTITY_ID,
            filepath=path,
            description="trial",
            timestamp="2018-09-10T05:03:42.363Z",
            type="txt",
        )
        self.client.initiate_multi_part_upload(request_object)

        # uploading file part 1
        with open(
            os.path.dirname(os.path.abspath(__file__ + "/../.."))
            + "\\"
            + os.path.join("tests")
            + "\\"
            + os.path.join("data")
            + r"\filepart1.txt",
            "r",
        ) as f:
            file_part1 = f.read().splitlines()
        request_object.file = file_part1
        request_object.part = 1
        self.client.create_multi_part_file(request_object)

        # uploading file part 2
        with open(
            os.path.dirname(os.path.abspath(__file__ + "/../.."))
            + "\\"
            + os.path.join("tests")
            + "\\"
            + os.path.join("data")
            + r"\filepart2.txt",
            "r",
        ) as f:
            file_part2 = f.read().splitlines()
        request_object.file = file_part2
        request_object.part = 2
        self.client.create_multi_part_file(request_object)

        # uploading file part 3
        with open(
            os.path.dirname(os.path.abspath(__file__ + "/../.."))
            + "\\"
            + os.path.join("tests")
            + "\\"
            + os.path.join("data")
            + r"\filepart3.txt",
            "r",
        ) as f:
            file_part3 = f.read().splitlines()
        request_object.file = file_part3
        request_object.part = 3
        self.client.create_multi_part_file(request_object)

        # uploading file part 4
        with open(
            os.path.dirname(os.path.abspath(__file__ + "/../.."))
            + "\\"
            + os.path.join("tests")
            + "\\"
            + os.path.join("data")
            + r"\filepart4.txt",
            "r",
        ) as f:
            file_part4 = f.read().splitlines()
        request_object.file = file_part4
        request_object.part = 4
        self.client.create_multi_part_file(request_object)

        request_object1 = GetFileListRequest(filepath=path, entity_id=FILE_ENTITY_ID)
        self.client.get_file_list(request_object1)
        self.client.complete_multi_part_upload(request_object)
        # upload completed

        # Re-Initializing file
        request_object2 = PutFileRequest(
            file=None,
            entity_id=FILE_ENTITY_ID,
            filepath=path,
            description="unity test book",
            timestamp="2018-09-10T05:03:42.363Z",
            type="txt",
            if_match="0",
        )
        self.client.initiate_multi_part_upload(request_object2)
        # uploading file part 1
        with open(
            os.path.dirname(os.path.abspath(__file__ + "/../.."))
            + "\\"
            + os.path.join("tests")
            + "\\"
            + os.path.join("data")
            + r"\filepart1.txt",
            "r",
        ) as f:
            file_part1 = f.read().splitlines()
        request_object3 = PutFileRequest(
            file=file_part1,
            entity_id=FILE_ENTITY_ID,
            filepath=path,
            part=1,
            description="unity test book",
            timestamp="2018-09-10T05:03:42.363Z",
            type="txt",
            if_match="0",
        )
        self.client.update_multi_part_file(request_object3)
        # uploading file part 2
        with open(
            os.path.dirname(os.path.abspath(__file__ + "/../.."))
            + "\\"
            + os.path.join("tests")
            + "\\"
            + os.path.join("data")
            + r"\filepart2.txt",
            "r",
        ) as f:
            file_part2 = f.read().splitlines()
        request_object3.file = file_part2
        request_object3.part = 2
        self.client.update_multi_part_file(request_object3)
        # uploading file part 3
        with open(
            os.path.dirname(os.path.abspath(__file__ + "/../.."))
            + "\\"
            + os.path.join("tests")
            + "\\"
            + os.path.join("data")
            + r"\filepart3.txt",
            "r",
        ) as f:
            file_part3 = f.read().splitlines()
        request_object3.file = file_part3
        request_object3.part = 3
        self.client.update_multi_part_file(request_object3)
        # uploading file part 4
        with open(
            os.path.dirname(os.path.abspath(__file__ + "/../.."))
            + "\\"
            + os.path.join("tests")
            + "\\"
            + os.path.join("data")
            + r"\filepart4.txt",
            "r",
        ) as f:
            file_part4 = f.read().splitlines()
        request_object3.file = file_part4
        request_object3.part = 4
        self.client.update_multi_part_file(request_object3)
        # updated the file
        request_object3.file = None
        self.client.complete_multi_part_upload(request_object3)
        print(path)

    def test_update_multi_part_upload_for_abort(self):
        path = FILE_PATH_NAME + str(self.get_random_number())
        with open(
            os.path.dirname(os.path.abspath(__file__ + "/../.."))
            + "\\"
            + os.path.join("tests")
            + "\\"
            + os.path.join("data")
            + r"\filepart1.txt",
            "r",
        ) as f:
            file_part1 = f.read().splitlines()
        request_object = PutFileRequest(
            file=None,
            entity_id=FILE_ENTITY_ID,
            filepath=path,
            description="trial",
            timestamp="2018-09-10T05:03:42.363Z",
            type="txt",
        )
        self.client.initiate_multi_part_upload(request_object)
        request_object.part = 1
        request_object.file = file_part1
        self.client.create_multi_part_file(request_object)

        with open(
            os.path.dirname(os.path.abspath(__file__ + "/../.."))
            + "\\"
            + os.path.join("tests")
            + "\\"
            + os.path.join("data")
            + r"\filepart2.txt",
            "r",
        ) as f:
            file_part2 = f.read().splitlines()
        request_object.file = file_part2
        request_object.part = 2
        self.client.create_multi_part_file(request_object)

        request_object1 = GetFileListRequest(filepath=path, entity_id=FILE_ENTITY_ID)
        file_parts1 = self.client.get_file_list(request_object1)
        self.assertIsNotNone(file_parts1)
        self.client.complete_multi_part_upload(request_object)

        request_object.if_match = 0
        self.client.initiate_multi_part_upload(request_object)
        request_object.part = 1
        request_object.file = file_part1
        request_object.if_match = 0
        self.client.update_multi_part_file(request_object)
        request_object.file = file_part2
        request_object.part = 2
        request_object.if_match = 0
        self.client.update_multi_part_file(request_object)

        request_object2 = GetFileListRequest(filepath=path, entity_id=FILE_ENTITY_ID)
        file_parts2 = self.client.get_file_list(request_object2)
        self.assertIsNotNone(file_parts2)

        request_object.if_match = 0
        self.client.abort_multi_part_upload(request_object)

        # retry
        request_object.if_match = 0
        self.client.initiate_multi_part_upload(request_object)
        request_object.part = 1
        request_object.file = file_part1
        request_object.if_match = 0
        self.client.update_multi_part_file(request_object)
        request_object.file = file_part2
        request_object.part = 2
        request_object.if_match = 0
        self.client.update_multi_part_file(request_object)

        request_object3 = GetFileListRequest(filepath=path, entity_id=FILE_ENTITY_ID)
        file_parts3 = self.client.get_file_list(request_object3)
        self.assertIsNotNone(file_parts3)

        request_object.if_match = 0
        self.client.complete_multi_part_upload(request_object)

    def test_should_throw_exception_for_uploading_file_already_in_progress_in_update_multi_part(
        self
    ):
        with self.assertRaises(MindsphereError):
            path = "Integ15806"
            request_object = PutFileRequest(
                file=None,
                entity_id=FILE_ENTITY_ID,
                filepath=path,
                if_match=1,
                description="unity test book",
                timestamp="2017-07-13T01:00:00.00Z",
                type="txt",
            )
            self.client.initiate_multi_part_upload(request_object)
            # uploading file part 1
            with open(
                os.path.dirname(os.path.abspath(__file__ + "/../.."))
                + "\\"
                + os.path.join("tests")
                + "\\"
                + os.path.join("data")
                + r"\filepart1.txt",
                "r",
            ) as f:
                file_part1 = f.read().splitlines()
            request_object1 = PutFileRequest(
                file=file_part1,
                entity_id=FILE_ENTITY_ID,
                filepath=path,
                if_match=1,
                description="unity test book",
                timestamp="2017-07-13T01:00:00.00Z",
                type="txt",
                part=1,
            )
            self.client.update_multi_part_file(request_object1)

    def test_should_throw_exception_not_initialised_file_error_in_update_multi_part(
        self
    ):
        with self.assertRaises(MindsphereError):
            path = "Integ1580606"
            # uploading file part 1
            with open(
                os.path.dirname(os.path.abspath(__file__ + "/../.."))
                + "\\"
                + os.path.join("tests")
                + "\\"
                + os.path.join("data")
                + r"\filepart1.txt",
                "r",
            ) as f:
                file_part1 = f.read().splitlines()
            request_object = PutFileRequest(
                file=file_part1,
                entity_id=FILE_ENTITY_ID,
                filepath=path,
                if_match=1,
                description="unity test book",
                timestamp="2017-07-13T01:00:00.00Z",
                type="txt",
                part=1,
            )
            self.client.update_multi_part_file(request_object)

    def test_should_throw_exception_with_path_as_none(self):
        with self.assertRaises(MindsphereError):
            request_object = PutFileRequest(
                file=None,
                entity_id=FILE_ENTITY_ID,
                filepath=None,
                description="trial",
                timestamp="2018-09-10T05:03:42.363Z",
                type="txt",
            )
            self.client.initiate_multi_part_upload(request_object)

    def test_should_throw_exception_with_file_less_than_5mb(self):
        with self.assertRaises(MindsphereError):
            path = FILE_PATH_NAME + str(self.get_random_number())
            with open(
                os.path.dirname(os.path.abspath(__file__ + "/../.."))
                + "\\"
                + os.path.join("tests")
                + "\\"
                + os.path.join("data")
                + r"\test.txt",
                "r",
            ) as f:
                test = f.read().splitlines()
            request_object = PutFileRequest(
                file=None,
                entity_id=FILE_ENTITY_ID,
                filepath=path,
                description="trial",
                timestamp="2018-09-10T05:03:42.363Z",
                type="txt",
            )
            self.client.initiate_multi_part_upload(request_object)
            request_object.part = 1
            request_object.file = test
            self.client.create_multi_part_file(request_object)

    def test_integration_for_request_model(self):
        path = FILE_PATH_NAME + str(self.get_random_number())
        with open(
            os.path.dirname(os.path.abspath(__file__ + "/../.."))
            + "\\"
            + os.path.join("tests")
            + "\\"
            + os.path.join("data")
            + r"\test.txt",
            "r",
        ) as f:
            test = f.read().splitlines()
        request_object1 = PutFileRequest(
            file=test,
            entity_id=FILE_ENTITY_ID,
            filepath=path,
            description="lorem test3",
            timestamp="2018-09-10T05:03:42.363Z",
            type="txt",
        )
        self.client.put_file(request_object1)
        request_object2 = GetIOTFileRequest(
            filepath=path, range=None, entity_id=FILE_ENTITY_ID
        )
        # get Api call
        get_file_response = self.client.get_file(request_object2)
        self.assertIsNotNone(get_file_response)
        request_object3 = SearchFilesRequest(entity_id=FILE_ENTITY_ID)
        # search Api call
        search_response = self.client.search_files(request_object3)
        self.assertIsNotNone(search_response)
        request_object4 = DeleteFileRequest(filepath=path, entity_id=FILE_ENTITY_ID)
        # delete Api call
        self.client.delete_file(request_object4)

    @staticmethod
    def get_random_number():
        return random.randint(1000, 9000) + 10000


if __name__ == "__main__":
    unittest.main()
