# coding: utf-8

"""
    Event Analytics API

    Provides the essential functionality for a data-driven analysis of the event data.  # noqa: E501
"""


from __future__ import absolute_import

from mindsphere_core.mindsphere_core import logger
from mindsphere_core import mindsphere_core, exceptions, token_service
from mindsphere_core.token_service import init_credentials


class EventOperationsClient:
    __base_path__ = '/api/eventanalytics/v3'
    __model_package__ = __name__.split('.')[0]

    def __init__(self, rest_client_config=None, mindsphere_credentials=None):
        self.rest_client_config = rest_client_config
        self.mindsphere_credentials = init_credentials(mindsphere_credentials)

    def count_events(self, request_object):
        """Determines the number of events for a required time resolution.

        The microservice takes as an input the entire dataset and the time resolution (example 100ms). The micro service will output the given time interval (startTime, endTime) and the resulted number of event occurrences.

        :param CountEventsRequest request_object: It contains the below parameters --> |br| ( data* - Data structure with two parts   <b>eventsMetadata</b>, <b>events</b>. <ul>   <li> <b>eventsMetadata</b> Metadata for the events list specifying the property name of the item in the events list that contains the text of the event (<b>eventTextPropertyName</b>) and time window  length in miliseconds of the period in which time interval will be split (<b>splitInterval</b>).</li>   <li> <b>events</b> List with the events that will be processed.</li> </ul> )

        :return: EventCountOutput
        """
        logger.info('EventOperationsClient.count_events() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `count_events`')

        if request_object.data is None:
            raise exceptions.MindsphereClientError('The required parameter `data` is missing from `request_object`, when calling `count_events`')

        end_point_url = '/countEvents'
        end_point_url = end_point_url.format()
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + str(token)}
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, request_object.data

        logger.info('EventOperationsClient.count_events()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'POST', query_params, form_params, body_params, local_var_files, 'EventCountOutput', self.__model_package__)

    def filter_events(self, request_object):
        """Simplifies the dataset to the most meaningful data

        Filtering the dataset based on the text of the event

        :param FilterEventsRequest request_object: It contains the below parameters --> |br| ( data* - Data structure with three parts - <b>eventsMetadata</b>, <b>filterList</b>, and <b>events</b>.<ul>   <li> <b>eventsMetadata</b> Metadata for the events list specifying the property name of the item in the events list that contains the text of the event. </li>   <li> <b>filterList</b> Types of events to be removed </li>   <li> <b>events</b> List with the events that will be processed.</li> </ul> )

        :return: EventArrayOutput
        """
        logger.info('EventOperationsClient.filter_events() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `filter_events`')

        if request_object.data is None:
            raise exceptions.MindsphereClientError('The required parameter `data` is missing from `request_object`, when calling `filter_events`')

        end_point_url = '/filterEvents'
        end_point_url = end_point_url.format()
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + str(token)}
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, request_object.data

        logger.info('EventOperationsClient.filter_events()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'POST', query_params, form_params, body_params, local_var_files, 'EventArrayOutput', self.__model_package__)

    def remove_duplicate_events(self, request_object):
        """Removes the duplicate events

        Determine pre-existing relationships between events for a requested temporal resolution (example 500ms) and reduce the data set by aggregating events with duplicate value.

        :param RemoveDuplicateEventsRequest request_object: It contains the below parameters --> |br| ( data* - Data structure with two parts   <b>eventsMetadata</b>, <b>events</b>. <ul>  <li> <b>eventsMetadata</b> Metadata for the events list specifying the property name of the item in the events list that contains the text  of the event (<b>eventTextPropertyName</b>) and time window length in  miliseconds of the period in which time interval will be split  (<b>splitInterval</b>). </li>   <li> <b>events</b> List with the events that will be processed.</li> </ul> )

        :return: DuplicateEventArrayOutput
        """
        logger.info('EventOperationsClient.remove_duplicate_events() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `remove_duplicate_events`')

        if request_object.data is None:
            raise exceptions.MindsphereClientError('The required parameter `data` is missing from `request_object`, when calling `remove_duplicate_events`')

        end_point_url = '/removeDuplicateEvents'
        end_point_url = end_point_url.format()
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + str(token)}
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, request_object.data

        logger.info('EventOperationsClient.remove_duplicate_events()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'POST', query_params, form_params, body_params, local_var_files, 'DuplicateEventArrayOutput', self.__model_package__)

    def top_events(self, request_object):
        """Find most frequent top N events

        Finds the most frequent events, which are sorted by the number of appearances in a dataset in a descending order.

        :param TopEventsRequest request_object: It contains the below parameters --> |br| ( data* - Data structure with three parts - <b>numberOfTopPositionsRequired</b>, <b>eventsMetadata</b>, and <b>events</b>. <ul>   <li> <b>numberOfTopPositionsRequired</b> How many top positions will be returned in the response. Has to be a positive integer. If not specified, the default value 10 will be used.</li>   <li> <b>eventsMetadata</b> Metadata for the events list specifying the property name of the item in the events list that contains the text of the event.</li>   <li> <b>events</b> List with the events that will be processed.</li> </ul> )

        :return: TopEventOutput
        """
        logger.info('EventOperationsClient.top_events() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `top_events`')

        if request_object.data is None:
            raise exceptions.MindsphereClientError('The required parameter `data` is missing from `request_object`, when calling `top_events`')

        end_point_url = '/findTopEvents'
        end_point_url = end_point_url.format()
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + str(token)}
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, request_object.data

        logger.info('EventOperationsClient.top_events()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'POST', query_params, form_params, body_params, local_var_files, 'TopEventOutput', self.__model_package__)

