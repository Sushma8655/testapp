# coding: utf-8

"""
    Event Analytics API

    Provides the essential functionality for a data-driven analysis of the event data.  # noqa: E501
"""


from __future__ import absolute_import

from mindsphere_core.mindsphere_core import logger
from mindsphere_core import mindsphere_core, exceptions, token_service
from mindsphere_core.token_service import init_credentials


class PatternOperationsClient:
    __base_path__ = '/api/eventanalytics/v3'
    __model_package__ = __name__.split('.')[0]

    def __init__(self, rest_client_config=None, mindsphere_credentials=None):
        self.rest_client_config = rest_client_config
        self.mindsphere_credentials = init_credentials(mindsphere_credentials)

    def match_patterns_over_events(self, request_object):
        """Applies the patterns specified in body on a list of events

        Finds all instances of the specified pattern(s) in a collection of events.

        :param MatchPatternsOverEventsRequest request_object: It contains the below parameters --> |br| ( data* - Data structure with four parts - <b>maxPatternInterval</b>, <b>patternsList</b>, <b>nonEvents</b> and <b>eventsInput</b>. <ul>   <li><b>maxPatternInterval </b> The maximum time length (in milliseconds) of the sliding window where the pattern occurs (Maximum difference allowed between the first event of the pattern and the last one). </li>   <li> <b>patternsList</b> The patterns to be found in events. The <b>eventText</b> can contain <b>regular expressions</b>. The acceptable syntax for the regular expressions is the java syntax.   <b>minRepetitions</b> and <b>maxRepetitions</b> represent the minimum and maximum number of events of the specified type that are allowed to occur in order for the pattern to be matched on the events.</li>   <li> <b>nonEvents</b> A list of events that is not allowed to be part of a pattern. Any pattern which contains a non-event is excluded from the final report.</li>   <li> <b>eventsInput</b> Metadata for the events list specifying the property name of the item in the events list that contains the text of the event and the list with the events that will be processed.</li> </ul> )

        :return: PatternMatchingOutput
        """
        logger.info('PatternOperationsClient.match_patterns_over_events() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `match_patterns_over_events`')

        if request_object.data is None:
            raise exceptions.MindsphereClientError('The required parameter `data` is missing from `request_object`, when calling `match_patterns_over_events`')

        end_point_url = '/matchEventPatterns'
        end_point_url = end_point_url.format()
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + str(token)}
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, request_object.data

        logger.info('PatternOperationsClient.match_patterns_over_events()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'POST', query_params, form_params, body_params, local_var_files, 'PatternMatchingOutput', self.__model_package__)

