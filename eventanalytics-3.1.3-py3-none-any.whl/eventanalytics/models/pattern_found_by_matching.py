# coding: utf-8

"""
    Event Analytics API

    Provides the essential functionality for a data-driven analysis of the event data.  # noqa: E501
"""


import pprint
import re
import six

from eventanalytics.models.event import Event
from eventanalytics.models.matching_pattern import MatchingPattern
from mindsphere_core.exceptions import MindsphereClientError


class PatternFoundByMatching(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'pattern_index': 'int',
        'time_window': 'object',
        'pattern': 'list[MatchingPattern]',
        'matched_events': 'list[Event]'
    }

    attribute_map = {
        'pattern_index': 'patternIndex',
        'time_window': 'timeWindow',
        'pattern': 'pattern',
        'matched_events': 'matchedEvents'
    }

    def __init__(self, pattern_index=None, time_window=None, pattern=None, matched_events=None):
        self._pattern_index = pattern_index
        self._time_window = time_window
        self._pattern = pattern
        self._matched_events = matched_events
        self.discriminator = None

    @property
    def pattern_index(self):
        """Gets the pattern_index of this PatternFoundByMatching.
        The index of the pattern based on request object

        :return: The pattern_index of this PatternFoundByMatching.
        :rtype: int
        """
        return self._pattern_index

    @pattern_index.setter
    def pattern_index(self, pattern_index):
        """Sets the pattern_index of this PatternFoundByMatching.
        The index of the pattern based on request object

        :param pattern_index: The pattern_index of this PatternFoundByMatching.
        :type: int
        """

        self._pattern_index = pattern_index

    @property
    def time_window(self):
        """Gets the time_window of this PatternFoundByMatching.

        :return: The time_window of this PatternFoundByMatching.
        :rtype: object
        """
        return self._time_window

    @time_window.setter
    def time_window(self, time_window):
        """Sets the time_window of this PatternFoundByMatching.

        :param time_window: The time_window of this PatternFoundByMatching.
        :type: object
        """

        self._time_window = time_window

    @property
    def pattern(self):
        """Gets the pattern of this PatternFoundByMatching.

        :return: The pattern of this PatternFoundByMatching.
        :rtype: list[MatchingPattern]
        """
        return self._pattern

    @pattern.setter
    def pattern(self, pattern):
        """Sets the pattern of this PatternFoundByMatching.

        :param pattern: The pattern of this PatternFoundByMatching.
        :type: list[MatchingPattern]
        """

        self._pattern = pattern

    @property
    def matched_events(self):
        """Gets the matched_events of this PatternFoundByMatching.

        :return: The matched_events of this PatternFoundByMatching.
        :rtype: list[Event]
        """
        return self._matched_events

    @matched_events.setter
    def matched_events(self, matched_events):
        """Sets the matched_events of this PatternFoundByMatching.

        :param matched_events: The matched_events of this PatternFoundByMatching.
        :type: list[Event]
        """

        self._matched_events = matched_events

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(PatternFoundByMatching, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, PatternFoundByMatching):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
