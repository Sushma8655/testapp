# coding: utf-8

"""
    Event Analytics API

    Provides the essential functionality for a data-driven analysis of the event data.  # noqa: E501
"""


import pprint
import re
import six

from eventanalytics.models.event import Event
from eventanalytics.models.events_input_model import EventsInputModel
from eventanalytics.models.events_input_model_events_metadata import EventsInputModelEventsMetadata
from mindsphere_core.exceptions import MindsphereClientError


class TopEventsInputDataModel(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'events_metadata': 'EventsInputModelEventsMetadata',
        'events': 'list[Event]',
        'number_of_top_positions_required': 'int'
    }

    attribute_map = {
        'events_metadata': 'eventsMetadata',
        'events': 'events',
        'number_of_top_positions_required': 'numberOfTopPositionsRequired'
    }

    def __init__(self, events_metadata=None, events=None, number_of_top_positions_required=10):
        self._events_metadata = events_metadata
        self._events = events
        self._number_of_top_positions_required = number_of_top_positions_required
        self.discriminator = None

    @property
    def events_metadata(self):
        """Gets the events_metadata of this TopEventsInputDataModel.

        :return: The events_metadata of this TopEventsInputDataModel.
        :rtype: EventsInputModelEventsMetadata
        """
        return self._events_metadata

    @events_metadata.setter
    def events_metadata(self, events_metadata):
        """Sets the events_metadata of this TopEventsInputDataModel.

        :param events_metadata: The events_metadata of this TopEventsInputDataModel.
        :type: EventsInputModelEventsMetadata
        """
        if events_metadata is None:
            raise MindsphereClientError("Invalid value for `events_metadata`, must not be `None`")

        self._events_metadata = events_metadata

    @property
    def events(self):
        """Gets the events of this TopEventsInputDataModel.

        :return: The events of this TopEventsInputDataModel.
        :rtype: list[Event]
        """
        return self._events

    @events.setter
    def events(self, events):
        """Sets the events of this TopEventsInputDataModel.

        :param events: The events of this TopEventsInputDataModel.
        :type: list[Event]
        """
        if events is None:
            raise MindsphereClientError("Invalid value for `events`, must not be `None`")

        self._events = events

    @property
    def number_of_top_positions_required(self):
        """Gets the number_of_top_positions_required of this TopEventsInputDataModel.
        How many top positions will be returned in the response. Has to be a positive integer. If not specified, the default value 10 will be used.

        :return: The number_of_top_positions_required of this TopEventsInputDataModel.
        :rtype: int
        """
        return self._number_of_top_positions_required

    @number_of_top_positions_required.setter
    def number_of_top_positions_required(self, number_of_top_positions_required):
        """Sets the number_of_top_positions_required of this TopEventsInputDataModel.
        How many top positions will be returned in the response. Has to be a positive integer. If not specified, the default value 10 will be used.

        :param number_of_top_positions_required: The number_of_top_positions_required of this TopEventsInputDataModel.
        :type: int
        """
        if number_of_top_positions_required is not None and number_of_top_positions_required < 1:
            raise MindsphereClientError("Invalid value for `number_of_top_positions_required`, must be a value greater than or equal to `1`")

        self._number_of_top_positions_required = number_of_top_positions_required

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(TopEventsInputDataModel, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, TopEventsInputDataModel):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
