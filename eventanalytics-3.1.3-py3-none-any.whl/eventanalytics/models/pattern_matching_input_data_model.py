# coding: utf-8

"""
    Event Analytics API

    Provides the essential functionality for a data-driven analysis of the event data.  # noqa: E501
"""


import pprint
import re
import six

from eventanalytics.models.events_input_model import EventsInputModel
from eventanalytics.models.pattern_definition import PatternDefinition
from mindsphere_core.exceptions import MindsphereClientError


class PatternMatchingInputDataModel(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'max_pattern_interval': 'int',
        'patterns_list': 'list[PatternDefinition]',
        'non_events': 'list[str]',
        'events_input': 'EventsInputModel'
    }

    attribute_map = {
        'max_pattern_interval': 'maxPatternInterval',
        'patterns_list': 'patternsList',
        'non_events': 'nonEvents',
        'events_input': 'eventsInput'
    }

    def __init__(self, max_pattern_interval=None, patterns_list=None, non_events=None, events_input=None):
        self._max_pattern_interval = max_pattern_interval
        self._patterns_list = patterns_list
        self._non_events = non_events
        self._events_input = events_input
        self.discriminator = None

    @property
    def max_pattern_interval(self):
        """Gets the max_pattern_interval of this PatternMatchingInputDataModel.
        The maximum time length (in milliseconds) of the sliding window where the pattern occurs

        :return: The max_pattern_interval of this PatternMatchingInputDataModel.
        :rtype: int
        """
        return self._max_pattern_interval

    @max_pattern_interval.setter
    def max_pattern_interval(self, max_pattern_interval):
        """Sets the max_pattern_interval of this PatternMatchingInputDataModel.
        The maximum time length (in milliseconds) of the sliding window where the pattern occurs

        :param max_pattern_interval: The max_pattern_interval of this PatternMatchingInputDataModel.
        :type: int
        """

        self._max_pattern_interval = max_pattern_interval

    @property
    def patterns_list(self):
        """Gets the patterns_list of this PatternMatchingInputDataModel.

        :return: The patterns_list of this PatternMatchingInputDataModel.
        :rtype: list[PatternDefinition]
        """
        return self._patterns_list

    @patterns_list.setter
    def patterns_list(self, patterns_list):
        """Sets the patterns_list of this PatternMatchingInputDataModel.

        :param patterns_list: The patterns_list of this PatternMatchingInputDataModel.
        :type: list[PatternDefinition]
        """

        self._patterns_list = patterns_list

    @property
    def non_events(self):
        """Gets the non_events of this PatternMatchingInputDataModel.
        List of events which will be removed from the input list

        :return: The non_events of this PatternMatchingInputDataModel.
        :rtype: list[str]
        """
        return self._non_events

    @non_events.setter
    def non_events(self, non_events):
        """Sets the non_events of this PatternMatchingInputDataModel.
        List of events which will be removed from the input list

        :param non_events: The non_events of this PatternMatchingInputDataModel.
        :type: list[str]
        """

        self._non_events = non_events

    @property
    def events_input(self):
        """Gets the events_input of this PatternMatchingInputDataModel.

        :return: The events_input of this PatternMatchingInputDataModel.
        :rtype: EventsInputModel
        """
        return self._events_input

    @events_input.setter
    def events_input(self, events_input):
        """Sets the events_input of this PatternMatchingInputDataModel.

        :param events_input: The events_input of this PatternMatchingInputDataModel.
        :type: EventsInputModel
        """

        self._events_input = events_input

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(PatternMatchingInputDataModel, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, PatternMatchingInputDataModel):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
