# coding: utf-8

"""
    Event Analytics API

    Provides the essential functionality for a data-driven analysis of the event data.  # noqa: E501
"""


import pprint
import re
import six

from eventanalytics.models.matching_pattern import MatchingPattern
from mindsphere_core.exceptions import MindsphereClientError


class PatternDefinition(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'folder_id': 'str',
        'file_id': 'str',
        'pattern_id': 'str',
        'pattern': 'list[MatchingPattern]'
    }

    attribute_map = {
        'folder_id': 'folderId',
        'file_id': 'fileId',
        'pattern_id': 'patternId',
        'pattern': 'pattern'
    }

    def __init__(self, folder_id=None, file_id=None, pattern_id=None, pattern=None):
        self._folder_id = folder_id
        self._file_id = file_id
        self._pattern_id = pattern_id
        self._pattern = pattern
        self.discriminator = None

    @property
    def folder_id(self):
        """Gets the folder_id of this PatternDefinition.
        The id used to reference the folder where the file with the pattern is stored.

        :return: The folder_id of this PatternDefinition.
        :rtype: str
        """
        return self._folder_id

    @folder_id.setter
    def folder_id(self, folder_id):
        """Sets the folder_id of this PatternDefinition.
        The id used to reference the folder where the file with the pattern is stored.

        :param folder_id: The folder_id of this PatternDefinition.
        :type: str
        """

        self._folder_id = folder_id

    @property
    def file_id(self):
        """Gets the file_id of this PatternDefinition.
        The id used to reference the file where the pattern is stored.

        :return: The file_id of this PatternDefinition.
        :rtype: str
        """
        return self._file_id

    @file_id.setter
    def file_id(self, file_id):
        """Sets the file_id of this PatternDefinition.
        The id used to reference the file where the pattern is stored.

        :param file_id: The file_id of this PatternDefinition.
        :type: str
        """

        self._file_id = file_id

    @property
    def pattern_id(self):
        """Gets the pattern_id of this PatternDefinition.
        The id used to reference a specific pattern. It is unique inside this collection.

        :return: The pattern_id of this PatternDefinition.
        :rtype: str
        """
        return self._pattern_id

    @pattern_id.setter
    def pattern_id(self, pattern_id):
        """Sets the pattern_id of this PatternDefinition.
        The id used to reference a specific pattern. It is unique inside this collection.

        :param pattern_id: The pattern_id of this PatternDefinition.
        :type: str
        """

        self._pattern_id = pattern_id

    @property
    def pattern(self):
        """Gets the pattern of this PatternDefinition.

        :return: The pattern of this PatternDefinition.
        :rtype: list[MatchingPattern]
        """
        return self._pattern

    @pattern.setter
    def pattern(self, pattern):
        """Sets the pattern of this PatternDefinition.

        :param pattern: The pattern of this PatternDefinition.
        :type: list[MatchingPattern]
        """

        self._pattern = pattern

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(PatternDefinition, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, PatternDefinition):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
