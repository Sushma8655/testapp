# coding: utf-8

"""
    Event Analytics API

    Provides the essential functionality for a data-driven analysis of the event data.  # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class MatchingPattern(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'event_text': 'str',
        'min_repetitions': 'int',
        'max_repetitions': 'int'
    }

    attribute_map = {
        'event_text': 'eventText',
        'min_repetitions': 'minRepetitions',
        'max_repetitions': 'maxRepetitions'
    }

    def __init__(self, event_text=None, min_repetitions=None, max_repetitions=None):
        self._event_text = event_text
        self._min_repetitions = min_repetitions
        self._max_repetitions = max_repetitions
        self.discriminator = None

    @property
    def event_text(self):
        """Gets the event_text of this MatchingPattern.
        Event identifier.

        :return: The event_text of this MatchingPattern.
        :rtype: str
        """
        return self._event_text

    @event_text.setter
    def event_text(self, event_text):
        """Sets the event_text of this MatchingPattern.
        Event identifier.

        :param event_text: The event_text of this MatchingPattern.
        :type: str
        """
        if event_text is None:
            raise MindsphereClientError("Invalid value for `event_text`, must not be `None`")

        self._event_text = event_text

    @property
    def min_repetitions(self):
        """Gets the min_repetitions of this MatchingPattern.
        The minimum number of desired repetitions of the event inside the pattern.

        :return: The min_repetitions of this MatchingPattern.
        :rtype: int
        """
        return self._min_repetitions

    @min_repetitions.setter
    def min_repetitions(self, min_repetitions):
        """Sets the min_repetitions of this MatchingPattern.
        The minimum number of desired repetitions of the event inside the pattern.

        :param min_repetitions: The min_repetitions of this MatchingPattern.
        :type: int
        """

        self._min_repetitions = min_repetitions

    @property
    def max_repetitions(self):
        """Gets the max_repetitions of this MatchingPattern.
        The maximum number of desired repetitions of the event inside the pattern.

        :return: The max_repetitions of this MatchingPattern.
        :rtype: int
        """
        return self._max_repetitions

    @max_repetitions.setter
    def max_repetitions(self, max_repetitions):
        """Sets the max_repetitions of this MatchingPattern.
        The maximum number of desired repetitions of the event inside the pattern.

        :param max_repetitions: The max_repetitions of this MatchingPattern.
        :type: int
        """

        self._max_repetitions = max_repetitions

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(MatchingPattern, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, MatchingPattern):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
