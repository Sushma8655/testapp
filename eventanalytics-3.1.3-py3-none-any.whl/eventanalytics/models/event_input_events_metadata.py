# coding: utf-8

"""
    Event Analytics API

    Provides the essential functionality for a data-driven analysis of the event data.  # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class EventInputEventsMetadata(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'event_text_property_name': 'str',
        'split_interval': 'int'
    }

    attribute_map = {
        'event_text_property_name': 'eventTextPropertyName',
        'split_interval': 'splitInterval'
    }

    def __init__(self, event_text_property_name=None, split_interval=None):
        self._event_text_property_name = event_text_property_name
        self._split_interval = split_interval
        self.discriminator = None

    @property
    def event_text_property_name(self):
        """Gets the event_text_property_name of this EventInputEventsMetadata.
        The property name of the events list objects that contains the text of the event

        :return: The event_text_property_name of this EventInputEventsMetadata.
        :rtype: str
        """
        return self._event_text_property_name

    @event_text_property_name.setter
    def event_text_property_name(self, event_text_property_name):
        """Sets the event_text_property_name of this EventInputEventsMetadata.
        The property name of the events list objects that contains the text of the event

        :param event_text_property_name: The event_text_property_name of this EventInputEventsMetadata.
        :type: str
        """

        self._event_text_property_name = event_text_property_name

    @property
    def split_interval(self):
        """Gets the split_interval of this EventInputEventsMetadata.
        The window length represents the value in milliseconds of the period in which user wants to split input interval

        :return: The split_interval of this EventInputEventsMetadata.
        :rtype: int
        """
        return self._split_interval

    @split_interval.setter
    def split_interval(self, split_interval):
        """Sets the split_interval of this EventInputEventsMetadata.
        The window length represents the value in milliseconds of the period in which user wants to split input interval

        :param split_interval: The split_interval of this EventInputEventsMetadata.
        :type: int
        """

        self._split_interval = split_interval

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(EventInputEventsMetadata, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, EventInputEventsMetadata):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
