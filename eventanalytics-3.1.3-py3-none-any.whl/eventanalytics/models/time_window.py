# coding: utf-8

"""
    Event Analytics API

    Provides the essential functionality for a data-driven analysis of the event data.  # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class TimeWindow(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'start_timestamp': 'str',
        'end_timestamp': 'str'
    }

    attribute_map = {
        'start_timestamp': 'startTimestamp',
        'end_timestamp': 'endTimestamp'
    }

    def __init__(self, start_timestamp=None, end_timestamp=None):
        self._start_timestamp = start_timestamp
        self._end_timestamp = end_timestamp
        self.discriminator = None

    @property
    def start_timestamp(self):
        """Gets the start_timestamp of this TimeWindow.
        The start timestamp of the matched pattern.

        :return: The start_timestamp of this TimeWindow.
        :rtype: str
        """
        return self._start_timestamp

    @start_timestamp.setter
    def start_timestamp(self, start_timestamp):
        """Sets the start_timestamp of this TimeWindow.
        The start timestamp of the matched pattern.

        :param start_timestamp: The start_timestamp of this TimeWindow.
        :type: str
        """
        if start_timestamp is None:
            raise MindsphereClientError("Invalid value for `start_timestamp`, must not be `None`")

        self._start_timestamp = start_timestamp

    @property
    def end_timestamp(self):
        """Gets the end_timestamp of this TimeWindow.
        The end timestamp of the matched pattern.

        :return: The end_timestamp of this TimeWindow.
        :rtype: str
        """
        return self._end_timestamp

    @end_timestamp.setter
    def end_timestamp(self, end_timestamp):
        """Sets the end_timestamp of this TimeWindow.
        The end timestamp of the matched pattern.

        :param end_timestamp: The end_timestamp of this TimeWindow.
        :type: str
        """
        if end_timestamp is None:
            raise MindsphereClientError("Invalid value for `end_timestamp`, must not be `None`")

        self._end_timestamp = end_timestamp

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(TimeWindow, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, TimeWindow):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
