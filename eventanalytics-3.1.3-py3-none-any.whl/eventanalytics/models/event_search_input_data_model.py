# coding: utf-8

"""
    Event Analytics API

    Provides the essential functionality for a data-driven analysis of the event data.  # noqa: E501
"""


import pprint
import re
import six

from eventanalytics.models.event import Event
from eventanalytics.models.events_input_model import EventsInputModel
from eventanalytics.models.events_input_model_events_metadata import EventsInputModelEventsMetadata
from mindsphere_core.exceptions import MindsphereClientError


class EventSearchInputDataModel(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'events_metadata': 'EventsInputModelEventsMetadata',
        'events': 'list[Event]',
        'filter_list': 'list[str]'
    }

    attribute_map = {
        'events_metadata': 'eventsMetadata',
        'events': 'events',
        'filter_list': 'filterList'
    }

    def __init__(self, events_metadata=None, events=None, filter_list=None):
        self._events_metadata = events_metadata
        self._events = events
        self._filter_list = filter_list
        self.discriminator = None

    @property
    def events_metadata(self):
        """Gets the events_metadata of this EventSearchInputDataModel.

        :return: The events_metadata of this EventSearchInputDataModel.
        :rtype: EventsInputModelEventsMetadata
        """
        return self._events_metadata

    @events_metadata.setter
    def events_metadata(self, events_metadata):
        """Sets the events_metadata of this EventSearchInputDataModel.

        :param events_metadata: The events_metadata of this EventSearchInputDataModel.
        :type: EventsInputModelEventsMetadata
        """
        if events_metadata is None:
            raise MindsphereClientError("Invalid value for `events_metadata`, must not be `None`")

        self._events_metadata = events_metadata

    @property
    def events(self):
        """Gets the events of this EventSearchInputDataModel.

        :return: The events of this EventSearchInputDataModel.
        :rtype: list[Event]
        """
        return self._events

    @events.setter
    def events(self, events):
        """Sets the events of this EventSearchInputDataModel.

        :param events: The events of this EventSearchInputDataModel.
        :type: list[Event]
        """
        if events is None:
            raise MindsphereClientError("Invalid value for `events`, must not be `None`")

        self._events = events

    @property
    def filter_list(self):
        """Gets the filter_list of this EventSearchInputDataModel.
        List of events which will be removed from the input list

        :return: The filter_list of this EventSearchInputDataModel.
        :rtype: list[str]
        """
        return self._filter_list

    @filter_list.setter
    def filter_list(self, filter_list):
        """Sets the filter_list of this EventSearchInputDataModel.
        List of events which will be removed from the input list

        :param filter_list: The filter_list of this EventSearchInputDataModel.
        :type: list[str]
        """

        self._filter_list = filter_list

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(EventSearchInputDataModel, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, EventSearchInputDataModel):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
