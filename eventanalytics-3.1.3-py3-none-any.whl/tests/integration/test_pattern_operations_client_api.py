import unittest
from mindsphere_core import mindsphere_core, TenantCredentials

from eventanalytics.clients.pattern_operations_client import PatternOperationsClient
from eventanalytics.models import PatternMatchingInputDataModel
from eventanalytics.models import EventsInputModelEventsMetadata
from eventanalytics.models import EventInput
from eventanalytics.models import PatternDefinition
from eventanalytics.models import MatchingPattern
from eventanalytics.models import Event
from eventanalytics.models import MatchPatternsOverEventsRequest
from mindsphere_core.exceptions import MindsphereError
from tests.data.test_data import *


class TestPatternOperation(unittest.TestCase):

    def setUp(self):
        credentials = TenantCredentials(client_id=CLIENT_ID, client_secret=CLIENT_SECRET, tenant=TENANT)
        config = mindsphere_core.RestClientConfig('194.138.0.25', '9400')
        self.client = PatternOperationsClient(config, credentials)

    def test_match_event_pattern_with_sub_tenant(self):
        credentials = TenantCredentials(
            client_id=CLIENT_ID_SUB_TENANT,
            client_secret=CLIENT_SECRET_SUB_TENANT,
            tenant=TENANT,
            sub_tenant=SUB_TENANT,
            use_sub_tenant=True
        )
        config = mindsphere_core.RestClientConfig(proxy_host="194.138.0.25", proxy_port="9400", host_environment="eu1")
        client = PatternOperationsClient(config, credentials)
        patterns_list = self.get_patterns_list()
        metadata = EventsInputModelEventsMetadata('text')
        non_events = ['Error 2.. occurred', 'STOPPING ENGINE']
        events_list = self.get_events_input()
        events_input = EventInput(metadata, events_list)
        data = PatternMatchingInputDataModel(20000, patterns_list, non_events, events_input)
        request_object = MatchPatternsOverEventsRequest(data=data)
        response = client.match_patterns_over_events(request_object)
        self.assertEqual(response.output[0].matched_events[0].text,
                         'Downloading the module database causes module 11 restart')

    def test_match_event_pattern(self):
        patterns_list = self.get_patterns_list()
        metadata = EventsInputModelEventsMetadata('text')
        non_events = ['Error 2.. occurred', 'STOPPING ENGINE']
        events_list = self.get_events_input()
        events_input = EventInput(metadata, events_list)
        data = PatternMatchingInputDataModel(20000, patterns_list, non_events, events_input)
        request_object = MatchPatternsOverEventsRequest(data=data)
        response = self.client.match_patterns_over_events(request_object)
        self.assertEqual(response.output[0].matched_events[0].text,
                         'Downloading the module database causes module 11 restart')

    def test_match_event_pattern_on_missing_pattern_list(self):
        metadata = EventsInputModelEventsMetadata('text')
        non_events = ['Error 2.. occurred', 'STOPPING ENGINE']
        events_list = self.get_events_input()
        events_input = EventInput(metadata, events_list)
        data = PatternMatchingInputDataModel(20000, None, non_events, events_input)
        request_object = MatchPatternsOverEventsRequest(data=data)
        with self.assertRaises(MindsphereError):
            self.client.match_patterns_over_events(request_object)

    def test_match_event_pattern_on_missing_events_input(self):
        patterns_list = self.get_patterns_list()
        non_events = ['Error 2.. occurred', 'STOPPING ENGINE']
        data = PatternMatchingInputDataModel(20000, patterns_list, non_events, None)
        request_object = MatchPatternsOverEventsRequest(data=data)
        with self.assertRaises(MindsphereError):
            self.client.match_patterns_over_events(request_object)

    def test_match_event_pattern_on_empty_timestamp(self):
        patterns_list = self.get_patterns_list()
        metadata = EventsInputModelEventsMetadata('text')
        non_events = ['Error 2.. occurred', 'STOPPING ENGINE']
        events_list = self.get_empty_timestamp_events_list()
        events_input = EventInput(metadata, events_list)
        data = PatternMatchingInputDataModel(200000, patterns_list, non_events, events_input)
        request_object = MatchPatternsOverEventsRequest(data=data)
        with self.assertRaises(MindsphereError):
            self.client.match_patterns_over_events(request_object)

    @staticmethod
    def get_events_input():
        event1 = Event('2017-10-01T12:00:00.001Z', 'Downloading the module database causes module 11 restart', 0)
        event2 = Event('2017-10-01T12:00:01.001Z',
                       'The direction for forwarding the time of day is recognized automatically by the module', 0)
        event3 = Event('2017-10-01T12:00:02.001Z', 'Status@Flame On', 0)
        event4 = Event('2017-10-01T12:00:03.001Z', 'The SIMATIC mode was selected for time-of-day '
                                                   'synchronization of the module with Id: 33', 0)
        event5 = Event('2017-10-01T12:00:06.001Z',
                       'INTRODUCING FUEL', 0)
        event6 = Event('2017-10-01T12:00:09.001Z', 'Module STOP due to parameter assignment', 0)
        events_input = [event1, event2, event3, event4, event5, event6]
        return events_input

    @staticmethod
    def get_empty_timestamp_events_list():
        event1 = Event('2017-10-01T12:00:00.001Z', 'Downloading the module database causes module 11 restart', 0)
        event2 = Event('', 'The direction for forwarding the time of day is recognized automatically by the module', 0)
        events_list = [event1, event2]
        return events_list

    @staticmethod
    def get_patterns_list():
        pattern_def = PatternDefinition()
        matching_pattern1 = MatchingPattern('INTRODUCING FUEL', 1, 2)
        pattern_list = [matching_pattern1]
        matching_pattern2 = MatchingPattern('Status@Flame On', 0, 1)
        pattern_def.pattern = pattern_list
        pattern_list.append(matching_pattern2)
        matching_pattern3 = MatchingPattern('Module STOP due to parameter assignment', 1, 1)
        pattern_list.append(matching_pattern3)
        pattern_def.pattern = pattern_list

        pattern_def1 = PatternDefinition()
        matching_pattern4 = MatchingPattern('Downloading the module database causes module .. restart', 1, 1)
        pattern_list1 = [matching_pattern4]
        matching_pattern5 = MatchingPattern('The SIMATIC mode was selected for time-of-day '
                                            'synchronization of the module with Id: ..', 1, 1)
        pattern_list1.append(matching_pattern5)
        pattern_def.pattern = pattern_list
        pattern_def1.pattern = pattern_list1
        pattern_def_list = [pattern_def, pattern_def1]
        return pattern_def_list


if __name__ == '__main__':
    unittest.main()

