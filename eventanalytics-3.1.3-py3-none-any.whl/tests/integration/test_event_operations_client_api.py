import unittest
from mindsphere_core import mindsphere_core, TenantCredentials, AppCredentials

from eventanalytics.clients.event_operations_client import EventOperationsClient
from eventanalytics.models import EventSearchInputDataModel
from eventanalytics.models import EventInput
from eventanalytics.models import TopEventsInputDataModel
from eventanalytics.models import EventsInputModelEventsMetadata
from eventanalytics.models import EventInputEventsMetadata
from eventanalytics.models import *
from mindsphere_core.exceptions import MindsphereError
from tests.data.test_data import *


class TestEventAnalytics(unittest.TestCase):

    def setUp(self):
        #credentials = TenantCredentials(client_id=CLIENT_ID, client_secret=CLIENT_SECRET, tenant=TENANT)
        credentials = None
        config = mindsphere_core.RestClientConfig('194.138.0.25', '9400')
        self.client = EventOperationsClient(config, credentials)

    def test_find_top_events_with_sub_tenant(self):
        credentials = TenantCredentials(
            client_id=CLIENT_ID_SUB_TENANT,
            client_secret=CLIENT_SECRET_SUB_TENANT,
            tenant=TENANT,
            sub_tenant=SUB_TENANT,
            use_sub_tenant=True
        )
        config = mindsphere_core.RestClientConfig(proxy_host="194.138.0.25", proxy_port="9400", host_environment="eu1")
        client = EventOperationsClient(config, credentials)
        metadata = EventsInputModelEventsMetadata('text')
        events_list = self.get_events_list()
        data = TopEventsInputDataModel(metadata, events_list, 12)
        request_object = TopEventsRequest(data=data)
        response = client.top_events(request_object)
        self.assertEqual(response[0].get('appearances'), 2)

    def test_find_top_events(self):
        metadata = EventsInputModelEventsMetadata('text')
        events_list = self.get_events_list()
        data = TopEventsInputDataModel(metadata, events_list, 12)
        request_object = TopEventsRequest(data=data)
        response = self.client.top_events(request_object)
        self.assertEqual(response[0].get('appearances'), 2)

    def test_find_top_events_on_missing_metadata(self):
        events_list = self.get_events_list()
        data = TopEventsInputDataModel(None, events_list, 12)
        request_object = TopEventsRequest(data=data)
        with self.assertRaises(MindsphereError):
            self.client.top_events(request_object)

    def test_find_top_events_on_invalid_time_format(self):
        metadata = EventsInputModelEventsMetadata('text')
        events_list = self.get_invalid_time_formatted_events_list()
        data = TopEventsInputDataModel(metadata, events_list, 12)
        request_object = TopEventsRequest(data=data)
        with self.assertRaises(MindsphereError):
            self.client.top_events(request_object)

    def test_find_top_events_on_invalid_QC(self):
        metadata = EventsInputModelEventsMetadata('text')
        events_list = self.get_invalid_qc_events_list()
        data = TopEventsInputDataModel(metadata, events_list, 12)
        request_object = TopEventsRequest(data=data)
        with self.assertRaises(MindsphereError):
            self.client.top_events(request_object)

    def test_filter_events(self):
        metadata = EventsInputModelEventsMetadata('text')
        events_list = self.get_events_list()
        filter_list = ['Introduction fuel']
        data = EventSearchInputDataModel(metadata, events_list, filter_list)
        request_object = FilterEventsRequest(data=data)
        response = self.client.filter_events(request_object)
        self.assertEqual(response.output[0].text, 'Downloading the module database causes module 11 restart')

    def test_filter_events_on_missing_events_list(self):
        metadata = EventsInputModelEventsMetadata('text')
        filter_list = ['Introduction fuel']
        data = EventSearchInputDataModel(metadata, None, filter_list)
        request_object = FilterEventsRequest(data=data)
        with self.assertRaises(MindsphereError):
            self.client.filter_events(request_object)

    def test_filter_events_on_missing_filter_list(self):
        metadata = EventsInputModelEventsMetadata('text')
        events_list = self.get_events_list()
        data = EventSearchInputDataModel(metadata, events_list, None)
        request_object = FilterEventsRequest(data=data)
        with self.assertRaises(MindsphereError):
            self.client.filter_events(request_object)

    def test_count_events(self):
        metadata = EventInputEventsMetadata('text', 5000)
        events_list = self.get_events_list()
        data = EventInput(metadata, events_list)
        request_object = CountEventsRequest(data=data)
        response = self.client.count_events(request_object)
        self.assertEqual(response.output[0].event_count, 6)

    def test_count_events_on_missing_events_metadata(self):
        events_list = self.get_events_list()
        data = EventInput(events_metadata=None, events=events_list)
        request_object = CountEventsRequest(data=data)
        with self.assertRaises(MindsphereError):
            self.client.count_events(request_object)

    def test_count_events_on_missing_text_property_name(self):
        metadata = EventInputEventsMetadata(None, 5000)
        events_list = self.get_events_list()
        data = EventInput(metadata, events_list)
        request_object = CountEventsRequest(data=data)
        with self.assertRaises(MindsphereError):
            self.client.count_events(request_object)

    def test_remove_duplicate_events(self):
        metadata = EventInputEventsMetadata('text', 5000)
        events_list = self.get_events_list()
        data = EventInput(metadata, events_list)
        request_object = RemoveDuplicateEventsRequest(data=data)
        response = self.client.remove_duplicate_events(request_object)
        self.assertEqual(response.output[0].time, '2017-10-01T12:00:00.001Z')

    def test_remove_duplicate_events_on_missing_events_list(self):
        metadata = EventInputEventsMetadata('text', 5000)
        data = EventInput(metadata, None)
        request_object = RemoveDuplicateEventsRequest(data=data)
        with self.assertRaises(MindsphereError):
            self.client.remove_duplicate_events(request_object)

    def test_remove_duplicate_events_on_missing_text_property_name(self):
        metadata = EventInputEventsMetadata(None, 5000)
        events_list = self.get_events_list()
        data = EventInput(metadata, events_list)
        request_object = RemoveDuplicateEventsRequest(data=data)
        with self.assertRaises(MindsphereError):
            self.client.remove_duplicate_events(request_object)

    @staticmethod
    def get_events_list():
        event1 = Event('2017-10-01T12:00:00.001Z', 'Downloading the module database causes module 11 restart', 0)
        event2 = Event('2017-10-01T12:00:01.001Z', 'The direction for forwarding the time of day is '
                                                   'recognized automatically by the module', 0)
        event3 = Event('2017-10-01T12:00:02.001Z', 'Status@Flame On', 0)
        event4 = Event('2017-10-01T12:00:00.001Z', 'Downloading the module database causes module 11 restart', 0)
        event5 = Event('2017-10-01T12:00:01.001Z', 'The direction for forwarding the time of day is '
                                                   'recognized automatically by the module', 0)
        event6 = Event('2017-10-01T12:00:02.001Z', 'Status@Flame On', 0)
        events_list = [event1, event2, event3, event4, event5, event6]
        return events_list

    @staticmethod
    def get_invalid_time_formatted_events_list():
        event = Event('01-10-2017', 'Downloading the module database causes module 11 restart', 0)
        events_list = [event]
        return events_list

    @staticmethod
    def get_invalid_qc_events_list():
        event1 = Event('2017-10-01T12:00:00.001Z', 'Downloading the module database causes module 11 restart', 0)
        event2 = Event('2017-10-01T12:00:01.001Z', 'The atically by the module', 8)
        events_list = [event1, event2]
        return events_list


if __name__ == '__main__':
    unittest.main()
