TENANT = 'mdspsdk'
CLIENT_ID = "technical-user-mdspsdk"
CLIENT_ID_SUB_TENANT = 'mdspsdk-tech-usr'
CLIENT_SECRET = ""
CLIENT_SECRET_SUB_TENANT = ""
SUB_TENANT = 'sdktenant'
