# coding: utf-8

"""
    IoT Time Series API

    Create, update, and query time series data with a precision of 1 millisecond.  # noqa: E501
"""


import pprint
import re
import six

from timeseries.models.time_series_data_item import TimeSeriesDataItem
from mindsphere_core.exceptions import MindsphereClientError


class TimeSeriesItem(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """

    attribute_types = {
        "entity_id": "str",
        "property_set_name": "str",
        "data": "list[TimeSeriesDataItem]",
    }

    attribute_map = {
        "entity_id": "entityId",
        "property_set_name": "propertySetName",
        "data": "data",
    }

    def __init__(self, entity_id=None, property_set_name=None, data=None):
        self._entity_id = entity_id
        self._property_set_name = property_set_name
        self._data = data
        self.discriminator = None

    @property
    def entity_id(self):
        """Gets the entity_id of this TimeSeriesItem.
        asset (entity) Id of timeseries data.

        :return: The entity_id of this TimeSeriesItem.
        :rtype: str
        """
        return self._entity_id

    @entity_id.setter
    def entity_id(self, entity_id):
        """Sets the entity_id of this TimeSeriesItem.
        asset (entity) Id of timeseries data.

        :param entity_id: The entity_id of this TimeSeriesItem.
        :type: str
        """
        if entity_id is None:
            raise MindsphereClientError(
                "Invalid value for `entity_id`, must not be `None`"
            )

        self._entity_id = entity_id

    @property
    def property_set_name(self):
        """Gets the property_set_name of this TimeSeriesItem.
        aspect (property set) name of timeseries data.

        :return: The property_set_name of this TimeSeriesItem.
        :rtype: str
        """
        return self._property_set_name

    @property_set_name.setter
    def property_set_name(self, property_set_name):
        """Sets the property_set_name of this TimeSeriesItem.
        aspect (property set) name of timeseries data.

        :param property_set_name: The property_set_name of this TimeSeriesItem.
        :type: str
        """
        if property_set_name is None:
            raise MindsphereClientError(
                "Invalid value for `property_set_name`, must not be `None`"
            )

        self._property_set_name = property_set_name

    @property
    def data(self):
        """Gets the data of this TimeSeriesItem.
        Timeseries data for corresponsding asset (entity) Id and aspect (property set) name.

        :return: The data of this TimeSeriesItem.
        :rtype: list[TimeSeriesDataItem]
        """
        return self._data

    @data.setter
    def data(self, data):
        """Sets the data of this TimeSeriesItem.
        Timeseries data for corresponsding asset (entity) Id and aspect (property set) name.

        :param data: The data of this TimeSeriesItem.
        :type: list[TimeSeriesDataItem]
        """
        if data is None:
            raise MindsphereClientError("Invalid value for `data`, must not be `None`")

        self._data = data

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(
                    map(lambda x: x.to_dict() if hasattr(x, "to_dict") else x, value)
                )
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(
                    map(
                        lambda item: (item[0], item[1].to_dict())
                        if hasattr(item[1], "to_dict")
                        else item,
                        value.items(),
                    )
                )
            else:
                result[attr] = value
        if issubclass(TimeSeriesItem, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, TimeSeriesItem):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
