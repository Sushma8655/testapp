# coding: utf-8

"""
    IoT Time Series API

    Create, update, and query time series data with a precision of 1 millisecond.  # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class DeleteUpdatedTimeseriesRequest(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """

    attribute_types = {
        "property_set_name": "str",
        "entity_id": "str",
        "_from": "str",
        "to": "str",
    }

    attribute_map = {
        "property_set_name": "propertySetName",
        "entity_id": "entityId",
        "_from": "from",
        "to": "to",
    }

    def __init__(self, property_set_name=None, entity_id=None, _from=None, to=None):
        self._property_set_name = property_set_name
        self._entity_id = entity_id
        self.__from = _from
        self._to = to
        self.discriminator = None

    @property
    def property_set_name(self):
        """Gets the property_set_name of this DeleteTimeseriesRequest.

        :return: The property_set_name of this DeleteTimeseriesRequest.
        :rtype: str
        """
        return self._property_set_name

    @property_set_name.setter
    def property_set_name(self, property_set_name):
        """Sets the property_set_name of this DeleteTimeseriesRequest.

        :param property_set_name: The property_set_name of this DeleteTimeseriesRequest.
        :type: str
        """

        self._property_set_name = property_set_name

    @property
    def entity_id(self):
        """Gets the entity_id of this DeleteTimeseriesRequest.

        :return: The entity_id of this DeleteTimeseriesRequest.
        :rtype: str
        """
        return self._entity_id

    @entity_id.setter
    def entity_id(self, entity_id):
        """Sets the entity_id of this DeleteTimeseriesRequest.

        :param entity_id: The entity_id of this DeleteTimeseriesRequest.
        :type: str
        """

        self._entity_id = entity_id

    @property
    def _from(self):
        """Gets the _from of this DeleteTimeseriesRequest.

        :return: The _from of this DeleteTimeseriesRequest.
        :rtype: str
        """
        return self.__from

    @_from.setter
    def _from(self, _from):
        """Sets the _from of this DeleteTimeseriesRequest.

        :param _from: The _from of this DeleteTimeseriesRequest.
        :type: str
        """

        self.__from = _from

    @property
    def to(self):
        """Gets the to of this DeleteTimeseriesRequest.

        :return: The to of this DeleteTimeseriesRequest.
        :rtype: str
        """
        return self._to

    @to.setter
    def to(self, to):
        """Sets the to of this DeleteTimeseriesRequest.

        :param to: The to of this DeleteTimeseriesRequest.
        :type: str
        """

        self._to = to

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(
                    map(lambda x: x.to_dict() if hasattr(x, "to_dict") else x, value)
                )
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(
                    map(
                        lambda item: (item[0], item[1].to_dict())
                        if hasattr(item[1], "to_dict")
                        else item,
                        value.items(),
                    )
                )
            else:
                result[attr] = value
        if issubclass(DeleteUpdatedTimeseriesRequest, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DeleteUpdatedTimeseriesRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
