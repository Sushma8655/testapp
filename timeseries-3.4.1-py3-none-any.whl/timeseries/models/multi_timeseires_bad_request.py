# coding: utf-8

"""
    IoT Time Series API

    Create, update, and query time series data with a precision of 1 millisecond.  # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class MultiTimeseiresBadRequest(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """

    attribute_types = {
        "timestamp": "datetime",
        "status": "float",
        "error": "str",
        "exception": "str",
        "message": "str",
        "path": "str",
    }

    attribute_map = {
        "timestamp": "timestamp",
        "status": "status",
        "error": "error",
        "exception": "exception",
        "message": "message",
        "path": "path",
    }

    def __init__(
        self,
        timestamp=None,
        status=None,
        error=None,
        exception=None,
        message=None,
        path=None,
    ):
        self._timestamp = timestamp
        self._status = status
        self._error = error
        self._exception = exception
        self._message = message
        self._path = path
        self.discriminator = None

    @property
    def timestamp(self):
        """Gets the timestamp of this MultiTimeseiresBadRequest.

        :return: The timestamp of this MultiTimeseiresBadRequest.
        :rtype: datetime
        """
        return self._timestamp

    @timestamp.setter
    def timestamp(self, timestamp):
        """Sets the timestamp of this MultiTimeseiresBadRequest.

        :param timestamp: The timestamp of this MultiTimeseiresBadRequest.
        :type: datetime
        """

        self._timestamp = timestamp

    @property
    def status(self):
        """Gets the status of this MultiTimeseiresBadRequest.

        :return: The status of this MultiTimeseiresBadRequest.
        :rtype: float
        """
        return self._status

    @status.setter
    def status(self, status):
        """Sets the status of this MultiTimeseiresBadRequest.

        :param status: The status of this MultiTimeseiresBadRequest.
        :type: float
        """

        self._status = status

    @property
    def error(self):
        """Gets the error of this MultiTimeseiresBadRequest.

        :return: The error of this MultiTimeseiresBadRequest.
        :rtype: str
        """
        return self._error

    @error.setter
    def error(self, error):
        """Sets the error of this MultiTimeseiresBadRequest.

        :param error: The error of this MultiTimeseiresBadRequest.
        :type: str
        """

        self._error = error

    @property
    def exception(self):
        """Gets the exception of this MultiTimeseiresBadRequest.

        :return: The exception of this MultiTimeseiresBadRequest.
        :rtype: str
        """
        return self._exception

    @exception.setter
    def exception(self, exception):
        """Sets the exception of this MultiTimeseiresBadRequest.

        :param exception: The exception of this MultiTimeseiresBadRequest.
        :type: str
        """

        self._exception = exception

    @property
    def message(self):
        """Gets the message of this MultiTimeseiresBadRequest.

        :return: The message of this MultiTimeseiresBadRequest.
        :rtype: str
        """
        return self._message

    @message.setter
    def message(self, message):
        """Sets the message of this MultiTimeseiresBadRequest.

        :param message: The message of this MultiTimeseiresBadRequest.
        :type: str
        """

        self._message = message

    @property
    def path(self):
        """Gets the path of this MultiTimeseiresBadRequest.

        :return: The path of this MultiTimeseiresBadRequest.
        :rtype: str
        """
        return self._path

    @path.setter
    def path(self, path):
        """Sets the path of this MultiTimeseiresBadRequest.

        :param path: The path of this MultiTimeseiresBadRequest.
        :type: str
        """

        self._path = path

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(
                    map(lambda x: x.to_dict() if hasattr(x, "to_dict") else x, value)
                )
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(
                    map(
                        lambda item: (item[0], item[1].to_dict())
                        if hasattr(item[1], "to_dict")
                        else item,
                        value.items(),
                    )
                )
            else:
                result[attr] = value
        if issubclass(MultiTimeseiresBadRequest, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, MultiTimeseiresBadRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
