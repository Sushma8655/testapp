# coding: utf-8

"""
    IoT Time Series API

    Create, update, and query time series data with a precision of 1 millisecond.  # noqa: E501
"""


import pprint
import re
import six

from timeseries.models.time_series import UpdatedTimeSeries
from mindsphere_core.exceptions import MindsphereClientError


class CreateOrUpdateTimeseriesDataRequest(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """

    attribute_types = {
        "timeseries": "list[UpdatedTimeSeries]",
        "property_set_name": "str",
        "entity_id": "str",
    }

    attribute_map = {
        "timeseries": "timeseries",
        "property_set_name": "propertySetName",
        "entity_id": "entityId",
    }

    def __init__(self, timeseries=None, property_set_name=None, entity_id=None):
        self._timeseries = timeseries
        self._property_set_name = property_set_name
        self._entity_id = entity_id
        self.discriminator = None

    @property
    def timeseries(self):
        """Gets the timeseries of this CreateOrUpdateTimeseriesDataRequest.

        :return: The timeseries of this CreateOrUpdateTimeseriesDataRequest.
        :rtype: list[UpdatedTimeSeries]
        """
        return self._timeseries

    @timeseries.setter
    def timeseries(self, timeseries):
        """Sets the timeseries of this CreateOrUpdateTimeseriesDataRequest.

        :param timeseries: The timeseries of this CreateOrUpdateTimeseriesDataRequest.
        :type: list[UpdatedTimeSeries]
        """

        self._timeseries = timeseries

    @property
    def property_set_name(self):
        """Gets the property_set_name of this CreateOrUpdateTimeseriesDataRequest.

        :return: The property_set_name of this CreateOrUpdateTimeseriesDataRequest.
        :rtype: str
        """
        return self._property_set_name

    @property_set_name.setter
    def property_set_name(self, property_set_name):
        """Sets the property_set_name of this CreateOrUpdateTimeseriesDataRequest.

        :param property_set_name: The property_set_name of this CreateOrUpdateTimeseriesDataRequest.
        :type: str
        """

        self._property_set_name = property_set_name

    @property
    def entity_id(self):
        """Gets the entity_id of this CreateOrUpdateTimeseriesDataRequest.

        :return: The entity_id of this CreateOrUpdateTimeseriesDataRequest.
        :rtype: str
        """
        return self._entity_id

    @entity_id.setter
    def entity_id(self, entity_id):
        """Sets the entity_id of this CreateOrUpdateTimeseriesDataRequest.

        :param entity_id: The entity_id of this CreateOrUpdateTimeseriesDataRequest.
        :type: str
        """

        self._entity_id = entity_id

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(
                    map(lambda x: x.to_dict() if hasattr(x, "to_dict") else x, value)
                )
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(
                    map(
                        lambda item: (item[0], item[1].to_dict())
                        if hasattr(item[1], "to_dict")
                        else item,
                        value.items(),
                    )
                )
            else:
                result[attr] = value
        if issubclass(CreateOrUpdateTimeseriesDataRequest, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateOrUpdateTimeseriesDataRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
