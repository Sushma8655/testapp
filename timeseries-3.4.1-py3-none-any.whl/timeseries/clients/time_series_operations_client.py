# coding: utf-8

"""
    IoT Time Series API

    Create, update, and query time series data with a precision of 1 millisecond.  # noqa: E501
"""


from __future__ import absolute_import

from mindsphere_core.mindsphere_core import logger
from mindsphere_core import mindsphere_core, exceptions, token_service
from mindsphere_core.token_service import init_credentials


class TimeSeriesOperationsClient:
    __base_path__ = "/api/iottimeseries/v3"
    __model_package__ = __name__.split(".")[0]

    def __init__(self, rest_client_config=None, mindsphere_credentials=None):
        self.rest_client_config = rest_client_config
        self.mindsphere_credentials = init_credentials(mindsphere_credentials)

    def create_or_update_timeseries(self, request_object):
        """Create or update time series data for mutiple unique asset-aspect (entity-property set) combinations.

        Create or update time series data for multiple unique combinations of assets (entities) and aspects (property sets). In case of an update of data at an already existing time, all properties at that time will be replaced by the ones provided in the request. All asset-aspect (entity-property set) combinations need to belong to the same tenant.  Request body limitations: 1. A maximum of 5  asset-aspect (entity-property set) combinations can be provided 2. The request body size must be equal or less than 100 kb 3. A maximum of 100 time series data items can be provided overall

        :param CreateOrUpdateTimeseriesRequest request_object: It contains the below parameters --> |br| ( timeseries* - )

        :return: MultiStatusError
        """
        logger.info("TimeSeriesOperationsClient.create_or_update_timeseries() invoked.")
        if request_object is None:
            raise exceptions.MindsphereClientError(
                "`request_object` is not passed when calling `create_or_update_timeseries`"
            )

        if request_object.timeseries is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `timeseries` is missing from `request_object`, when calling `create_or_update_timeseries`"
            )

        end_point_url = "/timeseries"
        end_point_url = end_point_url.format()
        token = token_service.fetch_token(
            self.rest_client_config, self.mindsphere_credentials
        )
        api_url = mindsphere_core.build_url(
            self.__base_path__, end_point_url, self.rest_client_config
        )
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json',
                   'Authorization': 'Bearer ' + str(token)}
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, request_object.timeseries

        logger.info(
            "TimeSeriesOperationsClient.create_or_update_timeseries()  --> Proceeding for API Invoker."
        )
        return mindsphere_core.invoke_service(
            self.rest_client_config,
            api_url,
            headers,
            "PUT",
            query_params,
            form_params,
            body_params,
            local_var_files,
            "MultiStatusError",
            self.__model_package__,
        )

    def create_or_update_timeseries_data(self, request_object):
        """Create or update time series data

        Create or update time series data for one combination of an asset (entity) and an(a) aspect (property set). In case of an update of data at an already existing time, all properties at that time will be replaced by the ones provided in the request.

        :param CreateOrUpdateTimeseriesDataRequest request_object: It contains the below parameters --> |br| ( entityId* - unique identifier of the asset (entity) ), |br| ( propertySetName* - Name of the aspect (property set). ), |br| ( timeseries* - time series data array )

        :return: None
        """
        logger.info(
            "TimeSeriesOperationsClient.create_or_update_timeseries_data() invoked."
        )
        if request_object is None:
            raise exceptions.MindsphereClientError(
                "`request_object` is not passed when calling `create_or_update_timeseries_data`"
            )

        if request_object.entity_id is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `entityId` is missing from `request_object`, when calling `create_or_update_timeseries_data`"
            )

        if request_object.property_set_name is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `propertySetName` is missing from `request_object`, when calling `create_or_update_timeseries_data`"
            )

        if request_object.timeseries is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `timeseries` is missing from `request_object`, when calling `create_or_update_timeseries_data`"
            )

        end_point_url = "/timeseries/{entityId}/{propertySetName}"
        end_point_url = end_point_url.format(
            entityId=request_object.entity_id,
            propertySetName=request_object.property_set_name,
        )
        token = token_service.fetch_token(
            self.rest_client_config, self.mindsphere_credentials
        )
        api_url = mindsphere_core.build_url(
            self.__base_path__, end_point_url, self.rest_client_config
        )
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json',
                   'Authorization': 'Bearer ' + str(token)}

        query_params = {}
        form_params, local_var_files, body_params = {}, {}, request_object.timeseries

        logger.info(
            "TimeSeriesOperationsClient.create_or_update_timeseries_data()  --> Proceeding for API Invoker."
        )
        return mindsphere_core.invoke_service(
            self.rest_client_config,
            api_url,
            headers,
            "PUT",
            query_params,
            form_params,
            body_params,
            local_var_files,
            None,
            self.__model_package__,
        )

    def delete_timeseries(self, request_object):
        """Delete time series data

        Delete time series data for one combination of an asset (entity) and an(a) aspect (property set). All property values within the given time range are deleted.

        :param DeleteTimeseriesRequest request_object: It contains the below parameters --> |br| ( entityId* - unique identifier of the asset (entity) ), |br| ( propertySetName* - Name of the aspect (property set). ), |br| ( from* - beginning of the timerange to delete (exclusive) ), |br| ( to* - end of the timerange to delete (inclusive) )

        :return: None
        """
        logger.info("TimeSeriesOperationsClient.delete_timeseries() invoked.")
        if request_object is None:
            raise exceptions.MindsphereClientError(
                "`request_object` is not passed when calling `delete_timeseries`"
            )

        if request_object.entity_id is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `entityId` is missing from `request_object`, when calling `delete_timeseries`"
            )

        if request_object.property_set_name is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `propertySetName` is missing from `request_object`, when calling `delete_timeseries`"
            )

        if request_object._from is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `from` is missing from `request_object`, when calling `delete_timeseries`"
            )

        if request_object.to is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `to` is missing from `request_object`, when calling `delete_timeseries`"
            )

        end_point_url = "/timeseries/{entityId}/{propertySetName}"
        end_point_url = end_point_url.format(
            entityId=request_object.entity_id,
            propertySetName=request_object.property_set_name,
        )
        token = token_service.fetch_token(
            self.rest_client_config, self.mindsphere_credentials
        )
        api_url = mindsphere_core.build_url(
            self.__base_path__, end_point_url, self.rest_client_config
        )
        headers = {
            "Accept": "application/json",
            "Authorization": "Bearer " + str(token),
        }
        query_params = {"from": request_object._from, "to": request_object.to}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info(
            "TimeSeriesOperationsClient.delete_timeseries()  --> Proceeding for API Invoker."
        )
        return mindsphere_core.invoke_service(
            self.rest_client_config,
            api_url,
            headers,
            "DELETE",
            query_params,
            form_params,
            body_params,
            local_var_files,
            None,
            self.__model_package__,
        )

    def retrieve_timeseries(self, request_object):
        """Retrieve time series data

        Retrieve time series data for one combination of an asset (entity) and an(a) aspect (property set). The maximum number of time series data items returned per request is defined by parameter <i>limit</i>. In case more time series data items are present in the requested time range, only a subset of data items will be returned and a header <i>link</i> is added to the response. The header value contains the request URL to fetch the next set of  time series data items, by increasing the <i>from</i> parameter accordingly. Returns the latest record if no range is provided.

        :param RetrieveTimeseriesRequest request_object: It contains the below parameters --> |br| ( entityId* - unique identifier of the asset (entity) ), |br| ( propertySetName* - Name of the aspect (property set). ), |br| ( from - Beginning of the time range to be retrieved (exclusive). ), |br| ( to - End of the time range to be retrieved (inclusive). ), |br| ( limit - Maximum number of time series data items to be retrieved. ), |br| ( select - Comma-separated list of properties to be returned. By default all properties of an(a) aspect (property set) are considered. ), |br| ( sort - Define sorting order of returned data. Sorting can be chronologically ascending (<i>asc</i>) or descending (<i>desc</i>). ), |br| ( latestValue - If true, only the latest value of each property is returned. Latest values must be at least two hours old and at maximum 30 days old, in order to be considered. The returned values might be co-located or spread over multiple timestamps. Each property appears at max once in the response. The select parameter can be used to limit the properties to be considered. Parameters from, to, and limit must not be used in conjunction with latest. )

        :return: list[TimeSeriesDataItem]
        """
        logger.info("TimeSeriesOperationsClient.retrieve_timeseries() invoked.")
        if request_object is None:
            raise exceptions.MindsphereClientError(
                "`request_object` is not passed when calling `retrieve_timeseries`"
            )

        if request_object.entity_id is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `entityId` is missing from `request_object`, when calling `retrieve_timeseries`"
            )

        if request_object.property_set_name is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `propertySetName` is missing from `request_object`, when calling `retrieve_timeseries`"
            )

        end_point_url = "/timeseries/{entityId}/{propertySetName}"
        end_point_url = end_point_url.format(
            entityId=request_object.entity_id,
            propertySetName=request_object.property_set_name,
        )
        token = token_service.fetch_token(
            self.rest_client_config, self.mindsphere_credentials
        )
        api_url = mindsphere_core.build_url(
            self.__base_path__, end_point_url, self.rest_client_config
        )
        headers = {
            "Accept": "application/json",
            "Authorization": "Bearer " + str(token),
        }
        query_params = {
            "from": request_object._from,
            "to": request_object.to,
            "limit": request_object.limit,
            "select": request_object.select,
            "sort": request_object.sort,
            "latestValue": request_object.latest_value,
        }
        form_params, local_var_files, body_params = {}, {}, None

        logger.info(
            "TimeSeriesOperationsClient.retrieve_timeseries()  --> Proceeding for API Invoker."
        )
        return mindsphere_core.invoke_service(
            self.rest_client_config,
            api_url,
            headers,
            "GET",
            query_params,
            form_params,
            body_params,
            local_var_files,
            "list[TimeSeriesDataItem]",
            self.__model_package__,
        )
