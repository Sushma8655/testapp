# coding: utf-8

"""
    IoT Time Series API

    Create, update, and query time series data with a precision of 1 millisecond.  # noqa: E501
"""


from __future__ import absolute_import

import unittest
from unittest.mock import MagicMock
from timeseries.clients import TimeSeriesOperationsClient
from timeseries.models import *
from tests.unit.test_util import TestUtil, MOCK_VALUE, MOCK_SUCCESS
from mindsphere_core.exceptions import MindsphereError
from mindsphere_core import TenantCredentials, mindsphere_core, token_service


class TimeSeriesOperationsClientUnitTest(unittest.TestCase):
    """TimeSeriesOperationsClient unit test stubs"""

    def setUp(self):
        credentials = TenantCredentials(client_id=MOCK_VALUE, client_secret=MOCK_VALUE, tenant=MOCK_VALUE)
        config = mindsphere_core.RestClientConfig(MOCK_VALUE, MOCK_VALUE)
        self.client = TimeSeriesOperationsClient(config, credentials)
        token_service._invoke_token_endpoint = MagicMock(return_value=MOCK_SUCCESS)

    def test_create_or_update_timeseries(self):
        """Test case for create_or_update_timeseries
        Create or update time series data for mutiple unique asset-aspect (entity-property set) combinations.
        """
        package_name = "timeseries.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = CreateOrUpdateTimeseriesRequest()
        request_object.timeseries = TestUtil.get_mock_data(package_name, "TimeSeries")
        response = self.client.create_or_update_timeseries(request_object)
        self.assertEqual(200, response)

    def test_negative_create_or_update_timeseries(self):
        """Negative test case for create_or_update_timeseries
        Create or update time series data for mutiple unique asset-aspect (entity-property set) combinations.
        """
        request_object = CreateOrUpdateTimeseriesRequest()
        with self.assertRaises(MindsphereError):
            self.client.create_or_update_timeseries(request_object)

    def test_negative_request_create_or_update_timeseries(self):
        """Negative test case for create_or_update_timeseries
        Create or update time series data for mutiple unique asset-aspect (entity-property set) combinations.
        """
        with self.assertRaises(MindsphereError):
            self.client.create_or_update_timeseries(None)

    def test_create_or_update_timeseries_data(self):
        """Test case for create_or_update_timeseries_data
        Create or update time series data
        """
        package_name = "timeseries.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = CreateOrUpdateTimeseriesDataRequest()
        request_object.entity_id = TestUtil.get_mock_data(package_name, "str")
        request_object.property_set_name = TestUtil.get_mock_data(package_name, "str")
        request_object.timeseries = TestUtil.get_mock_data(package_name, "list[TimeSeriesDataItem]")
        response = self.client.create_or_update_timeseries_data(request_object)
        self.assertEqual(200, response)

    def test_negative_create_or_update_timeseries_data(self):
        """Negative test case for create_or_update_timeseries_data
        Create or update time series data
        """
        request_object = CreateOrUpdateTimeseriesDataRequest()
        with self.assertRaises(MindsphereError):
            self.client.create_or_update_timeseries_data(request_object)

    def test_negative_request_create_or_update_timeseries_data(self):
        """Negative test case for create_or_update_timeseries_data
        Create or update time series data
        """
        with self.assertRaises(MindsphereError):
            self.client.create_or_update_timeseries_data(None)

    def test_delete_timeseries(self):
        """Test case for delete_timeseries
        Delete time series data
        """
        package_name = "timeseries.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = DeleteUpdatedTimeseriesRequest()
        request_object.entity_id = TestUtil.get_mock_data(package_name, "str")
        request_object.property_set_name = TestUtil.get_mock_data(package_name, "str")
        request_object._from = TestUtil.get_mock_data(package_name, "datetime")
        request_object.to = TestUtil.get_mock_data(package_name, "datetime")
        response = self.client.delete_timeseries(request_object)
        self.assertEqual(200, response)

    def test_negative_delete_timeseries(self):
        """Negative test case for delete_timeseries
        Delete time series data
        """
        request_object = DeleteUpdatedTimeseriesRequest()
        with self.assertRaises(MindsphereError):
            self.client.delete_timeseries(request_object)

    def test_negative_request_delete_timeseries(self):
        """Negative test case for delete_timeseries
        Delete time series data
        """
        with self.assertRaises(MindsphereError):
            self.client.delete_timeseries(None)

    def test_retrieve_timeseries(self):
        """Test case for retrieve_timeseries
        Retrieve time series data
        """
        package_name = "timeseries.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = RetrieveTimeseriesRequest()
        request_object.entity_id = TestUtil.get_mock_data(package_name, "str")
        request_object.property_set_name = TestUtil.get_mock_data(package_name, "str")
        response = self.client.retrieve_timeseries(request_object)
        self.assertEqual(200, response)

    def test_negative_retrieve_timeseries(self):
        """Negative test case for retrieve_timeseries
        Retrieve time series data
        """
        request_object = RetrieveTimeseriesRequest()
        with self.assertRaises(MindsphereError):
            self.client.retrieve_timeseries(request_object)

    def test_negative_request_retrieve_timeseries(self):
        """Negative test case for retrieve_timeseries
        Retrieve time series data
        """
        with self.assertRaises(MindsphereError):
            self.client.retrieve_timeseries(None)


if __name__ == '__main__':
    unittest.main()
