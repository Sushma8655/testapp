import json
import unittest
import random
from mindsphere_core import mindsphere_core

from mindsphere_core.exceptions import MindsphereError

from timeseries import TimeSeriesOperationsClient, UpdatedTimeSeries, TimeSeriesDataItem, TimeSeriesItem, \
    CreateOrUpdateTimeseriesRequest, RetrieveTimeseriesRequest, CreateOrUpdateTimeseriesDataRequest, \
    DeleteUpdatedTimeseriesRequest


class TestAspectTypeApi(unittest.TestCase):
    def setUp(self):
        config = mindsphere_core.RestClientConfig()
        self.client = TimeSeriesOperationsClient(rest_client_config=config)

    def test_createOrUpdateTimeseries(self):
        timeseries = UpdatedTimeSeries()
        timeSeriesItem = TimeSeriesItem()
        timeSeriesItem.entity_id = "5908ae5c5e4f4e18b0be58cd21ee675f"
        timeSeriesItem.property_set_name = "test_2020_11_11"

        timeSeriesDataItem = TimeSeriesDataItem()
        timeSeriesDataItem.fields = {
            "test": 15
        }
        timeSeriesDataItem.time = "2020-11-11T02:52:00Z"
        timeSeriesDataItems = [timeSeriesDataItem]
        timeSeriesItem.data = timeSeriesDataItems
        timeSeriesItems = [timeSeriesItem]
        timeseries.timeseries = tim = timeSeriesItems
        createOrUpdateTimeseriesRequest = CreateOrUpdateTimeseriesRequest()
        createOrUpdateTimeseriesRequest.timeseries = timeseries

        response = self.client.create_or_update_timeseries(createOrUpdateTimeseriesRequest)
        print(response)

    def test_createOrUpdateTimeseriesNegative(self):
        createOrUpdateTimeseriesRequest = CreateOrUpdateTimeseriesRequest()
        with self.assertRaises(MindsphereError):
            self.client.create_or_update_timeseries(createOrUpdateTimeseriesRequest)

    def test_createOrUpdateTimeseriesData(self):
        requestObject = CreateOrUpdateTimeseriesDataRequest();
        requestObject.entity_id = "5908ae5c5e4f4e18b0be58cd21ee675f"
        requestObject.property_set_name = "test_2020_11_11"
        timeSeriesDataItem = TimeSeriesDataItem()
        timeSeriesDataItem.fields = {
            "test": 15
        }
        timeSeriesDataItem.time = "2020-11-11T02:52:00Z"
        timeSeriesDataItems = [timeSeriesDataItem]
        requestObject.timeseries = timeSeriesDataItems

        self.client.create_or_update_timeseries_data(requestObject)

    def test_createOrUpdateTimeseriesDataNegative(self):
        requestObject = CreateOrUpdateTimeseriesDataRequest();

        with self.assertRaises(MindsphereError):
            self.client.create_or_update_timeseries_data(requestObject)

    def test_deleteTimeseries(self):
        requestObject = DeleteUpdatedTimeseriesRequest();
        requestObject._from = "2020-12-12T15:10:00Z"
        requestObject.to = "2020-12-15T16:18:00Z"
        requestObject.entity_id = "5908ae5c5e4f4e18b0be58cd21ee675f"
        requestObject.property_set_name = "test_2020_11_11"

        self.client.delete_timeseries(requestObject)

    def test_deleteTimeserieswithInvaliddateformat(self):
        requestObject = DeleteUpdatedTimeseriesRequest();
        requestObject._from = "2018-01-2905:02:42.363Z"
        requestObject.to = "2018-01-29T05:02:43.363Z"
        requestObject.entity_id = "5908ae5c5e4f4e18b0be58cd21ee675f"
        requestObject.property_set_name = "test_2020_11_11"

        with self.assertRaises(MindsphereError):
            self.client.delete_timeseries(requestObject)

    def test_retrieveTimeseries(self):
        retrieveTimeseriesRequest = RetrieveTimeseriesRequest(
            entity_id="5908ae5c5e4f4e18b0be58cd21ee675f",
            property_set_name="test_2020_11_11"
        )
        response = self.client.retrieve_timeseries(retrieveTimeseriesRequest)
        print(response)

    def test_retrieveTimeserieswithfromandto(self):
        retrieveTimeseriesRequest = RetrieveTimeseriesRequest(
            entity_id="5908ae5c5e4f4e18b0be58cd21ee675f",
            property_set_name="test_2020_11_11",
            _from="2020-11-11T02:50:00Z",
            to="2020-11-11T03:52:00Z"
        )
        response = self.client.retrieve_timeseries(retrieveTimeseriesRequest)
        print(response)

    def test_retrieveTimeseriesNegative(self):
        retrieveTimeseriesRequest = RetrieveTimeseriesRequest()
        with self.assertRaises(MindsphereError):
            self.client.retrieve_timeseries(retrieveTimeseriesRequest)


if __name__ == "__main__":
    unittest.main()
