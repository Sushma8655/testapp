# coding: utf-8

"""
    IoT Time Series Bulk API

    This API allows to bulk import IoT time series data based on files uploaded via IoT File Service. Data import for simulation assets (entities) is supported with up to nano second precision and for performance assets (entities) with up to milli second precision. A bulk import is modeled as asynchronous job whose status can be retrieved after creation. Successfully imported time series data can be retrieved using the read operation.   # noqa: E501
"""


from __future__ import absolute_import

from mindsphere_core.mindsphere_core import logger
from mindsphere_core import mindsphere_core, exceptions, token_service
from mindsphere_core.token_service import init_credentials


class ReadOperationsClient:
    __base_path__ = '/api/iottsbulk/v3'
    __model_package__ = __name__.split('.')[0]

    def __init__(self, rest_client_config=None, mindsphere_credentials=None):
        self.rest_client_config = rest_client_config
        self.mindsphere_credentials = init_credentials(mindsphere_credentials)

    def retrieve_timeseries(self, request_object):
        """Retrieve time series data

        Retrieve time series data for a single asset (entity) and aspect (property set). Returns data for the specified time range. Returns only the selected properties if 'select' parameter is used.  The maximum number of time series data items returned per request is defined by parameter 'limit'. In case more time series data items are present in the requested time range, only a subset of data items will be returned. In that case response property 'nextRecord' contains the request URL to fetch the next set of  time series data items, by increasing the 'from' parameter accordingly. 

        :param RetrieveTimeseriesRequest request_object: It contains the below parameters --> |br| ( entity* - Unique identifier of the asset (entity). ), |br| ( propertySetName* - Unique name of the aspect (property set). ), |br| ( from* - Beginning of the time range to read (exclusive). 'from' time must be less than 'to' time. Range between 'from' and 'to' time must be less than 90 days.  ), |br| ( to* - End of the time range to retrieve (inclusive). ), |br| ( limit - Maximum number of time series data items to be retrieved. ), |br| ( select - Comma-separated list of properties to be returned. By default all properties of an(a) aspect (property set) are considered. )

        :return: TimeSeries
        """
        logger.info('ReadOperationsClient.retrieve_timeseries() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `retrieve_timeseries`')

        if request_object.entity is None:
            raise exceptions.MindsphereClientError('The required parameter `entity` is missing from `request_object`, when calling `retrieve_timeseries`')

        if request_object.property_set_name is None:
            raise exceptions.MindsphereClientError('The required parameter `propertySetName` is missing from `request_object`, when calling `retrieve_timeseries`')

        if request_object._from is None:
            raise exceptions.MindsphereClientError('The required parameter `from` is missing from `request_object`, when calling `retrieve_timeseries`')

        if request_object.to is None:
            raise exceptions.MindsphereClientError('The required parameter `to` is missing from `request_object`, when calling `retrieve_timeseries`')

        end_point_url = '/timeseries/{entity}/{propertySetName}'
        end_point_url = end_point_url.format(entity=request_object.entity, propertySetName=request_object.property_set_name)
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json',
                   'Authorization': 'Bearer ' + str(token)}
        query_params = {'from': request_object._from, 'to': request_object.to, 'limit': request_object.limit, 'select': request_object.select}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info('ReadOperationsClient.retrieve_timeseries()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'GET', query_params, form_params, body_params, local_var_files, 'TimeSeries', self.__model_package__)

