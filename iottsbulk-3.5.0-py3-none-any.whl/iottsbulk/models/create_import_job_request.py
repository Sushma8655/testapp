# coding: utf-8

"""
    IoT Time Series Bulk API

    This API allows to bulk import IoT time series data based on files uploaded via IoT File Service. Data import for simulation assets (entities) is supported with up to nano second precision and for performance assets (entities) with up to milli second precision. A bulk import is modeled as asynchronous job whose status can be retrieved after creation. Successfully imported time series data can be retrieved using the read operation.   # noqa: E501
"""


import pprint
import re
import six

from iottsbulk.models.bulk_import_input import BulkImportInput
from mindsphere_core.exceptions import MindsphereClientError


class CreateImportJobRequest(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'bulk_import_input': 'BulkImportInput'
    }

    attribute_map = {
        'bulk_import_input': 'bulkImportInput'
    }

    def __init__(self, bulk_import_input=None):
        self._bulk_import_input = bulk_import_input
        self.discriminator = None

    @property
    def bulk_import_input(self):
        """Gets the bulk_import_input of this CreateImportJobRequest.

        :return: The bulk_import_input of this CreateImportJobRequest.
        :rtype: BulkImportInput
        """
        return self._bulk_import_input

    @bulk_import_input.setter
    def bulk_import_input(self, bulk_import_input):
        """Sets the bulk_import_input of this CreateImportJobRequest.

        :param bulk_import_input: The bulk_import_input of this CreateImportJobRequest.
        :type: BulkImportInput
        """

        self._bulk_import_input = bulk_import_input

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(CreateImportJobRequest, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, CreateImportJobRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
