# coding: utf-8

"""
    IoT Time Series Bulk API

    This API allows to bulk import IoT time series data based on files uploaded via IoT File Service. Data import for simulation assets (entities) is supported with up to nano second precision and for performance assets (entities) with up to milli second precision. A bulk import is modeled as asynchronous job whose status can be retrieved after creation. Successfully imported time series data can be retrieved using the read operation.   # noqa: E501
"""


import pprint
import re
import six

from iottsbulk.models.file_info import FileInfo
from mindsphere_core.exceptions import MindsphereClientError


class Data(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'entity': 'str',
        'property_set_name': 'str',
        'timeseries_files': 'list[FileInfo]'
    }

    attribute_map = {
        'entity': 'entity',
        'property_set_name': 'propertySetName',
        'timeseries_files': 'timeseriesFiles'
    }

    def __init__(self, entity=None, property_set_name=None, timeseries_files=None):
        self._entity = entity
        self._property_set_name = property_set_name
        self._timeseries_files = timeseries_files
        self.discriminator = None

    @property
    def entity(self):
        """Gets the entity of this Data.
        Unique ID of an asset (entity).

        :return: The entity of this Data.
        :rtype: str
        """
        return self._entity

    @entity.setter
    def entity(self, entity):
        """Sets the entity of this Data.
        Unique ID of an asset (entity).

        :param entity: The entity of this Data.
        :type: str
        """
        if entity is None:
            raise MindsphereClientError("Invalid value for `entity`, must not be `None`")
        if entity is not None and len(entity) > 32:
            raise MindsphereClientError("Invalid value for `entity`, length must be less than or equal to `32`")
        if entity is not None and len(entity) < 32:
            raise MindsphereClientError("Invalid value for `entity`, length must be greater than or equal to `32`")
        if entity is not None and not re.search(r'[a-f0-9]{32}', entity):
            raise MindsphereClientError(r"Invalid value for `entity`, must be a follow pattern or equal to `/[a-f0-9]{32}/`")

        self._entity = entity

    @property
    def property_set_name(self):
        """Gets the property_set_name of this Data.
        Unique name of a aspect (property set).

        :return: The property_set_name of this Data.
        :rtype: str
        """
        return self._property_set_name

    @property_set_name.setter
    def property_set_name(self, property_set_name):
        """Sets the property_set_name of this Data.
        Unique name of a aspect (property set).

        :param property_set_name: The property_set_name of this Data.
        :type: str
        """
        if property_set_name is None:
            raise MindsphereClientError("Invalid value for `property_set_name`, must not be `None`")

        self._property_set_name = property_set_name

    @property
    def timeseries_files(self):
        """Gets the timeseries_files of this Data.
        Information on files uploaded with IoT File Service, to be considered as sources for importing time series data. The time ranges defined by properties \"from\" and \"to\" for the provided files must not overlap.

        :return: The timeseries_files of this Data.
        :rtype: list[FileInfo]
        """
        return self._timeseries_files

    @timeseries_files.setter
    def timeseries_files(self, timeseries_files):
        """Sets the timeseries_files of this Data.
        Information on files uploaded with IoT File Service, to be considered as sources for importing time series data. The time ranges defined by properties \"from\" and \"to\" for the provided files must not overlap.

        :param timeseries_files: The timeseries_files of this Data.
        :type: list[FileInfo]
        """
        if timeseries_files is None:
            raise MindsphereClientError("Invalid value for `timeseries_files`, must not be `None`")

        self._timeseries_files = timeseries_files

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(Data, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, Data):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
