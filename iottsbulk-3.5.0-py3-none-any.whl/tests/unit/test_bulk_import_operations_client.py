# coding: utf-8

"""
    IoT Time Series Bulk API

    This API allows to bulk import IoT time series data based on files uploaded via IoT File Service. Data import for simulation assets (entities) is supported with up to nano second precision and for performance assets (entities) with up to milli second precision. A bulk import is modeled as asynchronous job whose status can be retrieved after creation. Successfully imported time series data can be retrieved using the read operation.   # noqa: E501
"""


from __future__ import absolute_import

import unittest
from unittest.mock import MagicMock
from iottsbulk.clients import BulkImportOperationsClient
from iottsbulk.models import *
from tests.unit.test_util import TestUtil, MOCK_VALUE, MOCK_SUCCESS
from mindsphere_core.exceptions import MindsphereError
from mindsphere_core import TenantCredentials, mindsphere_core, token_service


class BulkImportOperationsClientUnitTest(unittest.TestCase):
    """BulkImportOperationsClient unit test stubs"""

    def setUp(self):
        credentials = TenantCredentials(client_id=MOCK_VALUE, client_secret=MOCK_VALUE, tenant=MOCK_VALUE)
        config = mindsphere_core.RestClientConfig(MOCK_VALUE, MOCK_VALUE)
        self.client = BulkImportOperationsClient(config, credentials)
        token_service._invoke_token_endpoint = MagicMock(return_value=MOCK_SUCCESS)

    def test_create_import_job(self):
        """Test case for create_import_job
        Create bulk import job for importing time series data
        """
        package_name = "iottsbulk.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = CreateImportJobRequest()
        request_object.bulk_import_input = TestUtil.get_mock_data(package_name, "BulkImportInput")
        response = self.client.create_import_job(request_object)
        self.assertEqual(200, response)

    def test_negative_create_import_job(self):
        """Negative test case for create_import_job
        Create bulk import job for importing time series data
        """
        request_object = CreateImportJobRequest()
        with self.assertRaises(MindsphereError):
            self.client.create_import_job(request_object)

    def test_negative_request_create_import_job(self):
        """Negative test case for create_import_job
        Create bulk import job for importing time series data
        """
        with self.assertRaises(MindsphereError):
            self.client.create_import_job(None)

    def test_retrieve_import_job(self):
        """Test case for retrieve_import_job
        Retrieve status of bulk import job
        """
        package_name = "iottsbulk.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = RetrieveImportJobRequest()
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        response = self.client.retrieve_import_job(request_object)
        self.assertEqual(200, response)

    def test_negative_retrieve_import_job(self):
        """Negative test case for retrieve_import_job
        Retrieve status of bulk import job
        """
        request_object = RetrieveImportJobRequest()
        with self.assertRaises(MindsphereError):
            self.client.retrieve_import_job(request_object)

    def test_negative_request_retrieve_import_job(self):
        """Negative test case for retrieve_import_job
        Retrieve status of bulk import job
        """
        with self.assertRaises(MindsphereError):
            self.client.retrieve_import_job(None)


if __name__ == '__main__':
    unittest.main()
