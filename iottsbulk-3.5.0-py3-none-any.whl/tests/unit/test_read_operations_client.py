# coding: utf-8

"""
    IoT Time Series Bulk API

    This API allows to bulk import IoT time series data based on files uploaded via IoT File Service. Data import for simulation assets (entities) is supported with up to nano second precision and for performance assets (entities) with up to milli second precision. A bulk import is modeled as asynchronous job whose status can be retrieved after creation. Successfully imported time series data can be retrieved using the read operation.   # noqa: E501
"""


from __future__ import absolute_import

import unittest
from unittest.mock import MagicMock
from iottsbulk.clients import ReadOperationsClient
from iottsbulk.models import *
from tests.unit.test_util import TestUtil, MOCK_VALUE, MOCK_SUCCESS
from mindsphere_core.exceptions import MindsphereError
from mindsphere_core import TenantCredentials, mindsphere_core, token_service


class ReadOperationsClientUnitTest(unittest.TestCase):
    """ReadOperationsClient unit test stubs"""

    def setUp(self):
        credentials = TenantCredentials(client_id=MOCK_VALUE, client_secret=MOCK_VALUE, tenant=MOCK_VALUE)
        config = mindsphere_core.RestClientConfig(MOCK_VALUE, MOCK_VALUE)
        self.client = ReadOperationsClient(config, credentials)
        token_service._invoke_token_endpoint = MagicMock(return_value=MOCK_SUCCESS)

    def test_retrieve_timeseries(self):
        """Test case for retrieve_timeseries
        Retrieve time series data
        """
        package_name = "iottsbulk.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = RetrieveTimeseriesRequest()
        request_object.entity = TestUtil.get_mock_data(package_name, "str")
        request_object.property_set_name = TestUtil.get_mock_data(package_name, "str")
        request_object._from = TestUtil.get_mock_data(package_name, "datetime")
        request_object.to = TestUtil.get_mock_data(package_name, "datetime")
        response = self.client.retrieve_timeseries(request_object)
        self.assertEqual(200, response)

    def test_negative_retrieve_timeseries(self):
        """Negative test case for retrieve_timeseries
        Retrieve time series data
        """
        request_object = RetrieveTimeseriesRequest()
        with self.assertRaises(MindsphereError):
            self.client.retrieve_timeseries(request_object)

    def test_negative_request_retrieve_timeseries(self):
        """Negative test case for retrieve_timeseries
        Retrieve time series data
        """
        with self.assertRaises(MindsphereError):
            self.client.retrieve_timeseries(None)


if __name__ == '__main__':
    unittest.main()
