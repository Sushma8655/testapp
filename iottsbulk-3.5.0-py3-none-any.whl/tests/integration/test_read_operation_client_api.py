import json
import unittest
import random
from mindsphere_core import mindsphere_core

from mindsphere_core.exceptions import MindsphereError

from iottsbulk import ReadOperationsClient, RetrieveTimeseriesRequest


class TestBulkImportOperationClientApi(unittest.TestCase):
    def setUp(self):
        config = mindsphere_core.RestClientConfig()
        self.client = ReadOperationsClient(rest_client_config=config)

    def test_retrieveTimeseries(self):
        retrieveTimeseriesRequest = RetrieveTimeseriesRequest();
        retrieveTimeseriesRequest.entity = "5908ae5c5e4f4e18b0be58cd21ee675f"
        retrieveTimeseriesRequest.property_set_name = "test_2020_11_11"
        retrieveTimeseriesRequest._from = "2020-11-11T02:50:00Z"
        retrieveTimeseriesRequest.to = "2020-11-11T03:52:00Z"
        response = self.client.retrieve_timeseries(retrieveTimeseriesRequest)
        print(response)

    def test_retrieveTimeseriesNegative(self):
        retrieveTimeseriesRequest = RetrieveTimeseriesRequest();
        with self.assertRaises(MindsphereError):
            self.client.retrieve_timeseries(retrieveTimeseriesRequest)

    def test_retrieveTimeserieswithLimit(self):
        retrieveTimeseriesRequest = RetrieveTimeseriesRequest();
        retrieveTimeseriesRequest.entity = "5908ae5c5e4f4e18b0be58cd21ee675f"
        retrieveTimeseriesRequest.property_set_name = "test_2020_11_11"
        retrieveTimeseriesRequest._from = "2020-11-11T02:50:00Z"
        retrieveTimeseriesRequest.to = "2020-11-11T03:52:00Z"
        retrieveTimeseriesRequest.limit = 5
        response = self.client.retrieve_timeseries(retrieveTimeseriesRequest)
        print(response)

    def test_retrieveTimeserieswithselect(self):
        retrieveTimeseriesRequest = RetrieveTimeseriesRequest();
        retrieveTimeseriesRequest.entity = "5908ae5c5e4f4e18b0be58cd21ee675f"
        retrieveTimeseriesRequest.property_set_name = "test_2020_11_11"
        retrieveTimeseriesRequest._from = "2020-11-11T02:50:00Z"
        retrieveTimeseriesRequest.to = "2020-11-11T03:52:00Z"
        retrieveTimeseriesRequest.limit = 5
        retrieveTimeseriesRequest.select = "test"
        response = self.client.retrieve_timeseries(retrieveTimeseriesRequest)
        print(response)


    def test_retrieveTimeserieswithoutentity(self):
        retrieveTimeseriesRequest = RetrieveTimeseriesRequest();
        retrieveTimeseriesRequest.property_set_name = "test_2020_11_11"
        retrieveTimeseriesRequest._from = "2020-11-11T02:50:00Z"
        retrieveTimeseriesRequest.to = "2020-11-11T03:52:00Z"
        retrieveTimeseriesRequest.limit = 5
        retrieveTimeseriesRequest.select = "test"
        with self.assertRaises(MindsphereError):
            self.client.retrieve_timeseries(retrieveTimeseriesRequest)


    def test_retrieveTimeserieswithoutpropertyset(self):
        retrieveTimeseriesRequest = RetrieveTimeseriesRequest();
        retrieveTimeseriesRequest.entity = "5908ae5c5e4f4e18b0be58cd21ee675f"
        retrieveTimeseriesRequest._from = "2020-11-11T02:50:00Z"
        retrieveTimeseriesRequest.to = "2020-11-11T03:52:00Z"
        retrieveTimeseriesRequest.limit = 5
        retrieveTimeseriesRequest.select = "test"
        with self.assertRaises(MindsphereError):
            self.client.retrieve_timeseries(retrieveTimeseriesRequest)

    def test_retrieveTimeserieswithoutfrom(self):
        retrieveTimeseriesRequest = RetrieveTimeseriesRequest();
        retrieveTimeseriesRequest.entity = "5908ae5c5e4f4e18b0be58cd21ee675f"
        retrieveTimeseriesRequest.property_set_name = "test_2020_11_11"
        retrieveTimeseriesRequest.to = "2020-11-11T03:52:00Z"
        retrieveTimeseriesRequest.limit = 5
        retrieveTimeseriesRequest.select = "test"
        with self.assertRaises(MindsphereError):
            self.client.retrieve_timeseries(retrieveTimeseriesRequest)


    def test_retrieveTimeserieswithoutto(self):
        retrieveTimeseriesRequest = RetrieveTimeseriesRequest();
        retrieveTimeseriesRequest.entity = "5908ae5c5e4f4e18b0be58cd21ee675f"
        retrieveTimeseriesRequest.property_set_name = "test_2020_11_11"
        retrieveTimeseriesRequest._from = "2020-11-11T02:50:00Z"
        retrieveTimeseriesRequest.limit = 5
        retrieveTimeseriesRequest.select = "test"
        with self.assertRaises(MindsphereError):
            self.client.retrieve_timeseries(retrieveTimeseriesRequest)




if __name__ == "__main__":
    unittest.main()
