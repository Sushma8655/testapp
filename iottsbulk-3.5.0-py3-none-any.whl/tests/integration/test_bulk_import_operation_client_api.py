import json
import unittest
import random
from mindsphere_core import mindsphere_core

from mindsphere_core.exceptions import MindsphereError

from iottsbulk import BulkImportOperationsClient, CreateImportJobRequest, BulkImportInput, Data, FileInfo, \
    RetrieveImportJobRequest


class TestBulkImportOperationClientApi(unittest.TestCase):
    def setUp(self):
        config = mindsphere_core.RestClientConfig()
        self.client = BulkImportOperationsClient(rest_client_config=config)

    def test_createimportJob(self):
        createImportJobRequest =CreateImportJobRequest()
        bulkImportInput = BulkImportInput()
        data = Data()
        data.entity = "d244670a66e740c08045d154989a5724"
        data.property_set_name = "testaspect2021"

        fileInfo = FileInfo()
        fileInfo.file_path = "test11.json"
        fileInfo._from = "2020-12-16T04:30:00.01Z"
        fileInfo.to = "2020-12-16T04:35:00.30Z"
        fileInfoList = [fileInfo]

        data.timeseries_files = fileInfoList
        dataList = [data]

        bulkImportInput.data = dataList
        createImportJobRequest.bulk_import_input = bulkImportInput
        response = self.client.create_import_job(createImportJobRequest)
        print(response)

    def test_createimportJobwithmultiple_file(self):
        createImportJobRequest = CreateImportJobRequest()
        bulkImportInput = BulkImportInput()
        data = Data()
        data.entity = "5908ae5c5e4f4e18b0be58cd21ee675f"
        data.property_set_name = "test_2020_11_11"

        fileInfo = FileInfo()
        fileInfo.file_path = "test1112.json"
        fileInfo._from = "2020-06-16T02:00:00.01Z"
        fileInfo.to = "2020-06-16T02:00:00.30Z"

        fileInfo1 = FileInfo()
        fileInfo1.file_path = "test1113.json"
        fileInfo1._from = "2020-06-16T02:00:00.01Z"
        fileInfo1.to = "2020-06-16T02:00:00.30Z"


        fileInfoList = [fileInfo,fileInfo1]

        data.timeseries_files = fileInfoList
        dataList = [data]

        bulkImportInput.data = dataList
        createImportJobRequest.bulk_import_input = bulkImportInput
        response = self.client.create_import_job(createImportJobRequest)
        print(response)

    def test_createimportJobwithoutfile(self):
        createImportJobRequest = CreateImportJobRequest()
        bulkImportInput = BulkImportInput()
        data = Data()
        data.entity = "5908ae5c5e4f4e18b0be58cd21ee675f"
        data.property_set_name = "test_2020_11_11"

        dataList = [data]

        bulkImportInput.data = dataList
        createImportJobRequest.bulk_import_input = bulkImportInput
        with self.assertRaises(MindsphereError):
            self.client.create_import_job(createImportJobRequest)

    def test_createimportJobwithoutentity(self):
        createImportJobRequest = CreateImportJobRequest()
        bulkImportInput = BulkImportInput()
        data = Data()
        data.property_set_name = "test_2020_11_11"

        fileInfo = FileInfo()
        fileInfo.file_path = "test1112.json"
        fileInfo._from = "2020-06-16T02:00:00.01Z"
        fileInfo.to = "2020-06-16T02:00:00.30Z"
        fileInfoList = [fileInfo]

        data.timeseries_files = fileInfoList
        dataList = [data]

        bulkImportInput.data = dataList
        createImportJobRequest.bulk_import_input = bulkImportInput
        with self.assertRaises(MindsphereError):
            self.client.create_import_job(createImportJobRequest)

    def test_retrieveimportJob(self):
        retrieveImportJobRequest = RetrieveImportJobRequest()
        retrieveImportJobRequest.id = "4e37b10ad4774b8bb391209a9d18f1b6"
        response = self.client.retrieve_import_job(retrieveImportJobRequest)
        print(response)

    def test_retrieveimportJobNegative(self):
        retrieveImportJobRequest = RetrieveImportJobRequest()
        with self.assertRaises(MindsphereError):
            self.client.retrieve_import_job(retrieveImportJobRequest)





if __name__ == "__main__":
    unittest.main()
