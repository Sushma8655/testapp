import unittest
from timeseries.clients.time_series_client import TimeSeriesClient
from mindsphere_core import mindsphere_core
from timeseries.models import *
from mindsphere_core.exceptions import MindsphereError


class TestTimeseries(unittest.TestCase):
    def setUp(self):
        config = mindsphere_core.RestClientConfig("194.138.0.25", "9400")
        self.client = TimeSeriesClient(rest_client_config=config)

    def test_get_timeseries(self):
        request_object = GetTimeseriesRequest(
            _from="2019-04-04T09:50:23.889Z",
            to="2019-04-04T09:52:23.889Z",
            entity="078b1908bc9347678168760934465587",
            propertysetname="TyreTemperature",
            sort="desc"
        )
        response = self.client.get_timeseries(request_object)
        self.assertIsNotNone(response)

    def test_negative_get_timeseries(self):
        request_object = GetTimeseriesRequest(
            _from="2019-04-04T09:50:23.889Z",
            to="2019-04-04T09:52:23.889Z",
            propertysetname="TyreTemperature",
        )
        with self.assertRaises(MindsphereError):
            self.client.get_timeseries(request_object)

    def test_negative_with_no_property_name_get_timeseries(self):
        request_object = GetTimeseriesRequest(
            _from="2019-04-04T09:50:23.889Z",
            to="2019-04-04T09:52:23.889Z",
            entity="078b1908bc9347678168760934465587",
        )
        with self.assertRaises(MindsphereError):
            self.client.get_timeseries(request_object)

    def test_put_timeseries(self):
        time_series_data = Timeseries()
        time_series_data.time = "2019-04-04T09:52:23.889Z"
        time_series_data.fields = {
            "FRWheel": 15,
            "FLWheel": 20,
            "RLWheel": 30,
            "RRWheel": 40,
        }

        request_object = PutTimeseriesRequest(
            timeseries=[time_series_data],
            entity="078b1908bc9347678168760934465587",
            propertysetname="TyreTemperature",
        )
        self.client.put_timeseries(request_object)

    def test_negative_with_no_property_name_put_timeseries(self):
        time_series_data = Timeseries()
        time_series_data.time = "2019-04-04T09:52:23.889Z"
        time_series_data.fields = {
            "FRWheel": 15,
            "FLWheel": 20,
            "RLWheel": 30,
            "RRWheel": 40,
        }

        request_object = PutTimeseriesRequest(
            timeseries=[time_series_data], entity="078b1908bc9347678168760934465587"
        )
        with self.assertRaises(MindsphereError):
            self.client.put_timeseries(request_object)

    def test_delete_timeseries(self):
        request_object = DeleteTimeseriesRequest(
            _from="2019-04-04T09:51:23.889Z",
            to="2019-04-04T09:53:23.889Z",
            entity="078b1908bc9347678168760934465587",
            propertysetname="TyreTemperature",
        )
        self.client.delete_timeseries(request_object)

    def test_negative_delete_timeseries(self):
        request_object = DeleteTimeseriesRequest(
            _from="2019-04-04T09:51:23.889Z",
            to="2019-04-04T09:53:23.889Z",
            propertysetname="TyreTemperature",
        )
        with self.assertRaises(MindsphereError):
            self.client.delete_timeseries(request_object)


if __name__ == "__main__":
    unittest.main()
