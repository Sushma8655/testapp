# coding: utf-8

"""
    IoT Time Series API

    Store and query time series data with a precision of 1 millisecond.  # noqa: E501
"""


from __future__ import absolute_import

from mindsphere_core.mindsphere_core import logger
from mindsphere_core import mindsphere_core, exceptions, token_service
from mindsphere_core.token_service import init_credentials


class TimeSeriesClient:
    __base_path__ = '/api/iottimeseries/v3'
    __model_package__ = __name__.split('.')[0]

    def __init__(self, rest_client_config=None, mindsphere_credentials=None):
        self.rest_client_config = rest_client_config
        self.mindsphere_credentials = init_credentials(mindsphere_credentials)

    def delete_timeseries(self, request_object):
        """delete time series

        Delete time series data for a single entity and propertyset within a given time range. Data for all properties within a propertyset is deleted. 

        :param DeleteTimeseriesRequest request_object: It contains the below parameters --> |br| ( entity* - unique identifier of the entity ), |br| ( propertysetname* - name of the propertyset ), |br| ( from* - beginning of the timerange to delete (exclusive) ), |br| ( to* - end of the timerange to delete (inclusive) )

        :return: None
        """
        logger.info('TimeSeriesClient.delete_timeseries() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `delete_timeseries`')

        if request_object.entity is None:
            raise exceptions.MindsphereClientError('The required parameter `entity` is missing from `request_object`, when calling `delete_timeseries`')

        if request_object.propertysetname is None:
            raise exceptions.MindsphereClientError('The required parameter `propertysetname` is missing from `request_object`, when calling `delete_timeseries`')

        if request_object._from is None:
            raise exceptions.MindsphereClientError('The required parameter `from` is missing from `request_object`, when calling `delete_timeseries`')

        if request_object.to is None:
            raise exceptions.MindsphereClientError('The required parameter `to` is missing from `request_object`, when calling `delete_timeseries`')

        end_point_url = '/timeseries/{entity}/{propertysetname}'
        end_point_url = end_point_url.format(entity=request_object.entity, propertysetname=request_object.propertysetname)
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + str(token)}
        query_params = {'from': request_object._from, 'to': request_object.to}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info('TimeSeriesClient.delete_timeseries()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'DELETE', query_params, form_params, body_params, local_var_files, None, self.__model_package__)

    def get_timeseries(self, request_object):
        """read time series

        Read time series data for a single entity and propertyset. Returns data for a specified time range. Returns the latest value if no range is provided. 

        :param GetTimeseriesRequest request_object: It contains the below parameters --> |br| ( entity* - unique identifier of the entity ), |br| ( propertysetname* - name of the propertyset ), |br| ( from - beginning of the time range to read (exclusive) ), |br| ( to - end of the time range to read (inclusive) ), |br| ( limit - maximum number of entries to read ), |br| ( select - select fields to return ), |br| ( sort - sort order by time, permissible values are <b>asc</b> and <b>desc</b> )

        :return: list[Timeseries]
        """
        logger.info('TimeSeriesClient.get_timeseries() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `get_timeseries`')

        if request_object.entity is None:
            raise exceptions.MindsphereClientError('The required parameter `entity` is missing from `request_object`, when calling `get_timeseries`')

        if request_object.propertysetname is None:
            raise exceptions.MindsphereClientError('The required parameter `propertysetname` is missing from `request_object`, when calling `get_timeseries`')

        end_point_url = '/timeseries/{entity}/{propertysetname}'
        end_point_url = end_point_url.format(entity=request_object.entity, propertysetname=request_object.propertysetname)
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + str(token)}
        query_params = {'from': request_object._from, 'to': request_object.to, 'limit': request_object.limit, 'select': request_object.select, 'sort': request_object.sort}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info('TimeSeriesClient.get_timeseries()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'GET', query_params, form_params, body_params, local_var_files, 'list[Timeseries]', self.__model_package__)

    def put_timeseries(self, request_object):
        """write or update time series

        Write or update time series data for a single entity and propertyset. Existing time series data is overwritten. Data for all properties within a propertyset needs to be provided together. 

        :param PutTimeseriesRequest request_object: It contains the below parameters --> |br| ( entity* - unique identifier of the entity ), |br| ( propertysetname* - name of the propertyset ), |br| ( timeseries* - time series data array )

        :return: None
        """
        logger.info('TimeSeriesClient.put_timeseries() invoked.')
        if request_object is None:
            raise exceptions.MindsphereClientError('`request_object` is not passed when calling `put_timeseries`')

        if request_object.entity is None:
            raise exceptions.MindsphereClientError('The required parameter `entity` is missing from `request_object`, when calling `put_timeseries`')

        if request_object.propertysetname is None:
            raise exceptions.MindsphereClientError('The required parameter `propertysetname` is missing from `request_object`, when calling `put_timeseries`')

        if request_object.timeseries is None:
            raise exceptions.MindsphereClientError('The required parameter `timeseries` is missing from `request_object`, when calling `put_timeseries`')

        end_point_url = '/timeseries/{entity}/{propertysetname}'
        end_point_url = end_point_url.format(entity=request_object.entity, propertysetname=request_object.propertysetname)
        token = token_service.fetch_token(self.rest_client_config, self.mindsphere_credentials)
        api_url = mindsphere_core.build_url(self.__base_path__, end_point_url, self.rest_client_config)
        headers = {'Accept': 'application/json', 'Content-Type': 'application/json', 'Authorization': 'Bearer ' + str(token)}
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, request_object.timeseries

        logger.info('TimeSeriesClient.put_timeseries()  --> Proceeding for API Invoker.')
        return mindsphere_core.invoke_service(self.rest_client_config, api_url, headers, 'PUT', query_params, form_params, body_params, local_var_files, None, self.__model_package__)

