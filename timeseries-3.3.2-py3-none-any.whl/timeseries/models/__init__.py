# coding: utf-8

# flake8: noqa
"""
    IoT Time Series API

    Store and query time series data with a precision of 1 millisecond.  # noqa: E501
"""


from __future__ import absolute_import

# import models into model package
from timeseries.models.badrequest import Badrequest
from timeseries.models.delete_timeseries_request import DeleteTimeseriesRequest
from timeseries.models.error import Error
from timeseries.models.get_timeseries_request import GetTimeseriesRequest
from timeseries.models.notfound import Notfound
from timeseries.models.put_timeseries_request import PutTimeseriesRequest
from timeseries.models.timeseries import Timeseries
from timeseries.models.toomanyrequests import Toomanyrequests
from timeseries.models.unauthorized import Unauthorized
