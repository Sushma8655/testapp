# coding: utf-8

"""
    IoT Time Series API

    Store and query time series data with a precision of 1 millisecond.  # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class GetTimeseriesRequest(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        'select': 'str',
        'limit': 'int',
        '_from': 'str',
        'to': 'str',
        'sort': 'str',
        'entity': 'str',
        'propertysetname': 'str'
    }

    attribute_map = {
        'select': 'select',
        'limit': 'limit',
        '_from': 'from',
        'to': 'to',
        'sort': 'sort',
        'entity': 'entity',
        'propertysetname': 'propertysetname'
    }

    def __init__(self, select=None, limit=None, _from=None, to=None, sort=None, entity=None, propertysetname=None):
        self._select = select
        self._limit = limit
        self.__from = _from
        self._to = to
        self._sort = sort
        self._entity = entity
        self._propertysetname = propertysetname
        self.discriminator = None

    @property
    def select(self):
        """Gets the select of this GetTimeseriesRequest.

        :return: The select of this GetTimeseriesRequest.
        :rtype: str
        """
        return self._select

    @select.setter
    def select(self, select):
        """Sets the select of this GetTimeseriesRequest.

        :param select: The select of this GetTimeseriesRequest.
        :type: str
        """

        self._select = select

    @property
    def limit(self):
        """Gets the limit of this GetTimeseriesRequest.

        :return: The limit of this GetTimeseriesRequest.
        :rtype: int
        """
        return self._limit

    @limit.setter
    def limit(self, limit):
        """Sets the limit of this GetTimeseriesRequest.

        :param limit: The limit of this GetTimeseriesRequest.
        :type: int
        """

        self._limit = limit

    @property
    def _from(self):
        """Gets the _from of this GetTimeseriesRequest.

        :return: The _from of this GetTimeseriesRequest.
        :rtype: str
        """
        return self.__from

    @_from.setter
    def _from(self, _from):
        """Sets the _from of this GetTimeseriesRequest.

        :param _from: The _from of this GetTimeseriesRequest.
        :type: str
        """

        self.__from = _from

    @property
    def to(self):
        """Gets the to of this GetTimeseriesRequest.

        :return: The to of this GetTimeseriesRequest.
        :rtype: str
        """
        return self._to

    @to.setter
    def to(self, to):
        """Sets the to of this GetTimeseriesRequest.

        :param to: The to of this GetTimeseriesRequest.
        :type: str
        """

        self._to = to

    @property
    def sort(self):
        """Gets the sort of this GetTimeseriesRequest.

        :return: The sort of this GetTimeseriesRequest.
        :rtype: str
        """
        return self._sort

    @sort.setter
    def sort(self, sort):
        """Sets the sort of this GetTimeseriesRequest.

        :param sort: The sort of this GetTimeseriesRequest.
        :type: str
        """

        self._sort = sort

    @property
    def entity(self):
        """Gets the entity of this GetTimeseriesRequest.

        :return: The entity of this GetTimeseriesRequest.
        :rtype: str
        """
        return self._entity

    @entity.setter
    def entity(self, entity):
        """Sets the entity of this GetTimeseriesRequest.

        :param entity: The entity of this GetTimeseriesRequest.
        :type: str
        """

        self._entity = entity

    @property
    def propertysetname(self):
        """Gets the propertysetname of this GetTimeseriesRequest.

        :return: The propertysetname of this GetTimeseriesRequest.
        :rtype: str
        """
        return self._propertysetname

    @propertysetname.setter
    def propertysetname(self, propertysetname):
        """Sets the propertysetname of this GetTimeseriesRequest.

        :param propertysetname: The propertysetname of this GetTimeseriesRequest.
        :type: str
        """

        self._propertysetname = propertysetname

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(GetTimeseriesRequest, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, GetTimeseriesRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
