# coding: utf-8

"""
    IoT Time Series API

    Store and query time series data with a precision of 1 millisecond.  # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class DeleteTimeseriesRequest(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    attribute_types = {
        '_from': 'str',
        'to': 'str',
        'entity': 'str',
        'propertysetname': 'str'
    }

    attribute_map = {
        '_from': 'from',
        'to': 'to',
        'entity': 'entity',
        'propertysetname': 'propertysetname'
    }

    def __init__(self, _from=None, to=None, entity=None, propertysetname=None):
        self.__from = _from
        self._to = to
        self._entity = entity
        self._propertysetname = propertysetname
        self.discriminator = None

    @property
    def _from(self):
        """Gets the _from of this DeleteTimeseriesRequest.

        :return: The _from of this DeleteTimeseriesRequest.
        :rtype: str
        """
        return self.__from

    @_from.setter
    def _from(self, _from):
        """Sets the _from of this DeleteTimeseriesRequest.

        :param _from: The _from of this DeleteTimeseriesRequest.
        :type: str
        """

        self.__from = _from

    @property
    def to(self):
        """Gets the to of this DeleteTimeseriesRequest.

        :return: The to of this DeleteTimeseriesRequest.
        :rtype: str
        """
        return self._to

    @to.setter
    def to(self, to):
        """Sets the to of this DeleteTimeseriesRequest.

        :param to: The to of this DeleteTimeseriesRequest.
        :type: str
        """

        self._to = to

    @property
    def entity(self):
        """Gets the entity of this DeleteTimeseriesRequest.

        :return: The entity of this DeleteTimeseriesRequest.
        :rtype: str
        """
        return self._entity

    @entity.setter
    def entity(self, entity):
        """Sets the entity of this DeleteTimeseriesRequest.

        :param entity: The entity of this DeleteTimeseriesRequest.
        :type: str
        """

        self._entity = entity

    @property
    def propertysetname(self):
        """Gets the propertysetname of this DeleteTimeseriesRequest.

        :return: The propertysetname of this DeleteTimeseriesRequest.
        :rtype: str
        """
        return self._propertysetname

    @propertysetname.setter
    def propertysetname(self, propertysetname):
        """Sets the propertysetname of this DeleteTimeseriesRequest.

        :param propertysetname: The propertysetname of this DeleteTimeseriesRequest.
        :type: str
        """

        self._propertysetname = propertysetname

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                result[attr] = value
        if issubclass(DeleteTimeseriesRequest, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DeleteTimeseriesRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
