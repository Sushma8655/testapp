# coding: utf-8

"""
    MindConnect API

     MindConnect API provides following data ingestion functionalities:  # Data Point Mappings  Creating and managing mappings between an agent's data points and an entity's dynamic property to be able to upload TimeSeries data.   Each agent has data points with unique ids. The mapping is between to this id to an entity's dynamic property set's property.  - A data point can be mapped to many property of many property set of many entities.  - A property cannot be mapped from more than one data point.   - A propertyset can have mappings from many agents' many data points to its properties.  - The unit of the datapoint has to be same with the unit of the property.  - The type of the datapoint has to be same with the type of the property.   Whenever data source configuration of an agent is updated via Agent Management API; all mappings with __keepMapping__ attribute set gets their validity attribute updated and all mappings with __keepMapping__ attribute unset are deleted.   # Exchange  Exchanging time series, events, files and data source configuration data. Combination of different data types can be uploaded via exchange endpoint within  multipart body. Maximum size of exchange body is 10MBs.  # Diagnostic Activations  Management of Diagnostic Activations and querying Diagnostic Messages of time series, event, file and data source configuration requests.  - Maximum 5 agents per tenant can be activated for data ingestion tracking.  - For non-agents, the required permission allows to manage diagnostic activation resources of agents in the same tenant as in the token.  - For agents, only the diagnostic activation related to the agent can be managed. Agents are forbidden to view/change the resources of other agents in the same tenant.  - Agents are allowed to update activation for itself only. Users with sufficient scopes are allowed   # noqa: E501
"""


from __future__ import absolute_import

import unittest
from unittest.mock import MagicMock
from mindconnect.clients import DiagnosticInformationClient
from mindconnect.models import *
from tests.unit.test_util import TestUtil, MOCK_VALUE, MOCK_SUCCESS
from mindsphere_core.exceptions import MindsphereError
from mindsphere_core import TenantCredentials, mindsphere_core, token_service


class DiagnosticInformationClientUnitTest(unittest.TestCase):
    """DiagnosticInformationClient unit test stubs"""

    def setUp(self):
        credentials = TenantCredentials(client_id=MOCK_VALUE, client_secret=MOCK_VALUE, tenant=MOCK_VALUE)
        config = mindsphere_core.RestClientConfig(MOCK_VALUE, MOCK_VALUE)
        self.client = DiagnosticInformationClient(config, credentials)
        token_service._invoke_token_endpoint = MagicMock(return_value=MOCK_SUCCESS)

    def test_diagnostic_information_get(self):
        """Test case for diagnostic_information_get
        Get Diagnostic Information
        """
        package_name = "mindconnect.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = DiagnosticInformationGetRequest()
        response = self.client.diagnostic_information_get(request_object)
        self.assertEqual(200, response)


if __name__ == '__main__':
    unittest.main()
