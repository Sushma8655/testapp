# coding: utf-8

"""
    MindConnect API

     MindConnect API provides following data ingestion functionalities:  # Data Point Mappings  Creating and managing mappings between an agent's data points and an entity's dynamic property to be able to upload TimeSeries data.   Each agent has data points with unique ids. The mapping is between to this id to an entity's dynamic property set's property.  - A data point can be mapped to many property of many property set of many entities.  - A property cannot be mapped from more than one data point.   - A propertyset can have mappings from many agents' many data points to its properties.  - The unit of the datapoint has to be same with the unit of the property.  - The type of the datapoint has to be same with the type of the property.   Whenever data source configuration of an agent is updated via Agent Management API; all mappings with __keepMapping__ attribute set gets their validity attribute updated and all mappings with __keepMapping__ attribute unset are deleted.   # Exchange  Exchanging time series, events, files and data source configuration data. Combination of different data types can be uploaded via exchange endpoint within  multipart body. Maximum size of exchange body is 10MBs.  # Diagnostic Activations  Management of Diagnostic Activations and querying Diagnostic Messages of time series, event, file and data source configuration requests.  - Maximum 5 agents per tenant can be activated for data ingestion tracking.  - For non-agents, the required permission allows to manage diagnostic activation resources of agents in the same tenant as in the token.  - For agents, only the diagnostic activation related to the agent can be managed. Agents are forbidden to view/change the resources of other agents in the same tenant.  - Agents are allowed to update activation for itself only. Users with sufficient scopes are allowed   # noqa: E501
"""


from __future__ import absolute_import

import unittest
from unittest.mock import MagicMock
from mindconnect.clients import RecordRecoveryClient
from mindconnect.models import *
from tests.unit.test_util import TestUtil, MOCK_VALUE, MOCK_SUCCESS
from mindsphere_core.exceptions import MindsphereError
from mindsphere_core import TenantCredentials, mindsphere_core, token_service


class RecordRecoveryClientUnitTest(unittest.TestCase):
    """RecordRecoveryClient unit test stubs"""

    def setUp(self):
        credentials = TenantCredentials(client_id=MOCK_VALUE, client_secret=MOCK_VALUE, tenant=MOCK_VALUE)
        config = mindsphere_core.RestClientConfig(MOCK_VALUE, MOCK_VALUE)
        self.client = RecordRecoveryClient(config, credentials)
        token_service._invoke_token_endpoint = MagicMock(return_value=MOCK_SUCCESS)

    def test_recoverable_records_get(self):
        """Test case for recoverable_records_get
        Get all recoverable records
        """
        package_name = "mindconnect.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = RecoverableRecordsGetRequest()
        response = self.client.recoverable_records_get(request_object)
        self.assertEqual(200, response)

    def test_recoverable_records_id_delete(self):
        """Test case for recoverable_records_id_delete
        Delete a recoverable record
        """
        package_name = "mindconnect.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = RecoverableRecordsIdDeleteRequest()
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        response = self.client.recoverable_records_id_delete(request_object)
        self.assertEqual(200, response)

    def test_negative_recoverable_records_id_delete(self):
        """Negative test case for recoverable_records_id_delete
        Delete a recoverable record
        """
        request_object = RecoverableRecordsIdDeleteRequest()
        with self.assertRaises(MindsphereError):
            self.client.recoverable_records_id_delete(request_object)

    def test_negative_request_recoverable_records_id_delete(self):
        """Negative test case for recoverable_records_id_delete
        Delete a recoverable record
        """
        with self.assertRaises(MindsphereError):
            self.client.recoverable_records_id_delete(None)

    def test_recoverable_records_id_download_link_get(self):
        """Test case for recoverable_records_id_download_link_get
        Get download link of record payload.
        """
        package_name = "mindconnect.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = RecoverableRecordsIdDownloadLinkGetRequest()
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        response = self.client.recoverable_records_id_download_link_get(request_object)
        self.assertEqual(200, response)

    def test_negative_recoverable_records_id_download_link_get(self):
        """Negative test case for recoverable_records_id_download_link_get
        Get download link of record payload.
        """
        request_object = RecoverableRecordsIdDownloadLinkGetRequest()
        with self.assertRaises(MindsphereError):
            self.client.recoverable_records_id_download_link_get(request_object)

    def test_negative_request_recoverable_records_id_download_link_get(self):
        """Negative test case for recoverable_records_id_download_link_get
        Get download link of record payload.
        """
        with self.assertRaises(MindsphereError):
            self.client.recoverable_records_id_download_link_get(None)

    def test_recoverable_records_id_replay_post(self):
        """Test case for recoverable_records_id_replay_post
        Re-play a recoverable record
        """
        package_name = "mindconnect.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = RecoverableRecordsIdReplayPostRequest()
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        response = self.client.recoverable_records_id_replay_post(request_object)
        self.assertEqual(200, response)

    def test_negative_recoverable_records_id_replay_post(self):
        """Negative test case for recoverable_records_id_replay_post
        Re-play a recoverable record
        """
        request_object = RecoverableRecordsIdReplayPostRequest()
        with self.assertRaises(MindsphereError):
            self.client.recoverable_records_id_replay_post(request_object)

    def test_negative_request_recoverable_records_id_replay_post(self):
        """Negative test case for recoverable_records_id_replay_post
        Re-play a recoverable record
        """
        with self.assertRaises(MindsphereError):
            self.client.recoverable_records_id_replay_post(None)


if __name__ == '__main__':
    unittest.main()
