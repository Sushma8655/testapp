# coding: utf-8

"""
    MindConnect API

     MindConnect API provides following data ingestion functionalities:  # Data Point Mappings  Creating and managing mappings between an agent's data points and an entity's dynamic property to be able to upload TimeSeries data.   Each agent has data points with unique ids. The mapping is between to this id to an entity's dynamic property set's property.  - A data point can be mapped to many property of many property set of many entities.  - A property cannot be mapped from more than one data point.   - A propertyset can have mappings from many agents' many data points to its properties.  - The unit of the datapoint has to be same with the unit of the property.  - The type of the datapoint has to be same with the type of the property.   Whenever data source configuration of an agent is updated via Agent Management API; all mappings with __keepMapping__ attribute set gets their validity attribute updated and all mappings with __keepMapping__ attribute unset are deleted.   # Exchange  Exchanging time series, events, files and data source configuration data. Combination of different data types can be uploaded via exchange endpoint within  multipart body. Maximum size of exchange body is 10MBs.  # Diagnostic Activations  Management of Diagnostic Activations and querying Diagnostic Messages of time series, event, file and data source configuration requests.  - Maximum 5 agents per tenant can be activated for data ingestion tracking.  - For non-agents, the required permission allows to manage diagnostic activation resources of agents in the same tenant as in the token.  - For agents, only the diagnostic activation related to the agent can be managed. Agents are forbidden to view/change the resources of other agents in the same tenant.  - Agents are allowed to update activation for itself only. Users with sufficient scopes are allowed   # noqa: E501
"""


from __future__ import absolute_import

import unittest
from unittest.mock import MagicMock
from mindconnect.clients import DiagnosticActivationsClient
from mindconnect.models import *
from tests.unit.test_util import TestUtil, MOCK_VALUE, MOCK_SUCCESS
from mindsphere_core.exceptions import MindsphereError
from mindsphere_core import TenantCredentials, mindsphere_core, token_service


class DiagnosticActivationsClientUnitTest(unittest.TestCase):
    """DiagnosticActivationsClient unit test stubs"""

    def setUp(self):
        credentials = TenantCredentials(client_id=MOCK_VALUE, client_secret=MOCK_VALUE, tenant=MOCK_VALUE)
        config = mindsphere_core.RestClientConfig(MOCK_VALUE, MOCK_VALUE)
        self.client = DiagnosticActivationsClient(config, credentials)
        token_service._invoke_token_endpoint = MagicMock(return_value=MOCK_SUCCESS)

    def test_diagnostic_activations_get(self):
        """Test case for diagnostic_activations_get
        Gets diagnostic activations 
        """
        package_name = "mindconnect.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = DiagnosticActivationsGetRequest()
        response = self.client.diagnostic_activations_get(request_object)
        self.assertEqual(200, response)

    def test_diagnostic_activations_id_delete(self):
        """Test case for diagnostic_activations_id_delete
        Deletes a diagnostic activation 
        """
        package_name = "mindconnect.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = DiagnosticActivationsIdDeleteRequest()
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        response = self.client.diagnostic_activations_id_delete(request_object)
        self.assertEqual(200, response)

    def test_negative_diagnostic_activations_id_delete(self):
        """Negative test case for diagnostic_activations_id_delete
        Deletes a diagnostic activation 
        """
        request_object = DiagnosticActivationsIdDeleteRequest()
        with self.assertRaises(MindsphereError):
            self.client.diagnostic_activations_id_delete(request_object)

    def test_negative_request_diagnostic_activations_id_delete(self):
        """Negative test case for diagnostic_activations_id_delete
        Deletes a diagnostic activation 
        """
        with self.assertRaises(MindsphereError):
            self.client.diagnostic_activations_id_delete(None)

    def test_diagnostic_activations_id_get(self):
        """Test case for diagnostic_activations_id_get
        Gets a diagnostic activation.   
        """
        package_name = "mindconnect.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = DiagnosticActivationsIdGetRequest()
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        response = self.client.diagnostic_activations_id_get(request_object)
        self.assertEqual(200, response)

    def test_negative_diagnostic_activations_id_get(self):
        """Negative test case for diagnostic_activations_id_get
        Gets a diagnostic activation.   
        """
        request_object = DiagnosticActivationsIdGetRequest()
        with self.assertRaises(MindsphereError):
            self.client.diagnostic_activations_id_get(request_object)

    def test_negative_request_diagnostic_activations_id_get(self):
        """Negative test case for diagnostic_activations_id_get
        Gets a diagnostic activation.   
        """
        with self.assertRaises(MindsphereError):
            self.client.diagnostic_activations_id_get(None)

    def test_diagnostic_activations_id_messages_get(self):
        """Test case for diagnostic_activations_id_messages_get
        Get a diagnostic messages of specific activation resource 
        """
        package_name = "mindconnect.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = DiagnosticActivationsIdMessagesGetRequest()
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        response = self.client.diagnostic_activations_id_messages_get(request_object)
        self.assertEqual(200, response)

    def test_negative_diagnostic_activations_id_messages_get(self):
        """Negative test case for diagnostic_activations_id_messages_get
        Get a diagnostic messages of specific activation resource 
        """
        request_object = DiagnosticActivationsIdMessagesGetRequest()
        with self.assertRaises(MindsphereError):
            self.client.diagnostic_activations_id_messages_get(request_object)

    def test_negative_request_diagnostic_activations_id_messages_get(self):
        """Negative test case for diagnostic_activations_id_messages_get
        Get a diagnostic messages of specific activation resource 
        """
        with self.assertRaises(MindsphereError):
            self.client.diagnostic_activations_id_messages_get(None)

    def test_diagnostic_activations_id_put(self):
        """Test case for diagnostic_activations_id_put
        Update status of Diagnostic Activation 
        """
        package_name = "mindconnect.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = DiagnosticActivationsIdPutRequest()
        request_object.id = TestUtil.get_mock_data(package_name, "str")
        request_object.diagnostic_activation_status = TestUtil.get_mock_data(package_name, "DiagnosticActivationStatus")
        response = self.client.diagnostic_activations_id_put(request_object)
        self.assertEqual(200, response)

    def test_negative_diagnostic_activations_id_put(self):
        """Negative test case for diagnostic_activations_id_put
        Update status of Diagnostic Activation 
        """
        request_object = DiagnosticActivationsIdPutRequest()
        with self.assertRaises(MindsphereError):
            self.client.diagnostic_activations_id_put(request_object)

    def test_negative_request_diagnostic_activations_id_put(self):
        """Negative test case for diagnostic_activations_id_put
        Update status of Diagnostic Activation 
        """
        with self.assertRaises(MindsphereError):
            self.client.diagnostic_activations_id_put(None)

    def test_diagnostic_activations_post(self):
        """Test case for diagnostic_activations_post
        Creates a new diagnostic activation 
        """
        package_name = "mindconnect.models"
        mindsphere_core.invoke_service = MagicMock(return_value=200)
        request_object = DiagnosticActivationsPostRequest()
        request_object.diagnostic_activation = TestUtil.get_mock_data(package_name, "DiagnosticActivation")
        response = self.client.diagnostic_activations_post(request_object)
        self.assertEqual(200, response)

    def test_negative_diagnostic_activations_post(self):
        """Negative test case for diagnostic_activations_post
        Creates a new diagnostic activation 
        """
        request_object = DiagnosticActivationsPostRequest()
        with self.assertRaises(MindsphereError):
            self.client.diagnostic_activations_post(request_object)

    def test_negative_request_diagnostic_activations_post(self):
        """Negative test case for diagnostic_activations_post
        Creates a new diagnostic activation 
        """
        with self.assertRaises(MindsphereError):
            self.client.diagnostic_activations_post(None)


if __name__ == '__main__':
    unittest.main()
