import unittest
from mindsphere_core import mindsphere_core

from mindconnect import DiagnosticInformationGetRequest
from mindconnect.clients import DiagnosticInformationClient


class DiagnosticInformationClientAPITest(unittest.TestCase):
    def setUp(self):
        config = mindsphere_core.RestClientConfig("194.138.0.25", "9400")
        self.client = DiagnosticInformationClient(rest_client_config=config)

    def test_diagnostic_information_get(self):

        requestObject = DiagnosticInformationGetRequest()
        response = self.client.diagnostic_information_get(requestObject)
        print(response)


    def test_diagnostic_information_withsize(self):

        requestObject = DiagnosticInformationGetRequest()
        requestObject.size = 2
        response = self.client.diagnostic_information_get(requestObject)
        print(response)

    def test_diagnostic_information_withsort(self):
        requestObject = DiagnosticInformationGetRequest()
        requestObject.sort = "asc"
        response = self.client.diagnostic_information_get(requestObject)
        print(response)


    def test_diagnostic_information_withpage(self):
        requestObject = DiagnosticInformationGetRequest()
        requestObject.page = 3
        response = self.client.diagnostic_information_get(requestObject)
        print(response)



if __name__ == "__main__":
    unittest.main()
