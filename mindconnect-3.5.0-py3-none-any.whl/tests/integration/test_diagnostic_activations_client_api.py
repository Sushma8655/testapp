import unittest
from mindsphere_core import mindsphere_core
from mindsphere_core.exceptions import MindsphereError

from mindconnect import DiagnosticActivationsClient, DiagnosticActivationsGetRequest, DiagnosticActivationsPostRequest, \
    DiagnosticActivation, DiagnosticActivationsIdDeleteRequest, DiagnosticActivationsIdGetRequest, \
    DiagnosticActivationsIdMessagesGetRequest, DiagnosticActivationsIdPutRequest, DiagnosticActivationStatus


class DiagnosticActivationsClientAPITest(unittest.TestCase):
    def setUp(self):
        config = mindsphere_core.RestClientConfig("194.138.0.25", "9400")
        self.client = DiagnosticActivationsClient(rest_client_config=config)

    def test_get(self):
        request_object = DiagnosticActivationsGetRequest()
        response = self.client.diagnostic_activations_get(request_object)
        print(response)
        self.assertIsNotNone(response)

    def test_getsort(self):
        request_object = DiagnosticActivationsGetRequest(
            size=20,
            sort="agentId,desc",
            page=0
        )
        response = self.client.diagnostic_activations_get(request_object)
        print(response)
        self.assertIsNotNone(response)

    def test_create(self):
        diagnosticActivation = DiagnosticActivation(
            agent_id="078b1908bc9347678168760934465587",
            status="ACTIVE"
        )
        request_object = DiagnosticActivationsPostRequest(
            diagnostic_activation=diagnosticActivation
        )
        response = self.client.diagnostic_activations_post(request_object)
        print(response)
        self.assertIsNotNone(response)

    def test_createNegative(self):
        request_object = DiagnosticActivationsPostRequest()

        with self.assertRaises(MindsphereError):
            self.client.diagnostic_activations_post(request_object)

    def test_delete(self):
        request_object = DiagnosticActivationsIdDeleteRequest(
            id="078b1908bc9347678168760934465587"
        )
        self.client.diagnostic_activations_id_delete(request_object)

    def test_deleteNegative(self):
        request_object = DiagnosticActivationsIdDeleteRequest()
        with self.assertRaises(MindsphereError):
            self.client.diagnostic_activations_id_delete(request_object)

    def test_getbyId(self):
        request_object = DiagnosticActivationsIdGetRequest(
            id="078b1908bc9347678168760934465587"
        )
        response = self.client.diagnostic_activations_id_get(request_object)
        print(response)
        self.assertIsNotNone(response)

    def test_getbyId_negative(self):
        request_object = DiagnosticActivationsIdGetRequest()
        with self.assertRaises(MindsphereError):
            self.client.diagnostic_activations_id_get(request_object)

    def test_getbyId_Message(self):
        request_object = DiagnosticActivationsIdMessagesGetRequest(
            id="078b1908bc9347678168760934465587"
        )
        response = self.client.diagnostic_activations_id_messages_get(request_object)
        print(response)
        self.assertIsNotNone(response)

    def test_getbyId_Message_negative(self):
        request_object = DiagnosticActivationsIdMessagesGetRequest()
        with self.assertRaises(MindsphereError):
            self.client.diagnostic_activations_id_messages_get(request_object)

    def test_putbyId(self):
        diagnosticActivationStatus = DiagnosticActivationStatus(
            status="INACTIVE"
        )
        request_object = DiagnosticActivationsIdPutRequest(
            id="078b1908bc9347678168760934465587",
            diagnostic_activation_status=diagnosticActivationStatus
        )
        response = self.client.diagnostic_activations_id_put(request_object)
        print(response)
        self.assertIsNotNone(response)

    def test_putbyIdNegaive(self):
        request_object = DiagnosticActivationsIdPutRequest()
        with self.assertRaises(MindsphereError):
            self.client.diagnostic_activations_id_put(request_object)


if __name__ == "__main__":
    unittest.main()
