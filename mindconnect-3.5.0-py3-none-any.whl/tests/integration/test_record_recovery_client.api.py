import unittest
from mindsphere_core import mindsphere_core
from mindsphere_core.exceptions import MindsphereError

from mindconnect import RecordRecoveryClient, RecoverableRecordsGetRequest, \
    RecoverableRecordsIdReplayPostRequest, RecoverableRecordsIdDownloadLinkGetRequest, RecoverableRecordsIdDeleteRequest


class RecordRecoveryClientAPITest(unittest.TestCase):
    def setUp(self):
        config = mindsphere_core.RestClientConfig("194.138.0.25", "9400")
        self.client = RecordRecoveryClient(rest_client_config=config)

    def test_post(self):
        request_object = RecoverableRecordsIdReplayPostRequest(
            id="078b1908bc934767816876093446558"
        )
        response = self.client.recoverable_records_id_replay_post(request_object)
        print(response)
        self.assertIsNotNone(response)

    def test_postNegative(self):
        request_object = RecoverableRecordsIdReplayPostRequest()
        with self.assertRaises(MindsphereError):
            self.client.recoverable_records_id_replay_post(request_object)

    def test_get(self):
        request_object = RecoverableRecordsGetRequest()
        response = self.client.recoverable_records_get(request_object)
        print(response)
        self.assertIsNotNone(response)

    def test_getbyId(self):
        request_object = RecoverableRecordsIdDownloadLinkGetRequest(
            id="078b1908bc934767816876093446558"
        )
        response = self.client.recoverable_records_id_download_link_get(request_object)
        print(response)
        self.assertIsNotNone(response)

    def test_getbyIdNegative(self):
        request_object = RecoverableRecordsIdDownloadLinkGetRequest()
        with self.assertRaises(MindsphereError):
            self.client.recoverable_records_id_download_link_get(request_object)

    def test_deletebyId(self):
        request_object = RecoverableRecordsIdDeleteRequest(
            id="078b1908bc934767816876093446558"
        )
        response = self.client.recoverable_records_id_delete(request_object)
        print(response)
        self.assertIsNotNone(response)

    def test_deletebyIdNegative(self):
        request_object = RecoverableRecordsIdDeleteRequest()
        with self.assertRaises(MindsphereError):
            self.client.recoverable_records_id_delete(request_object)


if __name__ == "__main__":
    unittest.main()
