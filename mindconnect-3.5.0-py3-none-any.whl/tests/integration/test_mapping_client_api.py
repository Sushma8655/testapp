import unittest
from mindsphere_core import mindsphere_core
from mindsphere_core.exceptions import MindsphereError

from mindconnect import MappingsClient, DataPointMappingsGetRequest, DataPointMappingsIdGetRequest, \
    DataPointMappingsPostRequest, Mapping, DataPointMappingsIdDeleteRequest


class MappingsClientAPITest(unittest.TestCase):
    def setUp(self):
        config = mindsphere_core.RestClientConfig("194.138.0.25", "9400")
        self.client = MappingsClient(rest_client_config=config)

    def test_get(self):
        request_object = DataPointMappingsGetRequest()
        response = self.client.data_point_mappings_get(request_object)
        print(response)
        self.assertIsNotNone(response)

    def test_getbyId(self):
        request_object = DataPointMappingsIdGetRequest(
            id="7d3aef34-268f-4d00-b23f-91c50ff945fb"
        )
        response = self.client.data_point_mappings_id_get(request_object)
        print(response)
        self.assertIsNotNone(response)

    def test_getbyIdNegative(self):
        request_object = DataPointMappingsIdGetRequest()
        with self.assertRaises(MindsphereError):
            self.client.data_point_mappings_id_get(request_object)

    def test_create(self):
        mapping = Mapping(
            agent_id="ad22f8a7ebb24b8fb41767afd2c63f08",
            data_point_id="SDKDP13",
            entity_id="078b1908bc9347678168760934465587",
            property_set_name="TyreTemperature",
            property_name="FLWheel",
            keep_mapping=False
        )
        request_object = DataPointMappingsPostRequest(
            mapping=mapping
        )
        response = self.client.data_point_mappings_post(request_object)
        print(response)
        self.assertIsNotNone(response)

    def test_createNegative(self):
        request_object = DataPointMappingsPostRequest()
        with self.assertRaises(MindsphereError):
            self.client.data_point_mappings_post(request_object)

    def test_deletebyId(self):
        request_object = DataPointMappingsIdDeleteRequest(
            id="7ec593ef-14d8-47ef-ad5a-c091320c4e06"
        )
        self.client.data_point_mappings_id_delete(request_object)

    def test_deletebyIdNegative(self):
        request_object = DataPointMappingsIdDeleteRequest()
        with self.assertRaises(MindsphereError):
            self.client.data_point_mappings_id_delete(request_object)


if __name__ == "__main__":
    unittest.main()
