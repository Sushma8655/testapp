# coding: utf-8

"""
    MindConnect API

     MindConnect API provides following data ingestion functionalities:  # Data Point Mappings  Creating and managing mappings between an agent's data points and an entity's dynamic property to be able to upload TimeSeries data.   Each agent has data points with unique ids. The mapping is between to this id to an entity's dynamic property set's property.  - A data point can be mapped to many property of many property set of many entities.  - A property cannot be mapped from more than one data point.   - A propertyset can have mappings from many agents' many data points to its properties.  - The unit of the datapoint has to be same with the unit of the property.  - The type of the datapoint has to be same with the type of the property.   Whenever data source configuration of an agent is updated via Agent Management API; all mappings with __keepMapping__ attribute set gets their validity attribute updated and all mappings with __keepMapping__ attribute unset are deleted.   # Exchange  Exchanging time series, events, files and data source configuration data. Combination of different data types can be uploaded via exchange endpoint within  multipart body. Maximum size of exchange body is 10MBs.  # Diagnostic Activations  Management of Diagnostic Activations and querying Diagnostic Messages of time series, event, file and data source configuration requests.  - Maximum 5 agents per tenant can be activated for data ingestion tracking.  - For non-agents, the required permission allows to manage diagnostic activation resources of agents in the same tenant as in the token.  - For agents, only the diagnostic activation related to the agent can be managed. Agents are forbidden to view/change the resources of other agents in the same tenant.  - Agents are allowed to update activation for itself only. Users with sufficient scopes are allowed   # noqa: E501
"""


from __future__ import absolute_import

from mindsphere_core.mindsphere_core import logger
from mindsphere_core import mindsphere_core, exceptions, token_service
from mindsphere_core.token_service import init_credentials


class RecordRecoveryClient:
    __base_path__ = "/api/mindconnect/v3"
    __model_package__ = __name__.split(".")[0]

    def __init__(self, rest_client_config=None, mindsphere_credentials=None):
        self.rest_client_config = rest_client_config
        self.mindsphere_credentials = init_credentials(mindsphere_credentials)

    def recoverable_records_get(self, request_object):
        """Get all recoverable records

        Gets all recoverable records 

        :param RecoverableRecordsGetRequest request_object: It contains the below parameters --> |br| ( filter - JSON based filter. ), |br| ( size - The maximum number of elements in a page. ), |br| ( page - The (0-based) index of page. ), |br| ( sort - The order of returned elements. Multiple fields could be used separated by commas (e.g. ''field1,field2''). Descending order could be requested by appending '',desc'' at the end of parameter.(e.g. ''field1,field2,desc'')'  )

        :return: PagedRecoverableRecords
        """
        logger.info("RecordRecoveryClient.recoverable_records_get() invoked.")

        end_point_url = "/recoverableRecords"
        end_point_url = end_point_url.format()
        token = token_service.fetch_token(
            self.rest_client_config, self.mindsphere_credentials
        )
        api_url = mindsphere_core.build_url(
            self.__base_path__, end_point_url, self.rest_client_config
        )
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + str(token),
        }
        query_params = {
            "filter": request_object.filter,
            "size": request_object.size,
            "page": request_object.page,
            "sort": request_object.sort,
        }
        form_params, local_var_files, body_params = {}, {}, None

        logger.info(
            "RecordRecoveryClient.recoverable_records_get()  --> Proceeding for API Invoker."
        )
        return mindsphere_core.invoke_service(
            self.rest_client_config,
            api_url,
            headers,
            "GET",
            query_params,
            form_params,
            body_params,
            local_var_files,
            "PagedRecoverableRecords",
            self.__model_package__,
        )

    def recoverable_records_id_delete(self, request_object):
        """Delete a recoverable record

        Deletes a recoverable record.   

        :param RecoverableRecordsIdDeleteRequest request_object: It contains the below parameters --> |br| ( id* - Unique identifier of the recoverable record. )

        :return: None
        """
        logger.info("RecordRecoveryClient.recoverable_records_id_delete() invoked.")
        if request_object is None:
            raise exceptions.MindsphereClientError(
                "`request_object` is not passed when calling `recoverable_records_id_delete`"
            )

        if request_object.id is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `id` is missing from `request_object`, when calling `recoverable_records_id_delete`"
            )

        end_point_url = "/recoverableRecords/{id}"
        end_point_url = end_point_url.format(id=request_object.id)
        token = token_service.fetch_token(
            self.rest_client_config, self.mindsphere_credentials
        )
        api_url = mindsphere_core.build_url(
            self.__base_path__, end_point_url, self.rest_client_config
        )
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + str(token),
        }
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info(
            "RecordRecoveryClient.recoverable_records_id_delete()  --> Proceeding for API Invoker."
        )
        return mindsphere_core.invoke_service(
            self.rest_client_config,
            api_url,
            headers,
            "DELETE",
            query_params,
            form_params,
            body_params,
            local_var_files,
            None,
            self.__model_package__,
        )

    def recoverable_records_id_download_link_get(self, request_object):
        """Get download link of record payload.

        Gets download link of record payload 

        :param RecoverableRecordsIdDownloadLinkGetRequest request_object: It contains the below parameters --> |br| ( id* - Unique identifier of the recoverable record. )

        :return: str
        """
        logger.info(
            "RecordRecoveryClient.recoverable_records_id_download_link_get() invoked."
        )
        if request_object is None:
            raise exceptions.MindsphereClientError(
                "`request_object` is not passed when calling `recoverable_records_id_download_link_get`"
            )

        if request_object.id is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `id` is missing from `request_object`, when calling `recoverable_records_id_download_link_get`"
            )

        end_point_url = "/recoverableRecords/{id}/downloadLink"
        end_point_url = end_point_url.format(id=request_object.id)
        token = token_service.fetch_token(
            self.rest_client_config, self.mindsphere_credentials
        )
        api_url = mindsphere_core.build_url(
            self.__base_path__, end_point_url, self.rest_client_config
        )
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + str(token),
        }
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info(
            "RecordRecoveryClient.recoverable_records_id_download_link_get()  --> Proceeding for API Invoker."
        )
        return mindsphere_core.invoke_service(
            self.rest_client_config,
            api_url,
            headers,
            "GET",
            query_params,
            form_params,
            body_params,
            local_var_files,
            "str",
            self.__model_package__,
        )

    def recoverable_records_id_replay_post(self, request_object):
        """Re-play a recoverable record

        Re-play a recoverable record.   

        :param RecoverableRecordsIdReplayPostRequest request_object: It contains the below parameters --> |br| ( id* - Unique identifier of the recoverable record. )

        :return: None
        """
        logger.info(
            "RecordRecoveryClient.recoverable_records_id_replay_post() invoked."
        )
        if request_object is None:
            raise exceptions.MindsphereClientError(
                "`request_object` is not passed when calling `recoverable_records_id_replay_post`"
            )

        if request_object.id is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `id` is missing from `request_object`, when calling `recoverable_records_id_replay_post`"
            )

        end_point_url = "/recoverableRecords/{id}/replay"
        end_point_url = end_point_url.format(id=request_object.id)
        token = token_service.fetch_token(
            self.rest_client_config, self.mindsphere_credentials
        )
        api_url = mindsphere_core.build_url(
            self.__base_path__, end_point_url, self.rest_client_config
        )
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + str(token),
        }
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info(
            "RecordRecoveryClient.recoverable_records_id_replay_post()  --> Proceeding for API Invoker."
        )
        return mindsphere_core.invoke_service(
            self.rest_client_config,
            api_url,
            headers,
            "POST",
            query_params,
            form_params,
            body_params,
            local_var_files,
            None,
            self.__model_package__,
        )
