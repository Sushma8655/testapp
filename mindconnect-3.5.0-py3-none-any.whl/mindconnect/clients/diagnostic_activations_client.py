# coding: utf-8

"""
    MindConnect API

     MindConnect API provides following data ingestion functionalities:  # Data Point Mappings  Creating and managing mappings between an agent's data points and an entity's dynamic property to be able to upload TimeSeries data.   Each agent has data points with unique ids. The mapping is between to this id to an entity's dynamic property set's property.  - A data point can be mapped to many property of many property set of many entities.  - A property cannot be mapped from more than one data point.   - A propertyset can have mappings from many agents' many data points to its properties.  - The unit of the datapoint has to be same with the unit of the property.  - The type of the datapoint has to be same with the type of the property.   Whenever data source configuration of an agent is updated via Agent Management API; all mappings with __keepMapping__ attribute set gets their validity attribute updated and all mappings with __keepMapping__ attribute unset are deleted.   # Exchange  Exchanging time series, events, files and data source configuration data. Combination of different data types can be uploaded via exchange endpoint within  multipart body. Maximum size of exchange body is 10MBs.  # Diagnostic Activations  Management of Diagnostic Activations and querying Diagnostic Messages of time series, event, file and data source configuration requests.  - Maximum 5 agents per tenant can be activated for data ingestion tracking.  - For non-agents, the required permission allows to manage diagnostic activation resources of agents in the same tenant as in the token.  - For agents, only the diagnostic activation related to the agent can be managed. Agents are forbidden to view/change the resources of other agents in the same tenant.  - Agents are allowed to update activation for itself only. Users with sufficient scopes are allowed   # noqa: E501
"""


from __future__ import absolute_import

from mindsphere_core.mindsphere_core import logger
from mindsphere_core import mindsphere_core, exceptions, token_service
from mindsphere_core.token_service import init_credentials


class DiagnosticActivationsClient:
    __base_path__ = "/api/mindconnect/v3"
    __model_package__ = __name__.split(".")[0]

    def __init__(self, rest_client_config=None, mindsphere_credentials=None):
        self.rest_client_config = rest_client_config
        self.mindsphere_credentials = init_credentials(mindsphere_credentials)

    def diagnostic_activations_get(self, request_object):
        """Gets diagnostic activations 

        Get diagnostic activations. Agents are allowed to get their own activation. Users with sufficient scopes are allowed to get all activations in the same tenant as in the token. 

        :param DiagnosticActivationsGetRequest request_object: It contains the below parameters --> |br| ( size - The maximum number of elements in a page. ), |br| ( page - The (0-based) index of page. ), |br| ( sort - The order of returned elements. Multiple fields could be used separated by commas (e.g. ''field1,field2''). Descending order could be requested by appending '',desc'' at the end of parameter.(e.g. ''field1,field2,desc'')'  )

        :return: PagedDiagnosticActivation
        """
        logger.info("DiagnosticActivationsClient.diagnostic_activations_get() invoked.")

        end_point_url = "/diagnosticActivations"
        end_point_url = end_point_url.format()
        token = token_service.fetch_token(
            self.rest_client_config, self.mindsphere_credentials
        )
        api_url = mindsphere_core.build_url(
            self.__base_path__, end_point_url, self.rest_client_config
        )
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + str(token),
        }
        query_params = {
            "size": request_object.size,
            "page": request_object.page,
            "sort": request_object.sort,
        }
        form_params, local_var_files, body_params = {}, {}, None

        logger.info(
            "DiagnosticActivationsClient.diagnostic_activations_get()  --> Proceeding for API Invoker."
        )
        return mindsphere_core.invoke_service(
            self.rest_client_config,
            api_url,
            headers,
            "GET",
            query_params,
            form_params,
            body_params,
            local_var_files,
            "PagedDiagnosticActivation",
            self.__model_package__,
        )

    def diagnostic_activations_id_delete(self, request_object):
        """Deletes a diagnostic activation 

        Delete a diagnostic activation. Agents are allowed to delete their own activation. Users with sufficient scopes are allowed to delete any activation in the same tenant as in the token. 

        :param DiagnosticActivationsIdDeleteRequest request_object: It contains the below parameters --> |br| ( id* - Unique identifier of diagnostic activation resource. )

        :return: None
        """
        logger.info(
            "DiagnosticActivationsClient.diagnostic_activations_id_delete() invoked."
        )
        if request_object is None:
            raise exceptions.MindsphereClientError(
                "`request_object` is not passed when calling `diagnostic_activations_id_delete`"
            )

        if request_object.id is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `id` is missing from `request_object`, when calling `diagnostic_activations_id_delete`"
            )

        end_point_url = "/diagnosticActivations/{id}"
        end_point_url = end_point_url.format(id=request_object.id)
        token = token_service.fetch_token(
            self.rest_client_config, self.mindsphere_credentials
        )
        api_url = mindsphere_core.build_url(
            self.__base_path__, end_point_url, self.rest_client_config
        )
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + str(token),
        }
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info(
            "DiagnosticActivationsClient.diagnostic_activations_id_delete()  --> Proceeding for API Invoker."
        )
        return mindsphere_core.invoke_service(
            self.rest_client_config,
            api_url,
            headers,
            "DELETE",
            query_params,
            form_params,
            body_params,
            local_var_files,
            None,
            self.__model_package__,
        )

    def diagnostic_activations_id_get(self, request_object):
        """Gets a diagnostic activation.   

        Get a diagnostic activation with given id.  Agents are allowed to get their own activation. Users with sufficient scopes are allowed to get any activation in the same tenant as in the token.   

        :param DiagnosticActivationsIdGetRequest request_object: It contains the below parameters --> |br| ( id* - Unique identifier of diagnostic activation resource. )

        :return: DiagnosticActivation
        """
        logger.info(
            "DiagnosticActivationsClient.diagnostic_activations_id_get() invoked."
        )
        if request_object is None:
            raise exceptions.MindsphereClientError(
                "`request_object` is not passed when calling `diagnostic_activations_id_get`"
            )

        if request_object.id is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `id` is missing from `request_object`, when calling `diagnostic_activations_id_get`"
            )

        end_point_url = "/diagnosticActivations/{id}"
        end_point_url = end_point_url.format(id=request_object.id)
        token = token_service.fetch_token(
            self.rest_client_config, self.mindsphere_credentials
        )
        api_url = mindsphere_core.build_url(
            self.__base_path__, end_point_url, self.rest_client_config
        )
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + str(token),
        }
        query_params = {}
        form_params, local_var_files, body_params = {}, {}, None

        logger.info(
            "DiagnosticActivationsClient.diagnostic_activations_id_get()  --> Proceeding for API Invoker."
        )
        return mindsphere_core.invoke_service(
            self.rest_client_config,
            api_url,
            headers,
            "GET",
            query_params,
            form_params,
            body_params,
            local_var_files,
            "DiagnosticActivation",
            self.__model_package__,
        )

    def diagnostic_activations_id_messages_get(self, request_object):
        """Get a diagnostic messages of specific activation resource 

        Get a diagnostic messages of specific activation resource. Agents are allowed to get their own activations' messages. Users with sufficient scopes are allowed to get any activations messages in the same tenant as in the token.   

        :param DiagnosticActivationsIdMessagesGetRequest request_object: It contains the below parameters --> |br| ( id* - Unique identifier of diagnostic activation resource. ), |br| ( filter - JSON based filter. Diagnostic messages can be filtered by the following fields  - `correlationId`  - `message`  - `source`  - `timestamp`  - `severity`  ), |br| ( size - The maximum number of elements in a page. ), |br| ( page - The (0-based) index of page. ), |br| ( sort - The order of returned elements. Multiple fields could be used separated by commas (e.g. ''field1,field2''). Descending order could be requested by appending '',desc'' at the end of parameter.(e.g. ''field1,field2,desc'')'  )

        :return: PagedDiagnosticInformationMessages
        """
        logger.info(
            "DiagnosticActivationsClient.diagnostic_activations_id_messages_get() invoked."
        )
        if request_object is None:
            raise exceptions.MindsphereClientError(
                "`request_object` is not passed when calling `diagnostic_activations_id_messages_get`"
            )

        if request_object.id is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `id` is missing from `request_object`, when calling `diagnostic_activations_id_messages_get`"
            )

        end_point_url = "/diagnosticActivations/{id}/messages"
        end_point_url = end_point_url.format(id=request_object.id)
        token = token_service.fetch_token(
            self.rest_client_config, self.mindsphere_credentials
        )
        api_url = mindsphere_core.build_url(
            self.__base_path__, end_point_url, self.rest_client_config
        )
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + str(token),
        }
        query_params = {
            "filter": request_object.filter,
            "size": request_object.size,
            "page": request_object.page,
            "sort": request_object.sort,
        }
        form_params, local_var_files, body_params = {}, {}, None

        logger.info(
            "DiagnosticActivationsClient.diagnostic_activations_id_messages_get()  --> Proceeding for API Invoker."
        )
        return mindsphere_core.invoke_service(
            self.rest_client_config,
            api_url,
            headers,
            "GET",
            query_params,
            form_params,
            body_params,
            local_var_files,
            "PagedDiagnosticInformationMessages",
            self.__model_package__,
        )

    def diagnostic_activations_id_put(self, request_object):
        """Update status of Diagnostic Activation 

        Updates status of Diagnostic Activation. 

        :param DiagnosticActivationsIdPutRequest request_object: It contains the below parameters --> |br| ( id* - Unique identifier of diagnostic activation resource. ), |br| ( diagnosticActivationStatus* - Object describing updated diagnostic activation status. )

        :return: DiagnosticActivation
        """
        logger.info(
            "DiagnosticActivationsClient.diagnostic_activations_id_put() invoked."
        )
        if request_object is None:
            raise exceptions.MindsphereClientError(
                "`request_object` is not passed when calling `diagnostic_activations_id_put`"
            )

        if request_object.id is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `id` is missing from `request_object`, when calling `diagnostic_activations_id_put`"
            )

        if request_object.diagnostic_activation_status is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `diagnosticActivationStatus` is missing from `request_object`, when calling `diagnostic_activations_id_put`"
            )

        end_point_url = "/diagnosticActivations/{id}"
        end_point_url = end_point_url.format(id=request_object.id)
        token = token_service.fetch_token(
            self.rest_client_config, self.mindsphere_credentials
        )
        api_url = mindsphere_core.build_url(
            self.__base_path__, end_point_url, self.rest_client_config
        )
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + str(token),
        }
        query_params = {}
        form_params, local_var_files, body_params = (
            {},
            {},
            request_object.diagnostic_activation_status,
        )

        logger.info(
            "DiagnosticActivationsClient.diagnostic_activations_id_put()  --> Proceeding for API Invoker."
        )
        return mindsphere_core.invoke_service(
            self.rest_client_config,
            api_url,
            headers,
            "PUT",
            query_params,
            form_params,
            body_params,
            local_var_files,
            "DiagnosticActivation",
            self.__model_package__,
        )

    def diagnostic_activations_post(self, request_object):
        """Creates a new diagnostic activation 

        Create a new diagnostic activation.  Agents are allowed to create activation for itself only. Users with sufficient scopes are allowed to create activations of the agents in the same tenant as in the token. 

        :param DiagnosticActivationsPostRequest request_object: It contains the below parameters --> |br| ( diagnosticActivation* - Object describing new diagnostic activation resource. )

        :return: DiagnosticActivation
        """
        logger.info(
            "DiagnosticActivationsClient.diagnostic_activations_post() invoked."
        )
        if request_object is None:
            raise exceptions.MindsphereClientError(
                "`request_object` is not passed when calling `diagnostic_activations_post`"
            )

        if request_object.diagnostic_activation is None:
            raise exceptions.MindsphereClientError(
                "The required parameter `diagnosticActivation` is missing from `request_object`, when calling `diagnostic_activations_post`"
            )

        end_point_url = "/diagnosticActivations"
        end_point_url = end_point_url.format()
        token = token_service.fetch_token(
            self.rest_client_config, self.mindsphere_credentials
        )
        api_url = mindsphere_core.build_url(
            self.__base_path__, end_point_url, self.rest_client_config
        )
        headers = {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Authorization": "Bearer " + str(token),
        }
        query_params = {}
        form_params, local_var_files, body_params = (
            {},
            {},
            request_object.diagnostic_activation,
        )

        logger.info(
            "DiagnosticActivationsClient.diagnostic_activations_post()  --> Proceeding for API Invoker."
        )
        return mindsphere_core.invoke_service(
            self.rest_client_config,
            api_url,
            headers,
            "POST",
            query_params,
            form_params,
            body_params,
            local_var_files,
            "DiagnosticActivation",
            self.__model_package__,
        )
