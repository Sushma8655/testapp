# coding: utf-8

"""
    MindConnect API

     MindConnect API provides following data ingestion functionalities:  # Data Point Mappings  Creating and managing mappings between an agent's data points and an entity's dynamic property to be able to upload TimeSeries data.   Each agent has data points with unique ids. The mapping is between to this id to an entity's dynamic property set's property.  - A data point can be mapped to many property of many property set of many entities.  - A property cannot be mapped from more than one data point.   - A propertyset can have mappings from many agents' many data points to its properties.  - The unit of the datapoint has to be same with the unit of the property.  - The type of the datapoint has to be same with the type of the property.   Whenever data source configuration of an agent is updated via Agent Management API; all mappings with __keepMapping__ attribute set gets their validity attribute updated and all mappings with __keepMapping__ attribute unset are deleted.   # Exchange  Exchanging time series, events, files and data source configuration data. Combination of different data types can be uploaded via exchange endpoint within  multipart body. Maximum size of exchange body is 10MBs.  # Diagnostic Activations  Management of Diagnostic Activations and querying Diagnostic Messages of time series, event, file and data source configuration requests.  - Maximum 5 agents per tenant can be activated for data ingestion tracking.  - For non-agents, the required permission allows to manage diagnostic activation resources of agents in the same tenant as in the token.  - For agents, only the diagnostic activation related to the agent can be managed. Agents are forbidden to view/change the resources of other agents in the same tenant.  - Agents are allowed to update activation for itself only. Users with sufficient scopes are allowed   # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class Mapping(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """

    attribute_types = {
        "id": "str",
        "agent_id": "str",
        "data_point_id": "str",
        "data_point_unit": "str",
        "data_point_type": "str",
        "entity_id": "str",
        "property_set_name": "str",
        "property_name": "str",
        "property_unit": "str",
        "property_type": "str",
        "quality_enabled": "bool",
        "keep_mapping": "bool",
    }

    attribute_map = {
        "id": "id",
        "agent_id": "agentId",
        "data_point_id": "dataPointId",
        "data_point_unit": "dataPointUnit",
        "data_point_type": "dataPointType",
        "entity_id": "entityId",
        "property_set_name": "propertySetName",
        "property_name": "propertyName",
        "property_unit": "propertyUnit",
        "property_type": "propertyType",
        "quality_enabled": "qualityEnabled",
        "keep_mapping": "keepMapping",
    }

    def __init__(
        self,
        id=None,
        agent_id=None,
        data_point_id=None,
        data_point_unit=None,
        data_point_type=None,
        entity_id=None,
        property_set_name=None,
        property_name=None,
        property_unit=None,
        property_type=None,
        quality_enabled=None,
        keep_mapping=False,
    ):
        self._id = id
        self._agent_id = agent_id
        self._data_point_id = data_point_id
        self._data_point_unit = data_point_unit
        self._data_point_type = data_point_type
        self._entity_id = entity_id
        self._property_set_name = property_set_name
        self._property_name = property_name
        self._property_unit = property_unit
        self._property_type = property_type
        self._quality_enabled = quality_enabled
        self._keep_mapping = keep_mapping
        self.discriminator = None

    @property
    def id(self):
        """Gets the id of this Mapping.
        Unique identifier of the mapping resource

        :return: The id of this Mapping.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        """Sets the id of this Mapping.
        Unique identifier of the mapping resource

        :param id: The id of this Mapping.
        :type: str
        """

        self._id = id

    @property
    def agent_id(self):
        """Gets the agent_id of this Mapping.
        Unique identifier of the agent

        :return: The agent_id of this Mapping.
        :rtype: str
        """
        return self._agent_id

    @agent_id.setter
    def agent_id(self, agent_id):
        """Sets the agent_id of this Mapping.
        Unique identifier of the agent

        :param agent_id: The agent_id of this Mapping.
        :type: str
        """
        if agent_id is None:
            raise MindsphereClientError(
                "Invalid value for `agent_id`, must not be `None`"
            )

        self._agent_id = agent_id

    @property
    def data_point_id(self):
        """Gets the data_point_id of this Mapping.
        Unique identifier of the data point

        :return: The data_point_id of this Mapping.
        :rtype: str
        """
        return self._data_point_id

    @data_point_id.setter
    def data_point_id(self, data_point_id):
        """Sets the data_point_id of this Mapping.
        Unique identifier of the data point

        :param data_point_id: The data_point_id of this Mapping.
        :type: str
        """
        if data_point_id is None:
            raise MindsphereClientError(
                "Invalid value for `data_point_id`, must not be `None`"
            )
        if data_point_id is not None and len(data_point_id) > 36:
            raise MindsphereClientError(
                "Invalid value for `data_point_id`, length must be less than or equal to `36`"
            )

        self._data_point_id = data_point_id

    @property
    def data_point_unit(self):
        """Gets the data_point_unit of this Mapping.
        Unit of the data point

        :return: The data_point_unit of this Mapping.
        :rtype: str
        """
        return self._data_point_unit

    @data_point_unit.setter
    def data_point_unit(self, data_point_unit):
        """Sets the data_point_unit of this Mapping.
        Unit of the data point

        :param data_point_unit: The data_point_unit of this Mapping.
        :type: str
        """
        if data_point_unit is not None and len(data_point_unit) > 32:
            raise MindsphereClientError(
                "Invalid value for `data_point_unit`, length must be less than or equal to `32`"
            )

        self._data_point_unit = data_point_unit

    @property
    def data_point_type(self):
        """Gets the data_point_type of this Mapping.
        Type of the data point

        :return: The data_point_type of this Mapping.
        :rtype: str
        """
        return self._data_point_type

    @data_point_type.setter
    def data_point_type(self, data_point_type):
        """Sets the data_point_type of this Mapping.
        Type of the data point

        :param data_point_type: The data_point_type of this Mapping.
        :type: str
        """
        allowed_values = [
            "INT",
            "LONG",
            "DOUBLE",
            "BOOLEAN",
            "STRING",
            "BIG_STRING",
            "TIMESTAMP",
        ]
        if data_point_type.lower() not in [x.lower() for x in allowed_values]:
            raise MindsphereClientError(
                "Invalid value for `data_point_type` ({0}), must be one of {1}".format(
                    data_point_type, allowed_values
                )
            )

        self._data_point_type = data_point_type

    @property
    def entity_id(self):
        """Gets the entity_id of this Mapping.
        Unique identifier of the entity

        :return: The entity_id of this Mapping.
        :rtype: str
        """
        return self._entity_id

    @entity_id.setter
    def entity_id(self, entity_id):
        """Sets the entity_id of this Mapping.
        Unique identifier of the entity

        :param entity_id: The entity_id of this Mapping.
        :type: str
        """
        if entity_id is None:
            raise MindsphereClientError(
                "Invalid value for `entity_id`, must not be `None`"
            )

        self._entity_id = entity_id

    @property
    def property_set_name(self):
        """Gets the property_set_name of this Mapping.

        :return: The property_set_name of this Mapping.
        :rtype: str
        """
        return self._property_set_name

    @property_set_name.setter
    def property_set_name(self, property_set_name):
        """Sets the property_set_name of this Mapping.

        :param property_set_name: The property_set_name of this Mapping.
        :type: str
        """
        if property_set_name is None:
            raise MindsphereClientError(
                "Invalid value for `property_set_name`, must not be `None`"
            )
        if property_set_name is not None and len(property_set_name) > 256:
            raise MindsphereClientError(
                "Invalid value for `property_set_name`, length must be less than or equal to `256`"
            )

        self._property_set_name = property_set_name

    @property
    def property_name(self):
        """Gets the property_name of this Mapping.

        :return: The property_name of this Mapping.
        :rtype: str
        """
        return self._property_name

    @property_name.setter
    def property_name(self, property_name):
        """Sets the property_name of this Mapping.

        :param property_name: The property_name of this Mapping.
        :type: str
        """
        if property_name is None:
            raise MindsphereClientError(
                "Invalid value for `property_name`, must not be `None`"
            )
        if property_name is not None and len(property_name) > 256:
            raise MindsphereClientError(
                "Invalid value for `property_name`, length must be less than or equal to `256`"
            )

        self._property_name = property_name

    @property
    def property_unit(self):
        """Gets the property_unit of this Mapping.

        :return: The property_unit of this Mapping.
        :rtype: str
        """
        return self._property_unit

    @property_unit.setter
    def property_unit(self, property_unit):
        """Sets the property_unit of this Mapping.

        :param property_unit: The property_unit of this Mapping.
        :type: str
        """
        if property_unit is not None and len(property_unit) > 32:
            raise MindsphereClientError(
                "Invalid value for `property_unit`, length must be less than or equal to `32`"
            )

        self._property_unit = property_unit

    @property
    def property_type(self):
        """Gets the property_type of this Mapping.

        :return: The property_type of this Mapping.
        :rtype: str
        """
        return self._property_type

    @property_type.setter
    def property_type(self, property_type):
        """Sets the property_type of this Mapping.

        :param property_type: The property_type of this Mapping.
        :type: str
        """
        allowed_values = [
            "INT",
            "LONG",
            "DOUBLE",
            "BOOLEAN",
            "STRING",
            "BIG_STRING",
            "TIMESTAMP",
        ]
        if property_type.lower() not in [x.lower() for x in allowed_values]:
            raise MindsphereClientError(
                "Invalid value for `property_type` ({0}), must be one of {1}".format(
                    property_type, allowed_values
                )
            )

        self._property_type = property_type

    @property
    def quality_enabled(self):
        """Gets the quality_enabled of this Mapping.

        :return: The quality_enabled of this Mapping.
        :rtype: bool
        """
        return self._quality_enabled

    @quality_enabled.setter
    def quality_enabled(self, quality_enabled):
        """Sets the quality_enabled of this Mapping.

        :param quality_enabled: The quality_enabled of this Mapping.
        :type: bool
        """

        self._quality_enabled = quality_enabled

    @property
    def keep_mapping(self):
        """Gets the keep_mapping of this Mapping.
        Identifies auto deleting mapping or keeping mapping.

        :return: The keep_mapping of this Mapping.
        :rtype: bool
        """
        return self._keep_mapping

    @keep_mapping.setter
    def keep_mapping(self, keep_mapping):
        """Sets the keep_mapping of this Mapping.
        Identifies auto deleting mapping or keeping mapping.

        :param keep_mapping: The keep_mapping of this Mapping.
        :type: bool
        """

        self._keep_mapping = keep_mapping

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(
                    map(lambda x: x.to_dict() if hasattr(x, "to_dict") else x, value)
                )
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(
                    map(
                        lambda item: (item[0], item[1].to_dict())
                        if hasattr(item[1], "to_dict")
                        else item,
                        value.items(),
                    )
                )
            else:
                result[attr] = value
        if issubclass(Mapping, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, Mapping):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
