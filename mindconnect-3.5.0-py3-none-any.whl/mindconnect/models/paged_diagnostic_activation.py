# coding: utf-8

"""
    MindConnect API

     MindConnect API provides following data ingestion functionalities:  # Data Point Mappings  Creating and managing mappings between an agent's data points and an entity's dynamic property to be able to upload TimeSeries data.   Each agent has data points with unique ids. The mapping is between to this id to an entity's dynamic property set's property.  - A data point can be mapped to many property of many property set of many entities.  - A property cannot be mapped from more than one data point.   - A propertyset can have mappings from many agents' many data points to its properties.  - The unit of the datapoint has to be same with the unit of the property.  - The type of the datapoint has to be same with the type of the property.   Whenever data source configuration of an agent is updated via Agent Management API; all mappings with __keepMapping__ attribute set gets their validity attribute updated and all mappings with __keepMapping__ attribute unset are deleted.   # Exchange  Exchanging time series, events, files and data source configuration data. Combination of different data types can be uploaded via exchange endpoint within  multipart body. Maximum size of exchange body is 10MBs.  # Diagnostic Activations  Management of Diagnostic Activations and querying Diagnostic Messages of time series, event, file and data source configuration requests.  - Maximum 5 agents per tenant can be activated for data ingestion tracking.  - For non-agents, the required permission allows to manage diagnostic activation resources of agents in the same tenant as in the token.  - For agents, only the diagnostic activation related to the agent can be managed. Agents are forbidden to view/change the resources of other agents in the same tenant.  - Agents are allowed to update activation for itself only. Users with sufficient scopes are allowed   # noqa: E501
"""


import pprint
import re
import six

from mindconnect.models.diagnostic_activation import DiagnosticActivation
from mindconnect.models.order import Order
from mindsphere_core.exceptions import MindsphereClientError


class PagedDiagnosticActivation(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """

    attribute_types = {
        "content": "list[DiagnosticActivation]",
        "last": "bool",
        "total_pages": "int",
        "total_elements": "int",
        "number_of_elements": "int",
        "first": "bool",
        "sort": "list[Order]",
        "size": "int",
        "number": "int",
    }

    attribute_map = {
        "content": "content",
        "last": "last",
        "total_pages": "totalPages",
        "total_elements": "totalElements",
        "number_of_elements": "numberOfElements",
        "first": "first",
        "sort": "sort",
        "size": "size",
        "number": "number",
    }

    def __init__(
        self,
        content=None,
        last=None,
        total_pages=None,
        total_elements=None,
        number_of_elements=None,
        first=None,
        sort=None,
        size=None,
        number=None,
    ):
        self._content = content
        self._last = last
        self._total_pages = total_pages
        self._total_elements = total_elements
        self._number_of_elements = number_of_elements
        self._first = first
        self._sort = sort
        self._size = size
        self._number = number
        self.discriminator = None

    @property
    def content(self):
        """Gets the content of this PagedDiagnosticActivation.

        :return: The content of this PagedDiagnosticActivation.
        :rtype: list[DiagnosticActivation]
        """
        return self._content

    @content.setter
    def content(self, content):
        """Sets the content of this PagedDiagnosticActivation.

        :param content: The content of this PagedDiagnosticActivation.
        :type: list[DiagnosticActivation]
        """
        if content is None:
            raise MindsphereClientError(
                "Invalid value for `content`, must not be `None`"
            )

        self._content = content

    @property
    def last(self):
        """Gets the last of this PagedDiagnosticActivation.
        Whether the current item is the last one.

        :return: The last of this PagedDiagnosticActivation.
        :rtype: bool
        """
        return self._last

    @last.setter
    def last(self, last):
        """Sets the last of this PagedDiagnosticActivation.
        Whether the current item is the last one.

        :param last: The last of this PagedDiagnosticActivation.
        :type: bool
        """
        if last is None:
            raise MindsphereClientError("Invalid value for `last`, must not be `None`")

        self._last = last

    @property
    def total_pages(self):
        """Gets the total_pages of this PagedDiagnosticActivation.
        The number of total pages.

        :return: The total_pages of this PagedDiagnosticActivation.
        :rtype: int
        """
        return self._total_pages

    @total_pages.setter
    def total_pages(self, total_pages):
        """Sets the total_pages of this PagedDiagnosticActivation.
        The number of total pages.

        :param total_pages: The total_pages of this PagedDiagnosticActivation.
        :type: int
        """
        if total_pages is None:
            raise MindsphereClientError(
                "Invalid value for `total_pages`, must not be `None`"
            )

        self._total_pages = total_pages

    @property
    def total_elements(self):
        """Gets the total_elements of this PagedDiagnosticActivation.
        The total amount of elements.

        :return: The total_elements of this PagedDiagnosticActivation.
        :rtype: int
        """
        return self._total_elements

    @total_elements.setter
    def total_elements(self, total_elements):
        """Sets the total_elements of this PagedDiagnosticActivation.
        The total amount of elements.

        :param total_elements: The total_elements of this PagedDiagnosticActivation.
        :type: int
        """
        if total_elements is None:
            raise MindsphereClientError(
                "Invalid value for `total_elements`, must not be `None`"
            )

        self._total_elements = total_elements

    @property
    def number_of_elements(self):
        """Gets the number_of_elements of this PagedDiagnosticActivation.
        The number of elements currently on this page.

        :return: The number_of_elements of this PagedDiagnosticActivation.
        :rtype: int
        """
        return self._number_of_elements

    @number_of_elements.setter
    def number_of_elements(self, number_of_elements):
        """Sets the number_of_elements of this PagedDiagnosticActivation.
        The number of elements currently on this page.

        :param number_of_elements: The number_of_elements of this PagedDiagnosticActivation.
        :type: int
        """
        if number_of_elements is None:
            raise MindsphereClientError(
                "Invalid value for `number_of_elements`, must not be `None`"
            )

        self._number_of_elements = number_of_elements

    @property
    def first(self):
        """Gets the first of this PagedDiagnosticActivation.
        Whether the current item is the first one.

        :return: The first of this PagedDiagnosticActivation.
        :rtype: bool
        """
        return self._first

    @first.setter
    def first(self, first):
        """Sets the first of this PagedDiagnosticActivation.
        Whether the current item is the first one.

        :param first: The first of this PagedDiagnosticActivation.
        :type: bool
        """
        if first is None:
            raise MindsphereClientError("Invalid value for `first`, must not be `None`")

        self._first = first

    @property
    def sort(self):
        """Gets the sort of this PagedDiagnosticActivation.
        The sorting parameters for the page.

        :return: The sort of this PagedDiagnosticActivation.
        :rtype: list[Order]
        """
        return self._sort

    @sort.setter
    def sort(self, sort):
        """Sets the sort of this PagedDiagnosticActivation.
        The sorting parameters for the page.

        :param sort: The sort of this PagedDiagnosticActivation.
        :type: list[Order]
        """
        if sort is None:
            raise MindsphereClientError("Invalid value for `sort`, must not be `None`")

        self._sort = sort

    @property
    def size(self):
        """Gets the size of this PagedDiagnosticActivation.
        The size of the page.

        :return: The size of this PagedDiagnosticActivation.
        :rtype: int
        """
        return self._size

    @size.setter
    def size(self, size):
        """Sets the size of this PagedDiagnosticActivation.
        The size of the page.

        :param size: The size of this PagedDiagnosticActivation.
        :type: int
        """
        if size is None:
            raise MindsphereClientError("Invalid value for `size`, must not be `None`")

        self._size = size

    @property
    def number(self):
        """Gets the number of this PagedDiagnosticActivation.
        The number of the current item.

        :return: The number of this PagedDiagnosticActivation.
        :rtype: int
        """
        return self._number

    @number.setter
    def number(self, number):
        """Sets the number of this PagedDiagnosticActivation.
        The number of the current item.

        :param number: The number of this PagedDiagnosticActivation.
        :type: int
        """
        if number is None:
            raise MindsphereClientError(
                "Invalid value for `number`, must not be `None`"
            )

        self._number = number

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(
                    map(lambda x: x.to_dict() if hasattr(x, "to_dict") else x, value)
                )
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(
                    map(
                        lambda item: (item[0], item[1].to_dict())
                        if hasattr(item[1], "to_dict")
                        else item,
                        value.items(),
                    )
                )
            else:
                result[attr] = value
        if issubclass(PagedDiagnosticActivation, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, PagedDiagnosticActivation):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
