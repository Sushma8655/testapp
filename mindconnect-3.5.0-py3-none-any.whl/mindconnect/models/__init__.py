# coding: utf-8

# flake8: noqa
"""
    MindConnect API

     MindConnect API provides following data ingestion functionalities:  # Data Point Mappings  Creating and managing mappings between an agent's data points and an entity's dynamic property to be able to upload TimeSeries data.   Each agent has data points with unique ids. The mapping is between to this id to an entity's dynamic property set's property.  - A data point can be mapped to many property of many property set of many entities.  - A property cannot be mapped from more than one data point.   - A propertyset can have mappings from many agents' many data points to its properties.  - The unit of the datapoint has to be same with the unit of the property.  - The type of the datapoint has to be same with the type of the property.   Whenever data source configuration of an agent is updated via Agent Management API; all mappings with __keepMapping__ attribute set gets their validity attribute updated and all mappings with __keepMapping__ attribute unset are deleted.   # Exchange  Exchanging time series, events, files and data source configuration data. Combination of different data types can be uploaded via exchange endpoint within  multipart body. Maximum size of exchange body is 10MBs.  # Diagnostic Activations  Management of Diagnostic Activations and querying Diagnostic Messages of time series, event, file and data source configuration requests.  - Maximum 5 agents per tenant can be activated for data ingestion tracking.  - For non-agents, the required permission allows to manage diagnostic activation resources of agents in the same tenant as in the token.  - For agents, only the diagnostic activation related to the agent can be managed. Agents are forbidden to view/change the resources of other agents in the same tenant.  - Agents are allowed to update activation for itself only. Users with sufficient scopes are allowed   # noqa: E501
"""


from __future__ import absolute_import

# import models into model package
from mindconnect.models.badrequest import Badrequest
from mindconnect.models.conflict import Conflict
from mindconnect.models.data_point_mappings_get_request import (
    DataPointMappingsGetRequest,
)
from mindconnect.models.data_point_mappings_id_delete_request import (
    DataPointMappingsIdDeleteRequest,
)
from mindconnect.models.data_point_mappings_id_get_request import (
    DataPointMappingsIdGetRequest,
)
from mindconnect.models.data_point_mappings_post_request import (
    DataPointMappingsPostRequest,
)
from mindconnect.models.diagnostic_activation import DiagnosticActivation
from mindconnect.models.diagnostic_activation_status import DiagnosticActivationStatus
from mindconnect.models.diagnostic_activations_get_request import (
    DiagnosticActivationsGetRequest,
)
from mindconnect.models.diagnostic_activations_id_delete_request import (
    DiagnosticActivationsIdDeleteRequest,
)
from mindconnect.models.diagnostic_activations_id_get_request import (
    DiagnosticActivationsIdGetRequest,
)
from mindconnect.models.diagnostic_activations_id_messages_get_request import (
    DiagnosticActivationsIdMessagesGetRequest,
)
from mindconnect.models.diagnostic_activations_id_put_request import (
    DiagnosticActivationsIdPutRequest,
)
from mindconnect.models.diagnostic_activations_post_request import (
    DiagnosticActivationsPostRequest,
)
from mindconnect.models.diagnostic_information import DiagnosticInformation
from mindconnect.models.diagnostic_information_message import (
    DiagnosticInformationMessage,
)
from mindconnect.models.diagnostic_information_get_request import (
    DiagnosticInformationGetRequest,
)
from mindconnect.models.error import Error
from mindconnect.models.forbidden import Forbidden
from mindconnect.models.mapping import Mapping
from mindconnect.models.notfound import Notfound
from mindconnect.models.order import Order
from mindconnect.models.paged_diagnostic_activation import PagedDiagnosticActivation
from mindconnect.models.paged_diagnostic_information import PagedDiagnosticInformation
from mindconnect.models.paged_diagnostic_information_messages import (
    PagedDiagnosticInformationMessages,
)
from mindconnect.models.paged_mapping import PagedMapping
from mindconnect.models.paged_recoverable_records import PagedRecoverableRecords
from mindconnect.models.pay_load_too_large import PayLoadTooLarge
from mindconnect.models.recoverable_records import RecoverableRecords
from mindconnect.models.recoverable_records_get_request import (
    RecoverableRecordsGetRequest,
)
from mindconnect.models.recoverable_records_id_delete_request import (
    RecoverableRecordsIdDeleteRequest,
)
from mindconnect.models.recoverable_records_id_download_link_get_request import (
    RecoverableRecordsIdDownloadLinkGetRequest,
)
from mindconnect.models.recoverable_records_id_replay_post_request import (
    RecoverableRecordsIdReplayPostRequest,
)
from mindconnect.models.unauthorized import Unauthorized
from mindconnect.models.validity import Validity
