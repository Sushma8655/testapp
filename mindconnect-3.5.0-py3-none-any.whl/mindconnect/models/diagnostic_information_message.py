# coding: utf-8

"""
    MindConnect API

     MindConnect API provides following data ingestion functionalities:  # Data Point Mappings  Creating and managing mappings between an agent's data points and an entity's dynamic property to be able to upload TimeSeries data.   Each agent has data points with unique ids. The mapping is between to this id to an entity's dynamic property set's property.  - A data point can be mapped to many property of many property set of many entities.  - A property cannot be mapped from more than one data point.   - A propertyset can have mappings from many agents' many data points to its properties.  - The unit of the datapoint has to be same with the unit of the property.  - The type of the datapoint has to be same with the type of the property.   Whenever data source configuration of an agent is updated via Agent Management API; all mappings with __keepMapping__ attribute set gets their validity attribute updated and all mappings with __keepMapping__ attribute unset are deleted.   # Exchange  Exchanging time series, events, files and data source configuration data. Combination of different data types can be uploaded via exchange endpoint within  multipart body. Maximum size of exchange body is 10MBs.  # Diagnostic Activations  Management of Diagnostic Activations and querying Diagnostic Messages of time series, event, file and data source configuration requests.  - Maximum 5 agents per tenant can be activated for data ingestion tracking.  - For non-agents, the required permission allows to manage diagnostic activation resources of agents in the same tenant as in the token.  - For agents, only the diagnostic activation related to the agent can be managed. Agents are forbidden to view/change the resources of other agents in the same tenant.  - Agents are allowed to update activation for itself only. Users with sufficient scopes are allowed   # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class DiagnosticInformationMessage(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """

    attribute_types = {
        "correlation_id": "str",
        "severity": "str",
        "message": "str",
        "source": "str",
        "state": "str",
        "timestamp": "datetime",
    }

    attribute_map = {
        "correlation_id": "correlationId",
        "severity": "severity",
        "message": "message",
        "source": "source",
        "state": "state",
        "timestamp": "timestamp",
    }

    def __init__(
        self,
        correlation_id=None,
        severity=None,
        message=None,
        source=None,
        state=None,
        timestamp=None,
    ):
        self._correlation_id = correlation_id
        self._severity = severity
        self._message = message
        self._source = source
        self._state = state
        self._timestamp = timestamp
        self.discriminator = None

    @property
    def correlation_id(self):
        """Gets the correlation_id of this DiagnosticInformationMessage.

        :return: The correlation_id of this DiagnosticInformationMessage.
        :rtype: str
        """
        return self._correlation_id

    @correlation_id.setter
    def correlation_id(self, correlation_id):
        """Sets the correlation_id of this DiagnosticInformationMessage.

        :param correlation_id: The correlation_id of this DiagnosticInformationMessage.
        :type: str
        """
        if correlation_id is not None and len(correlation_id) > 36:
            raise MindsphereClientError(
                "Invalid value for `correlation_id`, length must be less than or equal to `36`"
            )

        self._correlation_id = correlation_id

    @property
    def severity(self):
        """Gets the severity of this DiagnosticInformationMessage.

        :return: The severity of this DiagnosticInformationMessage.
        :rtype: str
        """
        return self._severity

    @severity.setter
    def severity(self, severity):
        """Sets the severity of this DiagnosticInformationMessage.

        :param severity: The severity of this DiagnosticInformationMessage.
        :type: str
        """
        allowed_values = ["INFO", "WARN", "ERROR"]
        if severity.lower() not in [x.lower() for x in allowed_values]:
            raise MindsphereClientError(
                "Invalid value for `severity` ({0}), must be one of {1}".format(
                    severity, allowed_values
                )
            )

        self._severity = severity

    @property
    def message(self):
        """Gets the message of this DiagnosticInformationMessage.

        :return: The message of this DiagnosticInformationMessage.
        :rtype: str
        """
        return self._message

    @message.setter
    def message(self, message):
        """Sets the message of this DiagnosticInformationMessage.

        :param message: The message of this DiagnosticInformationMessage.
        :type: str
        """
        if message is not None and len(message) > 4096:
            raise MindsphereClientError(
                "Invalid value for `message`, length must be less than or equal to `4096`"
            )

        self._message = message

    @property
    def source(self):
        """Gets the source of this DiagnosticInformationMessage.
        Source of diagnostic information.

        :return: The source of this DiagnosticInformationMessage.
        :rtype: str
        """
        return self._source

    @source.setter
    def source(self, source):
        """Sets the source of this DiagnosticInformationMessage.
        Source of diagnostic information.

        :param source: The source of this DiagnosticInformationMessage.
        :type: str
        """

        self._source = source

    @property
    def state(self):
        """Gets the state of this DiagnosticInformationMessage.
        State of diagnostic information.

        :return: The state of this DiagnosticInformationMessage.
        :rtype: str
        """
        return self._state

    @state.setter
    def state(self, state):
        """Sets the state of this DiagnosticInformationMessage.
        State of diagnostic information.

        :param state: The state of this DiagnosticInformationMessage.
        :type: str
        """
        allowed_values = ["ACCEPTED", "RETRYING", "DROPPED", "PROCESSING", "FINISHED"]
        if state.lower() not in [x.lower() for x in allowed_values]:
            raise MindsphereClientError(
                "Invalid value for `state` ({0}), must be one of {1}".format(
                    state, allowed_values
                )
            )

        self._state = state

    @property
    def timestamp(self):
        """Gets the timestamp of this DiagnosticInformationMessage.
        Diagnostic information creation date.

        :return: The timestamp of this DiagnosticInformationMessage.
        :rtype: datetime
        """
        return self._timestamp

    @timestamp.setter
    def timestamp(self, timestamp):
        """Sets the timestamp of this DiagnosticInformationMessage.
        Diagnostic information creation date.

        :param timestamp: The timestamp of this DiagnosticInformationMessage.
        :type: datetime
        """

        self._timestamp = timestamp

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(
                    map(lambda x: x.to_dict() if hasattr(x, "to_dict") else x, value)
                )
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(
                    map(
                        lambda item: (item[0], item[1].to_dict())
                        if hasattr(item[1], "to_dict")
                        else item,
                        value.items(),
                    )
                )
            else:
                result[attr] = value
        if issubclass(DiagnosticInformationMessage, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, DiagnosticInformationMessage):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
