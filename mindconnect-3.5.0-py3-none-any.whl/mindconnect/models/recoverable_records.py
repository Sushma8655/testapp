# coding: utf-8

"""
    MindConnect API

     MindConnect API provides following data ingestion functionalities:  # Data Point Mappings  Creating and managing mappings between an agent's data points and an entity's dynamic property to be able to upload TimeSeries data.   Each agent has data points with unique ids. The mapping is between to this id to an entity's dynamic property set's property.  - A data point can be mapped to many property of many property set of many entities.  - A property cannot be mapped from more than one data point.   - A propertyset can have mappings from many agents' many data points to its properties.  - The unit of the datapoint has to be same with the unit of the property.  - The type of the datapoint has to be same with the type of the property.   Whenever data source configuration of an agent is updated via Agent Management API; all mappings with __keepMapping__ attribute set gets their validity attribute updated and all mappings with __keepMapping__ attribute unset are deleted.   # Exchange  Exchanging time series, events, files and data source configuration data. Combination of different data types can be uploaded via exchange endpoint within  multipart body. Maximum size of exchange body is 10MBs.  # Diagnostic Activations  Management of Diagnostic Activations and querying Diagnostic Messages of time series, event, file and data source configuration requests.  - Maximum 5 agents per tenant can be activated for data ingestion tracking.  - For non-agents, the required permission allows to manage diagnostic activation resources of agents in the same tenant as in the token.  - For agents, only the diagnostic activation related to the agent can be managed. Agents are forbidden to view/change the resources of other agents in the same tenant.  - Agents are allowed to update activation for itself only. Users with sufficient scopes are allowed   # noqa: E501
"""


import pprint
import re
import six
from mindsphere_core.exceptions import MindsphereClientError


class RecoverableRecords(object):

    """
    Attributes:
      attribute_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """

    attribute_types = {
        "id": "str",
        "correlation_id": "str",
        "agent_id": "str",
        "request_time": "datetime",
        "drop_reason": "str",
    }

    attribute_map = {
        "id": "id",
        "correlation_id": "correlationId",
        "agent_id": "agentId",
        "request_time": "requestTime",
        "drop_reason": "dropReason",
    }

    def __init__(
        self,
        id=None,
        correlation_id=None,
        agent_id=None,
        request_time=None,
        drop_reason=None,
    ):
        self._id = id
        self._correlation_id = correlation_id
        self._agent_id = agent_id
        self._request_time = request_time
        self._drop_reason = drop_reason
        self.discriminator = None

    @property
    def id(self):
        """Gets the id of this RecoverableRecords.
        Unique identifier of the record

        :return: The id of this RecoverableRecords.
        :rtype: str
        """
        return self._id

    @id.setter
    def id(self, id):
        """Sets the id of this RecoverableRecords.
        Unique identifier of the record

        :param id: The id of this RecoverableRecords.
        :type: str
        """

        self._id = id

    @property
    def correlation_id(self):
        """Gets the correlation_id of this RecoverableRecords.
        Unique identifier of the record

        :return: The correlation_id of this RecoverableRecords.
        :rtype: str
        """
        return self._correlation_id

    @correlation_id.setter
    def correlation_id(self, correlation_id):
        """Sets the correlation_id of this RecoverableRecords.
        Unique identifier of the record

        :param correlation_id: The correlation_id of this RecoverableRecords.
        :type: str
        """

        self._correlation_id = correlation_id

    @property
    def agent_id(self):
        """Gets the agent_id of this RecoverableRecords.
        agentId

        :return: The agent_id of this RecoverableRecords.
        :rtype: str
        """
        return self._agent_id

    @agent_id.setter
    def agent_id(self, agent_id):
        """Sets the agent_id of this RecoverableRecords.
        agentId

        :param agent_id: The agent_id of this RecoverableRecords.
        :type: str
        """
        if agent_id is not None and len(agent_id) > 36:
            raise MindsphereClientError(
                "Invalid value for `agent_id`, length must be less than or equal to `36`"
            )

        self._agent_id = agent_id

    @property
    def request_time(self):
        """Gets the request_time of this RecoverableRecords.
        Ingestion date of the data.

        :return: The request_time of this RecoverableRecords.
        :rtype: datetime
        """
        return self._request_time

    @request_time.setter
    def request_time(self, request_time):
        """Sets the request_time of this RecoverableRecords.
        Ingestion date of the data.

        :param request_time: The request_time of this RecoverableRecords.
        :type: datetime
        """

        self._request_time = request_time

    @property
    def drop_reason(self):
        """Gets the drop_reason of this RecoverableRecords.
        Drop reason of data

        :return: The drop_reason of this RecoverableRecords.
        :rtype: str
        """
        return self._drop_reason

    @drop_reason.setter
    def drop_reason(self, drop_reason):
        """Sets the drop_reason of this RecoverableRecords.
        Drop reason of data

        :param drop_reason: The drop_reason of this RecoverableRecords.
        :type: str
        """
        if drop_reason is not None and len(drop_reason) > 1024:
            raise MindsphereClientError(
                "Invalid value for `drop_reason`, length must be less than or equal to `1024`"
            )

        self._drop_reason = drop_reason

    def to_dict(self):
        """Returns the model properties as a dict"""
        result = {}

        for attr, _ in six.iteritems(self.attribute_types):
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(
                    map(lambda x: x.to_dict() if hasattr(x, "to_dict") else x, value)
                )
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(
                    map(
                        lambda item: (item[0], item[1].to_dict())
                        if hasattr(item[1], "to_dict")
                        else item,
                        value.items(),
                    )
                )
            else:
                result[attr] = value
        if issubclass(RecoverableRecords, dict):
            for key, value in self.items():
                result[key] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        return pprint.pformat(self.to_dict())

    def __repr__(self):
        """For `print` and `pprint`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, RecoverableRecords):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
